// 由 tools/extract-skins.js 从 Skin.kt 自动生成，请勿手改
window.SONANCE_SKINS = [
 {
  "id": "midnight_amber",
  "name": "午夜琥珀",
  "tagline": "原型默认 · 暗金",
  "light": false,
  "bg": "#121212",
  "surface": "#1A1A1A",
  "surface2": "#222222",
  "text": "#EDE8E0",
  "textDim": "#9A958E",
  "accent": "#E8A838",
  "onAccent": "#121212",
  "grad": [
   "#3A2A10",
   "#1A1408"
  ]
 },
 {
  "id": "graphite",
  "name": "石墨黑夜",
  "tagline": "极简中性 · 冷灰",
  "light": false,
  "bg": "#0D0D0F",
  "surface": "#161618",
  "surface2": "#1E1E21",
  "text": "#F2F2F4",
  "textDim": "#9E9EA7",
  "accent": "#8EA2FF",
  "onAccent": "#0D0D0F",
  "grad": [
   "#242A44",
   "#14161F"
  ]
 },
 {
  "id": "ocean",
  "name": "深海静默",
  "tagline": "海蓝 · 深夜",
  "light": false,
  "bg": "#08131F",
  "surface": "#0E1E2E",
  "surface2": "#14283C",
  "text": "#E6F2FA",
  "textDim": "#87A8C2",
  "accent": "#3FC1F5",
  "onAccent": "#04121C",
  "grad": [
   "#123A55",
   "#08151F"
  ]
 },
 {
  "id": "neon_violet",
  "name": "霓虹紫夜",
  "tagline": "赛博 · 电紫",
  "light": false,
  "bg": "#0F0718",
  "surface": "#180C24",
  "surface2": "#211134",
  "text": "#F0E8FA",
  "textDim": "#A78FC4",
  "accent": "#B478FF",
  "onAccent": "#0F0718",
  "grad": [
   "#3A1B5E",
   "#150A22"
  ]
 },
 {
  "id": "forest",
  "name": "松林幽谷",
  "tagline": "自然 · 森绿",
  "light": false,
  "bg": "#0A1210",
  "surface": "#0F1B17",
  "surface2": "#152520",
  "text": "#E8F3EC",
  "textDim": "#8AA99A",
  "accent": "#4ADE80",
  "onAccent": "#04140B",
  "grad": [
   "#17402D",
   "#08130E"
  ]
 },
 {
  "id": "crimson",
  "name": "绯红夜幕",
  "tagline": "热烈 · 酒红",
  "light": false,
  "bg": "#140A0C",
  "surface": "#1E1013",
  "surface2": "#29151A",
  "text": "#F7EAEC",
  "textDim": "#C2949B",
  "accent": "#FF5A6E",
  "onAccent": "#140A0C",
  "grad": [
   "#4A1720",
   "#160A0D"
  ]
 },
 {
  "id": "ivory",
  "name": "象牙白昼",
  "tagline": "明亮 · 暖米",
  "light": true,
  "bg": "#F7F4EF",
  "surface": "#FFFFFF",
  "surface2": "#F1ECE4",
  "text": "#1E1B16",
  "textDim": "#6B6459",
  "accent": "#C8791A",
  "onAccent": "#FFFFFF",
  "grad": [
   "#F3DFC0",
   "#E8D3B0"
  ]
 },
 {
  "id": "sakura",
  "name": "樱花浅粉",
  "tagline": "温柔 · 浅粉",
  "light": true,
  "bg": "#FDF6F7",
  "surface": "#FFFFFF",
  "surface2": "#F9EDF0",
  "text": "#2A1E22",
  "textDim": "#7A6270",
  "accent": "#E0568A",
  "onAccent": "#FFFFFF",
  "grad": [
   "#FBDCE6",
   "#F2C2D3"
  ]
 },
 {
  "id": "mint",
  "name": "薄荷清晨",
  "tagline": "清爽 · 浅绿",
  "light": true,
  "bg": "#F2F8F6",
  "surface": "#FFFFFF",
  "surface2": "#E8F2EF",
  "text": "#152420",
  "textDim": "#5A7570",
  "accent": "#0E9F6E",
  "onAccent": "#FFFFFF",
  "grad": [
   "#CDE9DF",
   "#B2DCCD"
  ]
 },
 {
  "id": "mist",
  "name": "雾霭蓝",
  "tagline": "清冷 · 雾蓝",
  "light": true,
  "bg": "#F3F6FA",
  "surface": "#FFFFFF",
  "surface2": "#E9EFF6",
  "text": "#17202B",
  "textDim": "#5A6879",
  "accent": "#2E6DB4",
  "onAccent": "#FFFFFF",
  "grad": [
   "#DCE8F6",
   "#BCCFE8"
  ]
 },
 {
  "id": "cloud",
  "name": "素白极简",
  "tagline": "中性 · 极简",
  "light": true,
  "bg": "#F5F6F8",
  "surface": "#FFFFFF",
  "surface2": "#ECEEF1",
  "text": "#1B1E23",
  "textDim": "#5F656F",
  "accent": "#4A63E7",
  "onAccent": "#FFFFFF",
  "grad": [
   "#E3E6EC",
   "#C9CFD9"
  ]
 },
 {
  "id": "lavender",
  "name": "薰衣草田",
  "tagline": "柔和 · 浅紫",
  "light": true,
  "bg": "#F8F6FC",
  "surface": "#FFFFFF",
  "surface2": "#EFEAF8",
  "text": "#1F1A2B",
  "textDim": "#615878",
  "accent": "#7A5AD0",
  "onAccent": "#FFFFFF",
  "grad": [
   "#E7DEF8",
   "#CFC0EE"
  ]
 },
 {
  "id": "coral",
  "name": "珊瑚暖阳",
  "tagline": "暖阳 · 珊瑚",
  "light": true,
  "bg": "#FDF6F2",
  "surface": "#FFFFFF",
  "surface2": "#FAEBE3",
  "text": "#2B1C14",
  "textDim": "#77584A",
  "accent": "#DE6239",
  "onAccent": "#FFFFFF",
  "grad": [
   "#FBDDCC",
   "#F3C3AA"
  ]
 },
 {
  "id": "clay",
  "name": "陶土暖棕",
  "tagline": "质朴 · 陶土",
  "light": true,
  "bg": "#F9F4F0",
  "surface": "#FFFFFF",
  "surface2": "#F2E7E0",
  "text": "#26190F",
  "textDim": "#6D5442",
  "accent": "#9C5B3C",
  "onAccent": "#FFFFFF",
  "grad": [
   "#EDD9C8",
   "#DCC0AA"
  ]
 },
 {
  "id": "neon_lime",
  "name": "霓虹青柠",
  "tagline": "高饱和 · 酸绿",
  "light": false,
  "bg": "#0A1004",
  "surface": "#121A09",
  "surface2": "#18240D",
  "text": "#F4FFE2",
  "textDim": "#A9C88C",
  "accent": "#C9FF33",
  "onAccent": "#0A1004",
  "grad": [
   "#2C4A0E",
   "#0C1405"
  ]
 },
 {
  "id": "cyber_magenta",
  "name": "赛博洋红",
  "tagline": "高饱和 · 电粉",
  "light": false,
  "bg": "#120516",
  "surface": "#1D0A24",
  "surface2": "#270E32",
  "text": "#FDEAFB",
  "textDim": "#D292C7",
  "accent": "#FF2FD0",
  "onAccent": "#120516",
  "grad": [
   "#5A0A4E",
   "#160619"
  ]
 },
 {
  "id": "electric_cyan",
  "name": "电光冰蓝",
  "tagline": "高饱和 · 电蓝",
  "light": false,
  "bg": "#030B18",
  "surface": "#07152B",
  "surface2": "#0B1E3C",
  "text": "#E4F5FF",
  "textDim": "#87AACA",
  "accent": "#18E0FF",
  "onAccent": "#031018",
  "grad": [
   "#0B3A5C",
   "#061320"
  ]
 },
 {
  "id": "sunset_blaze",
  "name": "落日熔金",
  "tagline": "高饱和 · 炽橙",
  "light": false,
  "bg": "#1A0803",
  "surface": "#271009",
  "surface2": "#34170D",
  "text": "#FFF1E4",
  "textDim": "#DBA483",
  "accent": "#FF7A18",
  "onAccent": "#1A0803",
  "grad": [
   "#5C1D06",
   "#1C0A04"
  ]
 },
 {
  "id": "tropical",
  "name": "热带果漾",
  "tagline": "鲜明 · 暖果",
  "light": true,
  "bg": "#FFFBF2",
  "surface": "#FFFFFF",
  "surface2": "#FFF1DA",
  "text": "#2A1A06",
  "textDim": "#7C5C2C",
  "accent": "#FF6B35",
  "onAccent": "#FFFFFF",
  "grad": [
   "#FFE0A8",
   "#FFC178"
  ]
 },
 {
  "id": "sky_lemon",
  "name": "晴空柠檬",
  "tagline": "鲜明 · 天蓝柠檬",
  "light": true,
  "bg": "#F6FCFF",
  "surface": "#FFFFFF",
  "surface2": "#E6F6FF",
  "text": "#0C1E29",
  "textDim": "#4F7285",
  "accent": "#00B8FF",
  "onAccent": "#FFFFFF",
  "grad": [
   "#B8E8FF",
   "#8FD4F5"
  ]
 },
 {
  "id": "frosted_glass",
  "name": "霜华玻璃",
  "tagline": "毛玻璃 · 冷白",
  "light": true,
  "bg": "#EDF1F7",
  "surface": "#F8FAFD",
  "surface2": "#E5EBF4",
  "text": "#17202B",
  "textDim": "#5A6879",
  "accent": "#3A7BD5",
  "onAccent": "#FFFFFF",
  "grad": [
   "#D9E6F5",
   "#BFD2E8"
  ]
 },
 {
  "id": "liquid_glass",
  "name": "液态玻璃",
  "tagline": "液态玻璃 · 深蓝",
  "light": false,
  "bg": "#080D16",
  "surface": "#111A27",
  "surface2": "#192533",
  "text": "#EAF3FF",
  "textDim": "#9BB0C8",
  "accent": "#5AC8FA",
  "onAccent": "#04121C",
  "grad": [
   "#1B3550",
   "#0A1420"
  ]
 },
 {
  "id": "immersive",
  "name": "沉浸",
  "tagline": "封面铺底 · 随歌换妆",
  "light": false,
  "bg": "#17181C",
  "surface": "#22242A",
  "surface2": "#2A2C33",
  "text": "#F2F2F3",
  "textDim": "#B9B9C0",
  "accent": "#4ECDC4",
  "onAccent": "#0A0F0E",
  "grad": [
   "#2A2C34",
   "#17181C"
  ]
 },
 {
  "id": "titian_red",
  "name": "提香红",
  "tagline": "封面铺底 · 绯红玻璃",
  "light": false,
  "bg": "#201010",
  "surface": "#2A1A18",
  "surface2": "#33201D",
  "text": "#F7ECEA",
  "textDim": "#D9C2BE",
  "accent": "#E0615E",
  "onAccent": "#FFF4F2",
  "grad": [
   "#4A1C1B",
   "#150A0A"
  ]
 },
 {
  "id": "lime_green",
  "name": "莱姆绿",
  "tagline": "封面铺底 · 青翠玻璃",
  "light": false,
  "bg": "#101A0C",
  "surface": "#1A2814",
  "surface2": "#22331A",
  "text": "#F1FAEA",
  "textDim": "#CFE2C4",
  "accent": "#7DD863",
  "onAccent": "#08120A",
  "grad": [
   "#2C4A16",
   "#0C1405"
  ]
 },
 {
  "id": "marrs_green",
  "name": "马尔斯绿",
  "tagline": "封面铺底 · 幽青玻璃",
  "light": false,
  "bg": "#0A1A1B",
  "surface": "#14292B",
  "surface2": "#1B3436",
  "text": "#E9F7F6",
  "textDim": "#C2DEDC",
  "accent": "#22BCB7",
  "onAccent": "#041414",
  "grad": [
   "#0E3A3B",
   "#051313"
  ]
 },
 {
  "id": "klein_blue",
  "name": "克莱因蓝",
  "tagline": "封面铺底 · 深蓝玻璃",
  "light": false,
  "bg": "#0A1128",
  "surface": "#161F45",
  "surface2": "#1D2856",
  "text": "#EDF1FF",
  "textDim": "#C4CDEE",
  "accent": "#4A6EE8",
  "onAccent": "#FFFFFF",
  "grad": [
   "#0E1E5C",
   "#050918"
  ]
 },
 {
  "id": "chinese_red",
  "name": "中国红",
  "tagline": "封面铺底 · 朱红玻璃",
  "light": false,
  "bg": "#1E0C0D",
  "surface": "#2C1517",
  "surface2": "#371B1E",
  "text": "#F9ECEA",
  "textDim": "#DFC4C1",
  "accent": "#E0454B",
  "onAccent": "#FFF5F3",
  "grad": [
   "#4A1013",
   "#140506"
  ]
 },
 {
  "id": "xuan_paper",
  "name": "宣纸白",
  "tagline": "封面铺底 · 素宣白玻璃",
  "light": true,
  "bg": "#F4F0E8",
  "surface": "#FFFFFF",
  "surface2": "#F7F3EB",
  "text": "#221E18",
  "textDim": "#6B6459",
  "accent": "#A8551E",
  "onAccent": "#FFFFFF",
  "grad": [
   "#F3DFC0",
   "#E8D3B0"
  ]
 },
 {
  "id": "porcelain_blue",
  "name": "青花瓷",
  "tagline": "封面铺底 · 青花白玻璃",
  "light": true,
  "bg": "#F0F4FA",
  "surface": "#FFFFFF",
  "surface2": "#F2F5FA",
  "text": "#17202B",
  "textDim": "#5A6879",
  "accent": "#1D4FB8",
  "onAccent": "#FFFFFF",
  "grad": [
   "#DCE8F6",
   "#BCCFE8"
  ]
 },
 {
  "id": "glaze_red",
  "name": "釉里红",
  "tagline": "封面铺底 · 釉里红玻璃",
  "light": true,
  "bg": "#FAF0EE",
  "surface": "#FFFFFF",
  "surface2": "#FAF1EF",
  "text": "#2B1A18",
  "textDim": "#77584A",
  "accent": "#C0392B",
  "onAccent": "#FFFFFF",
  "grad": [
   "#F8D5C4",
   "#EFB99D"
  ]
 }
];
;
// 由 tools/vector2svg.js 从 res/drawable/logo_*.xml 自动生成，请勿手改
window.SONANCE_ICONS = [{"id":"s2_4","name":"均衡器 · 圆弧波形","bg":"#0D2826","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><g transform=\"translate(21 21) rotate(0) scale(0.66 0.66) translate(0 0)\"><path d=\"M20 60 Q20 40 30 40 Q40 40 40 60 Q40 30 50 30 Q60 30 60 60 Q60 45 70 45 Q80 45 80 60\" fill=\"none\" stroke=\"#4ecdc4\" stroke-width=\"5\" stroke-linecap=\"round\"/></g></svg>"},{"id":"sonance_dial","name":"回响之钮 · 触感徽章","bg":"#131518","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i1g0\" gradientUnits=\"userSpaceOnUse\" x1=\"16.20\" y1=\"16.20\" x2=\"91.80\" y2=\"91.80\"><stop offset=\"0.00\" stop-color=\"#faf7f2\"/><stop offset=\"1.00\" stop-color=\"#ddd5c7\"/></linearGradient><linearGradient id=\"i1g1\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f6c57d\"/><stop offset=\"1.00\" stop-color=\"#d97736\"/></linearGradient></defs><path d=\"M23.0000,54.0000 a31.0000,31.0000 0 1,0 62.0000,0 a31.0000,31.0000 0 1,0 -62.0000,0 Z\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"1\" stroke-opacity=\"0.1\"/><path d=\"M30.0000,54.0000 a24.0000,24.0000 0 1,0 48.0000,0 a24.0000,24.0000 0 1,0 -48.0000,0 Z\" fill=\"url(#i1g0)\"/><path d=\"M36 40 A22 22 0 0 1 68 37\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"1.4\" stroke-opacity=\"0.7\" stroke-linecap=\"round\"/><path d=\"M64.5000,43.5000 L70.0000,38.0000\" fill=\"none\" stroke=\"#131518\" stroke-width=\"2.6\" stroke-linecap=\"round\"/><path d=\"M47.0000,47.0000 h7.0000 a7.0000,7.0000 0 0,1 7.0000,7.0000 v0.0000 a7.0000,7.0000 0 0,1 -7.0000,7.0000 h-7.0000 a7.0000,7.0000 0 0,1 -7.0000,-7.0000 v-0.0000 a7.0000,7.0000 0 0,1 7.0000,-7.0000 z\" fill=\"#131518\"/><path d=\"M42.2000,54.0000 a4.8000,4.8000 0 1,0 9.6000,0 a4.8000,4.8000 0 1,0 -9.6000,0 Z\" fill=\"url(#i1g1)\"/><path d=\"M53.3000,54.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#f2ede4\" fill-opacity=\"0.45\"/></svg>"},{"id":"min_vinyl","name":"极简黑胶 · 同心韵律","bg":"#141416","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M24.0000,54.0000 a30.0000,30.0000 0 1,0 60.0000,0 a30.0000,30.0000 0 1,0 -60.0000,0 Z\" fill=\"#1e1e22\" stroke=\"#36363c\" stroke-width=\"1.5\"/><path d=\"M30.0000,54.0000 a24.0000,24.0000 0 1,0 48.0000,0 a24.0000,24.0000 0 1,0 -48.0000,0 Z\" fill=\"none\" stroke=\"#2e2e34\" stroke-width=\"1.2\"/><path d=\"M36.0000,54.0000 a18.0000,18.0000 0 1,0 36.0000,0 a18.0000,18.0000 0 1,0 -36.0000,0 Z\" fill=\"none\" stroke=\"#34343b\" stroke-width=\"1.2\"/><path d=\"M32 38 A26 26 0 0 1 68 32\" fill=\"none\" stroke=\"#f4efe6\" stroke-width=\"1.6\" stroke-opacity=\"0.45\" stroke-linecap=\"round\"/><path d=\"M43.5000,54.0000 a10.5000,10.5000 0 1,0 21.0000,0 a10.5000,10.5000 0 1,0 -21.0000,0 Z\" fill=\"#d4a359\"/><path d=\"M50.8000,54.0000 a3.2000,3.2000 0 1,0 6.4000,0 a3.2000,3.2000 0 1,0 -6.4000,0 Z\" fill=\"#141416\"/></svg>"},{"id":"bauhaus_play","name":"包豪斯 · 几何棱镜","bg":"#F2ECE1","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M24.0000,54.0000 a30.0000,30.0000 0 1,0 60.0000,0 a30.0000,30.0000 0 1,0 -60.0000,0 Z\" fill=\"none\" stroke=\"#1f1e1c\" stroke-width=\"1.4\" stroke-opacity=\"0.22\"/><path d=\"M32.0000,32.0000 h6.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v40.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-6.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-40.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"#1f1e1c\"/><path d=\"M40 32 A22 22 0 0 1 40 76 Z\" fill=\"#2b5b84\"/><path d=\"M50.0000,36.0000 L78.0000,54.0000 L50.0000,72.0000 Z\" fill=\"#d94e34\" fill-opacity=\"0.92\"/><path d=\"M50.0000,43.0000 L62.0000,54.0000 L50.0000,65.0000 Z\" fill=\"#1f1e1c\" fill-opacity=\"0.22\"/><path d=\"M32.8000,38.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#f2ece1\"/></svg>"},{"id":"tuning_fork","name":"音叉 · 共振之声","bg":"#1A2228","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M44 28 L44 50 A10 10 0 0 0 64 50 L64 28\" fill=\"none\" stroke=\"#e2e8f0\" stroke-width=\"5\" stroke-linecap=\"round\"/><path d=\"M54.0000,60.0000 L54.0000,79.0000\" fill=\"none\" stroke=\"#e2e8f0\" stroke-width=\"5\" stroke-linecap=\"round\"/><path d=\"M50.2000,80.0000 a3.8000,3.8000 0 1,0 7.6000,0 a3.8000,3.8000 0 1,0 -7.6000,0 Z\" fill=\"#7dd3fc\"/><path d=\"M35 34 A18 18 0 0 0 35 54\" fill=\"none\" stroke=\"#7dd3fc\" stroke-width=\"2.4\" stroke-opacity=\"0.8\" stroke-linecap=\"round\"/><path d=\"M28 30 A25 25 0 0 0 28 58\" fill=\"none\" stroke=\"#7dd3fc\" stroke-width=\"2\" stroke-opacity=\"0.4\" stroke-linecap=\"round\"/><path d=\"M73 34 A18 18 0 0 1 73 54\" fill=\"none\" stroke=\"#7dd3fc\" stroke-width=\"2.4\" stroke-opacity=\"0.8\" stroke-linecap=\"round\"/><path d=\"M80 30 A25 25 0 0 1 80 58\" fill=\"none\" stroke=\"#7dd3fc\" stroke-width=\"2\" stroke-opacity=\"0.4\" stroke-linecap=\"round\"/></svg>"},{"id":"metronome","name":"节拍器 · 黄金律动","bg":"#241E1A","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M38 78 L46 28 L62 28 L70 78 Z\" fill=\"#322923\" stroke=\"#e8c58e\" stroke-width=\"2.6\" stroke-linejoin=\"round\"/><path d=\"M45.0000,66.0000 L63.0000,66.0000\" fill=\"none\" stroke=\"#c88d45\" stroke-width=\"2\"/><path d=\"M54.0000,74.0000 L72.0000,33.0000\" fill=\"none\" stroke=\"#e8c58e\" stroke-width=\"3.2\" stroke-linecap=\"round\"/><path d=\"M62.0000,43.0000 L71.0000,47.0000 L67.0000,54.0000 L58.0000,50.0000 Z\" fill=\"#c88d45\"/><path d=\"M50.5000,74.0000 a3.5000,3.5000 0 1,0 7.0000,0 a3.5000,3.5000 0 1,0 -7.0000,0 Z\" fill=\"#e8c58e\"/></svg>"},{"id":"golden_pause","name":"双柱 · 静谧停顿","bg":"#EDE6D8","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M25.0000,54.0000 a29.0000,29.0000 0 1,0 58.0000,0 a29.0000,29.0000 0 1,0 -58.0000,0 Z\" fill=\"none\" stroke=\"#c59b5f\" stroke-width=\"1.5\" stroke-opacity=\"0.5\"/><path d=\"M32 34 A29 29 0 0 1 76 34\" fill=\"none\" stroke=\"#1f2421\" stroke-width=\"2\" stroke-opacity=\"0.35\" stroke-linecap=\"round\"/><path d=\"M44.0000,33.0000 h0.0000 a6.0000,6.0000 0 0,1 6.0000,6.0000 v30.0000 a6.0000,6.0000 0 0,1 -6.0000,6.0000 h-0.0000 a6.0000,6.0000 0 0,1 -6.0000,-6.0000 v-30.0000 a6.0000,6.0000 0 0,1 6.0000,-6.0000 z\" fill=\"#1f2421\"/><path d=\"M42.5000,37.0000 h0.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v31.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-0.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-31.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#ffffff\" fill-opacity=\"0.14\"/><path d=\"M64.0000,39.0000 h0.0000 a6.0000,6.0000 0 0,1 6.0000,6.0000 v24.0000 a6.0000,6.0000 0 0,1 -6.0000,6.0000 h-0.0000 a6.0000,6.0000 0 0,1 -6.0000,-6.0000 v-24.0000 a6.0000,6.0000 0 0,1 6.0000,-6.0000 z\" fill=\"#c59b5f\"/><path d=\"M61.4000,32.0000 a2.6000,2.6000 0 1,0 5.2000,0 a2.6000,2.6000 0 1,0 -5.2000,0 Z\" fill=\"#8c6d46\"/></svg>"},{"id":"retro_cassette","name":"复古磁带 · 双轮卡座","bg":"#1E1B18","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M29.0000,34.0000 h50.0000 a5.0000,5.0000 0 0,1 5.0000,5.0000 v30.0000 a5.0000,5.0000 0 0,1 -5.0000,5.0000 h-50.0000 a5.0000,5.0000 0 0,1 -5.0000,-5.0000 v-30.0000 a5.0000,5.0000 0 0,1 5.0000,-5.0000 z\" fill=\"#2e2a26\" stroke=\"#d9d0c3\" stroke-width=\"2.2\"/><path d=\"M31.5000,39.0000 h45.0000 a2.5000,2.5000 0 0,1 2.5000,2.5000 v11.0000 a2.5000,2.5000 0 0,1 -2.5000,2.5000 h-45.0000 a2.5000,2.5000 0 0,1 -2.5000,-2.5000 v-11.0000 a2.5000,2.5000 0 0,1 2.5000,-2.5000 z\" fill=\"#f3ede2\"/><path d=\"M30.5000,39.0000 h47.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v2.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-47.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-2.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#e06d44\"/><path d=\"M41.0000,46.0000 h26.0000 a6.0000,6.0000 0 0,1 6.0000,6.0000 v0.0000 a6.0000,6.0000 0 0,1 -6.0000,6.0000 h-26.0000 a6.0000,6.0000 0 0,1 -6.0000,-6.0000 v-0.0000 a6.0000,6.0000 0 0,1 6.0000,-6.0000 z\" fill=\"#1e1b18\"/><path d=\"M37.8000,52.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"none\" stroke=\"#f3ede2\" stroke-width=\"1.8\"/><path d=\"M61.8000,52.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"none\" stroke=\"#f3ede2\" stroke-width=\"1.8\"/><path d=\"M49.0000,49.0000 h10.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v4.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-10.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-4.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#5c554e\"/><path d=\"M33 74 L37 66 L71 66 L75 74\" fill=\"none\" stroke=\"#8c8275\" stroke-width=\"1.8\" stroke-linejoin=\"round\"/><path d=\"M42.6000,70.5000 a1.4000,1.4000 0 1,0 2.8000,0 a1.4000,1.4000 0 1,0 -2.8000,0 Z\" fill=\"#d9d0c3\"/><path d=\"M62.6000,70.5000 a1.4000,1.4000 0 1,0 2.8000,0 a1.4000,1.4000 0 1,0 -2.8000,0 Z\" fill=\"#d9d0c3\"/></svg>"},{"id":"turntable_arm","name":"黑胶唱机 · 落针时刻","bg":"#261C16","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M30.0000,25.0000 h48.0000 a8.0000,8.0000 0 0,1 8.0000,8.0000 v42.0000 a8.0000,8.0000 0 0,1 -8.0000,8.0000 h-48.0000 a8.0000,8.0000 0 0,1 -8.0000,-8.0000 v-42.0000 a8.0000,8.0000 0 0,1 8.0000,-8.0000 z\" fill=\"#3b2b22\" stroke=\"#7a5d4b\" stroke-width=\"1.8\"/><path d=\"M24.0000,54.0000 a22.0000,22.0000 0 1,0 44.0000,0 a22.0000,22.0000 0 1,0 -44.0000,0 Z\" fill=\"#121214\" stroke=\"#52463e\" stroke-width=\"2\"/><path d=\"M29.0000,54.0000 a17.0000,17.0000 0 1,0 34.0000,0 a17.0000,17.0000 0 1,0 -34.0000,0 Z\" fill=\"none\" stroke=\"#26262a\" stroke-width=\"1.2\"/><path d=\"M32 42 A18 18 0 0 1 56 38\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"1.2\" stroke-opacity=\"0.25\" stroke-linecap=\"round\"/><path d=\"M38.5000,54.0000 a7.5000,7.5000 0 1,0 15.0000,0 a7.5000,7.5000 0 1,0 -15.0000,0 Z\" fill=\"#d9a05b\"/><path d=\"M43.8000,54.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#121214\"/><path d=\"M70.0000,34.0000 a5.0000,5.0000 0 1,0 10.0000,0 a5.0000,5.0000 0 1,0 -10.0000,0 Z\" fill=\"#4a3d35\" stroke=\"#eae2d6\" stroke-width=\"1.5\"/><path d=\"M73.0000,27.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v2.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-2.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#d9a05b\"/><path d=\"M75 34 C76 47, 72 56, 63 63\" fill=\"none\" stroke=\"#eae2d6\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><g transform=\"translate(60.5 63) rotate(-38) scale(1 1) translate(-60.5 -63)\"><path d=\"M58.0000,61.0000 h5.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v2.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-5.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-2.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#d9a05b\"/></g><path d=\"M73.6000,74.0000 a2.4000,2.4000 0 1,0 4.8000,0 a2.4000,2.4000 0 1,0 -4.8000,0 Z\" fill=\"#4ade80\"/></svg>"},{"id":"vacuum_tube","name":"电子管 · 暖光胆机","bg":"#141010","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><radialGradient id=\"i9g2\" gradientUnits=\"userSpaceOnUse\" cx=\"54.00\" cy=\"51.84\" r=\"43.20\"><stop offset=\"0.00\" stop-color=\"#ffd59e\" stop-opacity=\"0.949\"/><stop offset=\"0.55\" stop-color=\"#ff7b29\" stop-opacity=\"0.451\"/><stop offset=\"1.00\" stop-color=\"#ff7b29\" stop-opacity=\"0\"/></radialGradient></defs><path d=\"M34.0000,48.0000 a20.0000,20.0000 0 1,0 40.0000,0 a20.0000,20.0000 0 1,0 -40.0000,0 Z\" fill=\"url(#i9g2)\"/><path d=\"M40 64 L40 38 A14 14 0 0 1 68 38 L68 64 Z\" fill=\"#ffffff\" fill-opacity=\"0.06\" stroke=\"#9aa5b4\" stroke-width=\"2.2\"/><path d=\"M49.0000,40.0000 h10.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v12.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-10.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-12.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"none\" stroke=\"#647080\" stroke-width=\"1.6\"/><path d=\"M50 54 L50 43 L54 47 L58 43 L58 54\" fill=\"none\" stroke=\"#ffb86c\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M40.5000,64.0000 h27.0000 a2.5000,2.5000 0 0,1 2.5000,2.5000 v3.0000 a2.5000,2.5000 0 0,1 -2.5000,2.5000 h-27.0000 a2.5000,2.5000 0 0,1 -2.5000,-2.5000 v-3.0000 a2.5000,2.5000 0 0,1 2.5000,-2.5000 z\" fill=\"#4a525e\"/><path d=\"M45.0000,72.0000 L45.0000,79.0000\" fill=\"none\" stroke=\"#c59b5f\" stroke-width=\"2.4\" stroke-linecap=\"round\"/><path d=\"M54.0000,72.0000 L54.0000,80.0000\" fill=\"none\" stroke=\"#c59b5f\" stroke-width=\"2.4\" stroke-linecap=\"round\"/><path d=\"M63.0000,72.0000 L63.0000,79.0000\" fill=\"none\" stroke=\"#c59b5f\" stroke-width=\"2.4\" stroke-linecap=\"round\"/></svg>"},{"id":"studio_fader","name":"调音台 · 三轨推子","bg":"#1C2127","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M36.0000,28.0000 L36.0000,80.0000\" fill=\"none\" stroke=\"#36404a\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M54.0000,28.0000 L54.0000,80.0000\" fill=\"none\" stroke=\"#36404a\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M72.0000,28.0000 L72.0000,80.0000\" fill=\"none\" stroke=\"#36404a\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M32.5000,54.0000 h7.0000 a2.5000,2.5000 0 0,1 2.5000,2.5000 v9.0000 a2.5000,2.5000 0 0,1 -2.5000,2.5000 h-7.0000 a2.5000,2.5000 0 0,1 -2.5000,-2.5000 v-9.0000 a2.5000,2.5000 0 0,1 2.5000,-2.5000 z\" fill=\"#e6edf3\"/><path d=\"M32.0000,61.0000 L40.0000,61.0000\" fill=\"none\" stroke=\"#1c2127\" stroke-width=\"1.8\"/><path d=\"M50.5000,34.0000 h7.0000 a2.5000,2.5000 0 0,1 2.5000,2.5000 v9.0000 a2.5000,2.5000 0 0,1 -2.5000,2.5000 h-7.0000 a2.5000,2.5000 0 0,1 -2.5000,-2.5000 v-9.0000 a2.5000,2.5000 0 0,1 2.5000,-2.5000 z\" fill=\"#f46036\"/><path d=\"M50.0000,41.0000 L58.0000,41.0000\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"1.8\"/><path d=\"M68.5000,46.0000 h7.0000 a2.5000,2.5000 0 0,1 2.5000,2.5000 v9.0000 a2.5000,2.5000 0 0,1 -2.5000,2.5000 h-7.0000 a2.5000,2.5000 0 0,1 -2.5000,-2.5000 v-9.0000 a2.5000,2.5000 0 0,1 2.5000,-2.5000 z\" fill=\"#38bdf8\"/><path d=\"M68.0000,53.0000 L76.0000,53.0000\" fill=\"none\" stroke=\"#1c2127\" stroke-width=\"1.8\"/></svg>"},{"id":"hifi_headphones","name":"监听耳机 · 声学架构","bg":"#162032","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M29 53 A25 25 0 0 1 79 53\" fill=\"none\" stroke=\"#f0eae1\" stroke-width=\"5.5\" stroke-linecap=\"round\"/><path d=\"M36 42 A19 19 0 0 1 72 42\" fill=\"none\" stroke=\"#e0a96d\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M28.5000,48.0000 h1.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v4.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-1.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-4.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#e0a96d\"/><path d=\"M78.5000,48.0000 h1.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v4.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-1.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-4.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#e0a96d\"/><path d=\"M29.0000,53.0000 h0.0000 a6.0000,6.0000 0 0,1 6.0000,6.0000 v10.0000 a6.0000,6.0000 0 0,1 -6.0000,6.0000 h-0.0000 a6.0000,6.0000 0 0,1 -6.0000,-6.0000 v-10.0000 a6.0000,6.0000 0 0,1 6.0000,-6.0000 z\" fill=\"#2a3a54\" stroke=\"#f0eae1\" stroke-width=\"2.2\"/><path d=\"M79.0000,53.0000 h0.0000 a6.0000,6.0000 0 0,1 6.0000,6.0000 v10.0000 a6.0000,6.0000 0 0,1 -6.0000,6.0000 h-0.0000 a6.0000,6.0000 0 0,1 -6.0000,-6.0000 v-10.0000 a6.0000,6.0000 0 0,1 6.0000,-6.0000 z\" fill=\"#2a3a54\" stroke=\"#f0eae1\" stroke-width=\"2.2\"/><path d=\"M34.7500,56.0000 h0.0000 a1.7500,1.7500 0 0,1 1.7500,1.7500 v12.5000 a1.7500,1.7500 0 0,1 -1.7500,1.7500 h-0.0000 a1.7500,1.7500 0 0,1 -1.7500,-1.7500 v-12.5000 a1.7500,1.7500 0 0,1 1.7500,-1.7500 z\" fill=\"#e0a96d\"/><path d=\"M73.2500,56.0000 h0.0000 a1.7500,1.7500 0 0,1 1.7500,1.7500 v12.5000 a1.7500,1.7500 0 0,1 -1.7500,1.7500 h-0.0000 a1.7500,1.7500 0 0,1 -1.7500,-1.7500 v-12.5000 a1.7500,1.7500 0 0,1 1.7500,-1.7500 z\" fill=\"#e0a96d\"/><path d=\"M26.8000,64.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#f0eae1\" fill-opacity=\"0.6\"/><path d=\"M76.8000,64.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#f0eae1\" fill-opacity=\"0.6\"/></svg>"},{"id":"speaker_driver","name":"发烧音箱 · 同轴单元","bg":"#202022","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M36.0000,24.0000 h36.0000 a12.0000,12.0000 0 0,1 12.0000,12.0000 v36.0000 a12.0000,12.0000 0 0,1 -12.0000,12.0000 h-36.0000 a12.0000,12.0000 0 0,1 -12.0000,-12.0000 v-36.0000 a12.0000,12.0000 0 0,1 12.0000,-12.0000 z\" fill=\"#2b2b2e\" stroke=\"#48484d\" stroke-width=\"1.8\"/><path d=\"M32.0000,54.0000 a22.0000,22.0000 0 1,0 44.0000,0 a22.0000,22.0000 0 1,0 -44.0000,0 Z\" fill=\"#18181a\" stroke=\"#52525b\" stroke-width=\"2.5\"/><path d=\"M40.0000,54.0000 a14.0000,14.0000 0 1,0 28.0000,0 a14.0000,14.0000 0 1,0 -28.0000,0 Z\" fill=\"none\" stroke=\"#3f3f46\" stroke-width=\"2\"/><path d=\"M46.5000,54.0000 a7.5000,7.5000 0 1,0 15.0000,0 a7.5000,7.5000 0 1,0 -15.0000,0 Z\" fill=\"#d48c54\"/><path d=\"M51.2000,54.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#18181a\"/><path d=\"M29.2000,31.0000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#71717a\"/><path d=\"M75.2000,31.0000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#71717a\"/><path d=\"M29.2000,77.0000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#71717a\"/><path d=\"M75.2000,77.0000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#71717a\"/></svg>"},{"id":"aurora_wave","name":"极光声波 · 流体渐变","bg":"#090D16","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i13g3\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"0.00\"><stop offset=\"0.00\" stop-color=\"#22d3ee\"/><stop offset=\"0.50\" stop-color=\"#a855f7\"/><stop offset=\"1.00\" stop-color=\"#ec4899\"/></linearGradient><linearGradient id=\"i13g4\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"0.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\" stop-opacity=\"0.4\"/><stop offset=\"1.00\" stop-color=\"#f472b6\" stop-opacity=\"0.698\"/></linearGradient></defs><path d=\"M22 54 C32 28, 44 28, 54 54 C64 80, 76 80, 86 54\" fill=\"none\" stroke=\"url(#i13g3)\" stroke-width=\"5.5\" stroke-linecap=\"round\"/><path d=\"M22 54 C34 74, 46 34, 54 54 C62 74, 74 34, 86 54\" fill=\"none\" stroke=\"url(#i13g4)\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M50.5000,54.0000 a3.5000,3.5000 0 1,0 7.0000,0 a3.5000,3.5000 0 1,0 -7.0000,0 Z\" fill=\"#f8fafc\"/></svg>"},{"id":"synth_grid","name":"合成器 · 脉冲矩阵","bg":"#120B24","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i14g5\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#ffe66d\"/><stop offset=\"1.00\" stop-color=\"#ff3d8b\"/></linearGradient></defs><path d=\"M30 56 A24 24 0 0 1 78 56 Z\" fill=\"url(#i14g5)\"/><path d=\"M26.0000,45.0000 h56.0000 v2.5000 h-56.0000 z\" fill=\"#120b24\"/><path d=\"M26.0000,51.0000 h56.0000 v3.0000 h-56.0000 z\" fill=\"#120b24\"/><path d=\"M26 64 L38 64 L43 52 L50 74 L58 46 L65 68 L70 64 L82 64\" fill=\"none\" stroke=\"#00f5d4\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>"},{"id":"midnight_gold","name":"午夜鎏金 · 黑胶徽章","bg":"#0B0B0D","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i15g6\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#fce6a6\"/><stop offset=\"0.50\" stop-color=\"#d4a24c\"/><stop offset=\"1.00\" stop-color=\"#9a6b22\"/></linearGradient><linearGradient id=\"i15g7\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#fce6a6\"/><stop offset=\"0.50\" stop-color=\"#d4a24c\"/><stop offset=\"1.00\" stop-color=\"#9a6b22\"/></linearGradient><linearGradient id=\"i15g8\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#fce6a6\"/><stop offset=\"0.50\" stop-color=\"#d4a24c\"/><stop offset=\"1.00\" stop-color=\"#9a6b22\"/></linearGradient></defs><path d=\"M26.0000,54.0000 a28.0000,28.0000 0 1,0 56.0000,0 a28.0000,28.0000 0 1,0 -56.0000,0 Z\" fill=\"none\" stroke=\"url(#i15g6)\" stroke-width=\"4\"/><path d=\"M33.0000,54.0000 a21.0000,21.0000 0 1,0 42.0000,0 a21.0000,21.0000 0 1,0 -42.0000,0 Z\" fill=\"none\" stroke=\"url(#i15g7)\" stroke-width=\"1.2\" stroke-opacity=\"0.6\"/><path d=\"M47.0000,41.0000 L68.0000,54.0000 L47.0000,67.0000 Z\" fill=\"url(#i15g8)\"/></svg>"},{"id":"spatial_sonar","name":"空间音频 · 声呐脉冲","bg":"#071A1D","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M20.0000,58.0000 a28.0000,28.0000 0 1,0 56.0000,0 a28.0000,28.0000 0 1,0 -56.0000,0 Z\" fill=\"none\" stroke=\"#2dd4bf\" stroke-width=\"1.8\" stroke-opacity=\"0.25\"/><path d=\"M29.0000,56.0000 a21.0000,21.0000 0 1,0 42.0000,0 a21.0000,21.0000 0 1,0 -42.0000,0 Z\" fill=\"none\" stroke=\"#2dd4bf\" stroke-width=\"2.2\" stroke-opacity=\"0.45\"/><path d=\"M38.0000,54.0000 a14.0000,14.0000 0 1,0 28.0000,0 a14.0000,14.0000 0 1,0 -28.0000,0 Z\" fill=\"none\" stroke=\"#5eead4\" stroke-width=\"2.6\" stroke-opacity=\"0.75\"/><path d=\"M47.5000,52.0000 a6.5000,6.5000 0 1,0 13.0000,0 a6.5000,6.5000 0 1,0 -13.0000,0 Z\" fill=\"#99f6e4\"/><path d=\"M54 52 L74 32\" fill=\"none\" stroke=\"#99f6e4\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M71.2000,32.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#2dd4bf\"/></svg>"},{"id":"cyber_eq","name":"赛博频谱 · 峰值跃动","bg":"#140E1C","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i17g9\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient><linearGradient id=\"i17g10\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient><linearGradient id=\"i17g11\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient><linearGradient id=\"i17g12\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient><linearGradient id=\"i17g13\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient><linearGradient id=\"i17g14\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#f43f5e\"/></linearGradient></defs><path d=\"M24.0000,71.0000 L84.0000,71.0000\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"1.4\" stroke-opacity=\"0.35\"/><path d=\"M29.0000,54.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v11.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-11.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g9)\"/><path d=\"M39.0000,42.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v23.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-23.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g10)\"/><path d=\"M49.0000,34.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v31.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-31.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g11)\"/><path d=\"M59.0000,46.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v19.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-19.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g12)\"/><path d=\"M69.0000,38.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v27.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-27.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g13)\"/><path d=\"M79.0000,52.0000 h2.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v13.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-2.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-13.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"url(#i17g14)\"/><path d=\"M28.0000,49.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/><path d=\"M38.0000,37.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/><path d=\"M48.0000,29.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/><path d=\"M58.0000,41.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/><path d=\"M68.0000,33.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/><path d=\"M78.0000,47.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#f8fafc\"/></svg>"},{"id":"gramophone","name":"留声机 · 晨曦铜号","bg":"#F5EBE0","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M45 55 C45 48, 35 44, 34 33 C34 25, 58 24, 69 32 C76 37, 75 50, 65 53 L49 56 Z\" fill=\"#e09f5a\" stroke=\"#3d2b1f\" stroke-width=\"2\" stroke-linejoin=\"round\"/><g transform=\"translate(64 39) rotate(-22) scale(1 1) translate(-64 -39)\"><path d=\"M57.5000,39.0000 a6.5000,11.5000 0 1,0 13.0000,0 a6.5000,11.5000 0 1,0 -13.0000,0 Z\" fill=\"#b5653a\" stroke=\"#3d2b1f\" stroke-width=\"1.6\"/></g><path d=\"M47 56 C41 59, 40 65, 42 68\" fill=\"none\" stroke=\"#3d2b1f\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M34.5000,67.0000 h29.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v0.5000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-29.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-0.5000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#1f1916\"/><path d=\"M29.0000,70.0000 L74.0000,70.0000 L77.0000,79.0000 L26.0000,79.0000 Z\" fill=\"#3d2b1f\"/><path d=\"M37.0000,73.0000 h29.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v0.2000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-29.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-0.2000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#b5653a\"/></svg>"},{"id":"acoustic_shell","name":"海螺共鸣 · 声学螺旋","bg":"#152824","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M28.0000,54.0000 a26.0000,26.0000 0 1,0 52.0000,0 a26.0000,26.0000 0 1,0 -52.0000,0 Z\" fill=\"#1e3a34\" stroke=\"#e6d5b8\" stroke-width=\"2.4\"/><path d=\"M54 54 C54 47, 62 47, 62 54 C62 63, 47 64, 46 53 C45 40, 67 38, 70 53 C73 69, 44 74, 36 58\" fill=\"none\" stroke=\"#e6d5b8\" stroke-width=\"2.6\" stroke-linecap=\"round\"/><path d=\"M54.0000,28.0000 L54.0000,41.0000\" fill=\"none\" stroke=\"#8ab8a8\" stroke-width=\"1.5\" stroke-opacity=\"0.65\"/><path d=\"M76.0000,42.0000 L65.0000,47.0000\" fill=\"none\" stroke=\"#8ab8a8\" stroke-width=\"1.5\" stroke-opacity=\"0.65\"/><path d=\"M72.0000,71.0000 L62.0000,62.0000\" fill=\"none\" stroke=\"#8ab8a8\" stroke-width=\"1.5\" stroke-opacity=\"0.65\"/><path d=\"M36.0000,71.0000 L45.0000,62.0000\" fill=\"none\" stroke=\"#8ab8a8\" stroke-width=\"1.5\" stroke-opacity=\"0.65\"/><path d=\"M50.5000,54.0000 a3.5000,3.5000 0 1,0 7.0000,0 a3.5000,3.5000 0 1,0 -7.0000,0 Z\" fill=\"#8ab8a8\"/></svg>"},{"id":"kalimba_tines","name":"卡林巴 · 拇指琴键","bg":"#2C1D14","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M43.0000,27.0000 h22.0000 a11.0000,11.0000 0 0,1 11.0000,11.0000 v32.0000 a11.0000,11.0000 0 0,1 -11.0000,11.0000 h-22.0000 a11.0000,11.0000 0 0,1 -11.0000,-11.0000 v-32.0000 a11.0000,11.0000 0 0,1 11.0000,-11.0000 z\" fill=\"#4a3022\" stroke=\"#d9a773\" stroke-width=\"2.2\"/><path d=\"M46.0000,63.0000 a8.0000,8.0000 0 1,0 16.0000,0 a8.0000,8.0000 0 1,0 -16.0000,0 Z\" fill=\"#2c1d14\" stroke=\"#d9a773\" stroke-width=\"1.8\"/><path d=\"M39.0000,34.0000 h30.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v0.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-30.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-0.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"#d9a773\"/><path d=\"M41.0000,34.0000 L41.0000,48.0000\" fill=\"none\" stroke=\"#e8e2d9\" stroke-width=\"2.8\" stroke-linecap=\"round\"/><path d=\"M47.5000,34.0000 L47.5000,52.0000\" fill=\"none\" stroke=\"#e8e2d9\" stroke-width=\"2.8\" stroke-linecap=\"round\"/><path d=\"M54.0000,34.0000 L54.0000,55.0000\" fill=\"none\" stroke=\"#e8e2d9\" stroke-width=\"2.8\" stroke-linecap=\"round\"/><path d=\"M60.5000,34.0000 L60.5000,52.0000\" fill=\"none\" stroke=\"#e8e2d9\" stroke-width=\"2.8\" stroke-linecap=\"round\"/><path d=\"M67.0000,34.0000 L67.0000,48.0000\" fill=\"none\" stroke=\"#e8e2d9\" stroke-width=\"2.8\" stroke-linecap=\"round\"/></svg>"},{"id":"sunset_tape","name":"日落磁带 · 暖阳沙丘","bg":"#F4DFD0","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i21g15\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f4a261\"/><stop offset=\"1.00\" stop-color=\"#e76f51\"/></linearGradient></defs><path d=\"M30.0000,52.0000 a24.0000,24.0000 0 1,0 48.0000,0 a24.0000,24.0000 0 1,0 -48.0000,0 Z\" fill=\"url(#i21g15)\"/><path d=\"M24 62 Q39 50 54 60 T84 56\" fill=\"none\" stroke=\"#264653\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M28 70 Q44 62 58 69 T80 67\" fill=\"none\" stroke=\"#264653\" stroke-width=\"2.6\" stroke-opacity=\"0.65\" stroke-linecap=\"round\"/></svg>"},{"id":"bamboo_flute","name":"竹笛 · 东方清韵","bg":"#182218","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><g transform=\"translate(54 54) rotate(-35) scale(1 1) translate(-54 -54)\"><path d=\"M26.5000,49.5000 h55.0000 a4.5000,4.5000 0 0,1 4.5000,4.5000 v0.0000 a4.5000,4.5000 0 0,1 -4.5000,4.5000 h-55.0000 a4.5000,4.5000 0 0,1 -4.5000,-4.5000 v-0.0000 a4.5000,4.5000 0 0,1 4.5000,-4.5000 z\" fill=\"#9cc5a1\"/><path d=\"M23.5000,49.5000 h61.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v0.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-61.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-0.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#c4dfc7\" fill-opacity=\"0.45\"/><path d=\"M38.0000,48.5000 h0.5000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v9.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-0.5000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-9.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#497353\"/><path d=\"M68.0000,48.5000 h0.5000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v9.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-0.5000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-9.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#497353\"/><path d=\"M44.1000,54.0000 a1.9000,1.9000 0 1,0 3.8000,0 a1.9000,1.9000 0 1,0 -3.8000,0 Z\" fill=\"#182218\"/><path d=\"M50.6000,54.0000 a1.9000,1.9000 0 1,0 3.8000,0 a1.9000,1.9000 0 1,0 -3.8000,0 Z\" fill=\"#182218\"/><path d=\"M57.1000,54.0000 a1.9000,1.9000 0 1,0 3.8000,0 a1.9000,1.9000 0 1,0 -3.8000,0 Z\" fill=\"#182218\"/><path d=\"M26.8000,54.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#e5d3b3\"/></g><g transform=\"translate(73 37) rotate(45) scale(1 1) translate(-73 -37)\"><path d=\"M71.5000,34.0000 h3.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v3.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-3.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-3.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#d95d39\"/></g><path d=\"M73 41 Q76 51 73 61\" fill=\"none\" stroke=\"#d95d39\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M73 41 Q70 51 70 59\" fill=\"none\" stroke=\"#e07a5f\" stroke-width=\"1.6\" stroke-linecap=\"round\"/></svg>"},{"id":"sonance_s","name":"Sonance · 声纹 S 徽章","bg":"#111318","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i23g16\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#6ee7b7\"/><stop offset=\"1.00\" stop-color=\"#3b82f6\"/></linearGradient><linearGradient id=\"i23g17\" gradientUnits=\"userSpaceOnUse\" x1=\"108.00\" y1=\"108.00\" x2=\"0.00\" y2=\"0.00\"><stop offset=\"0.00\" stop-color=\"#38bdf8\"/><stop offset=\"1.00\" stop-color=\"#6366f1\"/></linearGradient></defs><path d=\"M68 35 C68 27, 40 27, 40 39 C40 49, 54 51, 61 55\" fill=\"none\" stroke=\"url(#i23g16)\" stroke-width=\"9.5\" stroke-linecap=\"round\"/><path d=\"M40 73 C40 81, 68 81, 68 69 C68 59, 54 57, 47 53\" fill=\"none\" stroke=\"url(#i23g17)\" stroke-width=\"9.5\" stroke-linecap=\"round\"/><path d=\"M51.0000,54.0000 a3.0000,3.0000 0 1,0 6.0000,0 a3.0000,3.0000 0 1,0 -6.0000,0 Z\" fill=\"#ffffff\" fill-opacity=\"0.9\"/></svg>"},{"id":"mobius_loop","name":"莫比乌斯 · 无限循环","bg":"#1A1826","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i24g18\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"0.00\"><stop offset=\"0.00\" stop-color=\"#c084fc\"/><stop offset=\"1.00\" stop-color=\"#f472b6\"/></linearGradient></defs><path d=\"M35 42 C24 42, 24 66, 35 66 C45 66, 51 58, 54 54 C57 50, 63 42, 73 42 C84 42, 84 66, 73 66 C63 66, 57 58, 54 54\" fill=\"none\" stroke=\"#7e22ce\" stroke-width=\"7.5\" stroke-linecap=\"round\"/><path d=\"M54 54 C51 50, 45 42, 35 42 C24 42, 24 66, 35 66 C45 66, 51 58, 54 54 C57 50, 63 42, 73 42 C84 42, 84 66, 73 66\" fill=\"none\" stroke=\"url(#i24g18)\" stroke-width=\"6.5\" stroke-linecap=\"round\"/></svg>"},{"id":"dot_matrix","name":"点阵声场 · 像素律动","bg":"#0F172A","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M51.8000,30.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#818cf8\"/><path d=\"M39.2000,42.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#818cf8\"/><path d=\"M49.8000,42.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"#38bdf8\"/><path d=\"M63.2000,42.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#818cf8\"/><path d=\"M27.8000,54.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#818cf8\"/><path d=\"M37.8000,54.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"#38bdf8\"/><path d=\"M48.5000,54.0000 a5.5000,5.5000 0 1,0 11.0000,0 a5.5000,5.5000 0 1,0 -11.0000,0 Z\" fill=\"#f8fafc\"/><path d=\"M61.8000,54.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"#38bdf8\"/><path d=\"M75.8000,54.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#818cf8\"/><path d=\"M39.2000,66.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#818cf8\"/><path d=\"M49.8000,66.0000 a4.2000,4.2000 0 1,0 8.4000,0 a4.2000,4.2000 0 1,0 -8.4000,0 Z\" fill=\"#38bdf8\"/><path d=\"M63.2000,66.0000 a2.8000,2.8000 0 1,0 5.6000,0 a2.8000,2.8000 0 1,0 -5.6000,0 Z\" fill=\"#818cf8\"/><path d=\"M51.8000,78.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#818cf8\"/></svg>"},{"id":"acoustic_prism","name":"声学棱镜 · 折射音束","bg":"#121214","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M22.0000,62.0000 L43.0000,52.0000\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M63.0000,48.0000 L86.0000,42.0000\" fill=\"none\" stroke=\"#f43f5e\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M65.0000,53.0000 L86.0000,54.0000\" fill=\"none\" stroke=\"#fbbf24\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M67.0000,58.0000 L86.0000,66.0000\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M54.0000,29.0000 L76.0000,71.0000 L32.0000,71.0000 Z\" fill=\"#ffffff\" fill-opacity=\"0.1\" stroke=\"#e4e4e7\" stroke-width=\"2.6\" stroke-linejoin=\"round\"/></svg>"},{"id":"stereo_wings","name":"双声道 · 蝴蝶振翅","bg":"#24101C","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M52 53 C45 32, 24 27, 26 46 C27 57, 43 58, 52 55 Z\" fill=\"#fda4af\"/><path d=\"M56 53 C63 32, 84 27, 82 46 C81 57, 65 58, 56 55 Z\" fill=\"#fb7185\"/><path d=\"M52 57 C43 60, 32 74, 41 77 C48 79, 51 67, 52 57 Z\" fill=\"#fb7185\" fill-opacity=\"0.85\"/><path d=\"M56 57 C65 60, 76 74, 67 77 C60 79, 57 67, 56 57 Z\" fill=\"#fda4af\" fill-opacity=\"0.85\"/><path d=\"M46 49 C40 42, 33 41, 33 47\" fill=\"none\" stroke=\"#24101c\" stroke-width=\"1.5\" stroke-opacity=\"0.45\" stroke-linecap=\"round\"/><path d=\"M62 49 C68 42, 75 41, 75 47\" fill=\"none\" stroke=\"#24101c\" stroke-width=\"1.5\" stroke-opacity=\"0.45\" stroke-linecap=\"round\"/><path d=\"M54.0000,36.0000 L54.0000,75.0000\" fill=\"none\" stroke=\"#fff1f2\" stroke-width=\"2.4\" stroke-linecap=\"round\"/><path d=\"M51.8000,36.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#fff1f2\"/></svg>"},{"id":"mint_vinyl","name":"薄荷黑胶 · 清新唱片","bg":"#DFF2EA","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M26.0000,54.0000 a28.0000,28.0000 0 1,0 56.0000,0 a28.0000,28.0000 0 1,0 -56.0000,0 Z\" fill=\"#1d4e42\"/><path d=\"M33.0000,54.0000 a21.0000,21.0000 0 1,0 42.0000,0 a21.0000,21.0000 0 1,0 -42.0000,0 Z\" fill=\"none\" stroke=\"#2d6a5b\" stroke-width=\"1.5\"/><path d=\"M43.5000,54.0000 a10.5000,10.5000 0 1,0 21.0000,0 a10.5000,10.5000 0 1,0 -21.0000,0 Z\" fill=\"#ff8a7a\"/><path d=\"M51.0000,54.0000 a3.0000,3.0000 0 1,0 6.0000,0 a3.0000,3.0000 0 1,0 -6.0000,0 Z\" fill=\"#dff2ea\"/><path d=\"M34 40 A23 23 0 0 1 54 31\" fill=\"none\" stroke=\"#a7e3ce\" stroke-width=\"2\" stroke-opacity=\"0.7\" stroke-linecap=\"round\"/></svg>"},{"id":"lavender_note","name":"薰衣草 · 灵动双音符","bg":"#EAE4F7","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M44 63 L44 35 L70 30 L70 58\" fill=\"none\" stroke=\"#5b4296\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M44.0000,43.0000 L70.0000,38.0000\" fill=\"none\" stroke=\"#a78bfa\" stroke-width=\"4\" stroke-linecap=\"round\"/><g transform=\"translate(38 65) rotate(-18) scale(1 1) translate(-38 -65)\"><path d=\"M29.5000,65.0000 a8.5000,6.5000 0 1,0 17.0000,0 a8.5000,6.5000 0 1,0 -17.0000,0 Z\" fill=\"#5b4296\"/></g><g transform=\"translate(64 60) rotate(-18) scale(1 1) translate(-64 -60)\"><path d=\"M55.5000,60.0000 a8.5000,6.5000 0 1,0 17.0000,0 a8.5000,6.5000 0 1,0 -17.0000,0 Z\" fill=\"#5b4296\"/></g><path d=\"M33.7000,63.5000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#eae4f7\"/><path d=\"M59.7000,58.5000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#eae4f7\"/></svg>"},{"id":"coral_wave","name":"珊瑚暖波 · 柔光律动","bg":"#FCE8E4","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i30g19\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f7a072\"/><stop offset=\"1.00\" stop-color=\"#e86a58\"/></linearGradient><linearGradient id=\"i30g20\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f7a072\"/><stop offset=\"1.00\" stop-color=\"#e86a58\"/></linearGradient><linearGradient id=\"i30g21\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f7a072\"/><stop offset=\"1.00\" stop-color=\"#e86a58\"/></linearGradient><linearGradient id=\"i30g22\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"0.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#f7a072\"/><stop offset=\"1.00\" stop-color=\"#e86a58\"/></linearGradient></defs><path d=\"M32.0000,45.0000 h0.0000 a4.0000,4.0000 0 0,1 4.0000,4.0000 v10.0000 a4.0000,4.0000 0 0,1 -4.0000,4.0000 h-0.0000 a4.0000,4.0000 0 0,1 -4.0000,-4.0000 v-10.0000 a4.0000,4.0000 0 0,1 4.0000,-4.0000 z\" fill=\"url(#i30g19)\" fill-opacity=\"0.7\"/><path d=\"M44.0000,34.0000 h0.0000 a4.0000,4.0000 0 0,1 4.0000,4.0000 v32.0000 a4.0000,4.0000 0 0,1 -4.0000,4.0000 h-0.0000 a4.0000,4.0000 0 0,1 -4.0000,-4.0000 v-32.0000 a4.0000,4.0000 0 0,1 4.0000,-4.0000 z\" fill=\"url(#i30g20)\"/><path d=\"M56.0000,28.0000 h0.0000 a4.0000,4.0000 0 0,1 4.0000,4.0000 v44.0000 a4.0000,4.0000 0 0,1 -4.0000,4.0000 h-0.0000 a4.0000,4.0000 0 0,1 -4.0000,-4.0000 v-44.0000 a4.0000,4.0000 0 0,1 4.0000,-4.0000 z\" fill=\"#d94f3d\"/><path d=\"M68.0000,38.0000 h0.0000 a4.0000,4.0000 0 0,1 4.0000,4.0000 v24.0000 a4.0000,4.0000 0 0,1 -4.0000,4.0000 h-0.0000 a4.0000,4.0000 0 0,1 -4.0000,-4.0000 v-24.0000 a4.0000,4.0000 0 0,1 4.0000,-4.0000 z\" fill=\"url(#i30g21)\"/><path d=\"M80.0000,47.0000 h0.0000 a4.0000,4.0000 0 0,1 4.0000,4.0000 v6.0000 a4.0000,4.0000 0 0,1 -4.0000,4.0000 h-0.0000 a4.0000,4.0000 0 0,1 -4.0000,-4.0000 v-6.0000 a4.0000,4.0000 0 0,1 4.0000,-4.0000 z\" fill=\"url(#i30g22)\" fill-opacity=\"0.7\"/></svg>"},{"id":"sky_cloudphone","name":"晴空云朵 · 轻盈漫步","bg":"#E3F0FA","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M34 67 H72 A11 11 0 0 0 74 46 A15 15 0 0 0 46 40 A13 13 0 0 0 34 67 Z\" fill=\"#ffffff\" stroke=\"#93c5fd\" stroke-width=\"2\"/><path d=\"M51 59 L51 44 L61 42\" fill=\"none\" stroke=\"#2563eb\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M44.2000,59.0000 a3.8000,3.8000 0 1,0 7.6000,0 a3.8000,3.8000 0 1,0 -7.6000,0 Z\" fill=\"#2563eb\"/></svg>"},{"id":"lemon_disc","name":"柑橘光盘 · 闪耀 CD","bg":"#FFF5D6","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M27.0000,54.0000 a27.0000,27.0000 0 1,0 54.0000,0 a27.0000,27.0000 0 1,0 -54.0000,0 Z\" fill=\"#ffffff\" stroke=\"#f59e0b\" stroke-width=\"2\"/><path d=\"M54 54 L35 35 A27 27 0 0 1 65 29 Z\" fill=\"#ec4899\" fill-opacity=\"0.28\"/><path d=\"M54 54 L73 73 A27 27 0 0 1 43 79 Z\" fill=\"#38bdf8\" fill-opacity=\"0.28\"/><path d=\"M44.5000,54.0000 a9.5000,9.5000 0 1,0 19.0000,0 a9.5000,9.5000 0 1,0 -19.0000,0 Z\" fill=\"#fde68a\" stroke=\"#f59e0b\" stroke-width=\"1.5\"/><path d=\"M50.0000,54.0000 a4.0000,4.0000 0 1,0 8.0000,0 a4.0000,4.0000 0 1,0 -8.0000,0 Z\" fill=\"#fff5d6\"/></svg>"},{"id":"saturn_ring","name":"土星环 · 星际漫游","bg":"#0B1021","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><linearGradient id=\"i33g23\" gradientUnits=\"userSpaceOnUse\" x1=\"0.00\" y1=\"0.00\" x2=\"108.00\" y2=\"108.00\"><stop offset=\"0.00\" stop-color=\"#fde68a\"/><stop offset=\"0.55\" stop-color=\"#fb923c\"/><stop offset=\"1.00\" stop-color=\"#db2777\"/></linearGradient></defs><g transform=\"translate(54 54) rotate(-24) scale(1 1) translate(-54 -54)\"><path d=\"M23.0000,54.0000 a31.0000,9.0000 0 1,0 62.0000,0 a31.0000,9.0000 0 1,0 -62.0000,0 Z\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"2.6\" stroke-opacity=\"0.45\"/></g><path d=\"M37.0000,54.0000 a17.0000,17.0000 0 1,0 34.0000,0 a17.0000,17.0000 0 1,0 -34.0000,0 Z\" fill=\"url(#i33g23)\"/><path d=\"M25 67 A31 9 -24 0 0 83 41\" fill=\"none\" stroke=\"#bae6fd\" stroke-width=\"3.2\" stroke-linecap=\"round\"/><path d=\"M72.0000,31.0000 a3.0000,3.0000 0 1,0 6.0000,0 a3.0000,3.0000 0 1,0 -6.0000,0 Z\" fill=\"#fde68a\"/><path d=\"M29.5000,35.0000 a1.5000,1.5000 0 1,0 3.0000,0 a1.5000,1.5000 0 1,0 -3.0000,0 Z\" fill=\"#ffffff\" fill-opacity=\"0.7\"/></svg>"},{"id":"crescent_cat","name":"月夜猫影 · 静谧窗台","bg":"#181A2F","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M64 28 A26 26 0 1 0 77 71 A21 21 0 1 1 64 28 Z\" fill=\"#fde047\"/><path d=\"M46 71 C43 62, 46 53, 50 50 L49 43 L53 46.5 L57 43 L56 50 C60 53, 62 62, 59 71 Z\" fill=\"#0f101e\"/><path d=\"M50.0000,50.0000 a1.0000,1.0000 0 1,0 2.0000,0 a1.0000,1.0000 0 1,0 -2.0000,0 Z\" fill=\"#fde047\"/><path d=\"M54.0000,50.0000 a1.0000,1.0000 0 1,0 2.0000,0 a1.0000,1.0000 0 1,0 -2.0000,0 Z\" fill=\"#fde047\"/><path d=\"M59 69 Q67 66 66 57\" fill=\"none\" stroke=\"#0f101e\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><path d=\"M69.2000,34.0000 a1.8000,1.8000 0 1,0 3.6000,0 a1.8000,1.8000 0 1,0 -3.6000,0 Z\" fill=\"#fde047\"/><path d=\"M30.7000,39.0000 a1.3000,1.3000 0 1,0 2.6000,0 a1.3000,1.3000 0 1,0 -2.6000,0 Z\" fill=\"#ffffff\" fill-opacity=\"0.65\"/></svg>"},{"id":"paper_plane","name":"折纸飞船 · 逆风启航","bg":"#E0F2FE","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M24,72 L28,69.5 M32,66.5 L36,63.5 M39,60.5 L42,58\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"2.4\" stroke-linecap=\"round\"/><path d=\"M78.0000,30.0000 L28.0000,48.0000 L48.0000,57.0000 Z\" fill=\"#ffffff\" stroke=\"#0284c7\" stroke-width=\"2\" stroke-linejoin=\"round\"/><path d=\"M78.0000,30.0000 L48.0000,57.0000 L56.0000,74.0000 Z\" fill=\"#bae6fd\" stroke=\"#0284c7\" stroke-width=\"2\" stroke-linejoin=\"round\"/><path d=\"M48.0000,57.0000 L56.0000,74.0000 L60.0000,61.0000 Z\" fill=\"#0284c7\"/></svg>"},{"id":"origami_crane","name":"千纸鹤 · 几何折纸","bg":"#FDF2F8","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M54.0000,53.0000 L24.0000,36.0000 L46.0000,60.0000 Z\" fill=\"#f472b6\"/><path d=\"M54.0000,53.0000 L82.0000,34.0000 L62.0000,60.0000 Z\" fill=\"#fbcfe8\"/><path d=\"M46.0000,60.0000 L62.0000,60.0000 L54.0000,73.0000 Z\" fill=\"#db2777\"/><path d=\"M62.0000,60.0000 L72.0000,46.0000 L76.0000,47.0000 L66.0000,61.0000 Z\" fill=\"#be185d\"/><path d=\"M72.0000,46.0000 L79.0000,48.0000 L75.0000,50.0000 Z\" fill=\"#db2777\"/><path d=\"M46.0000,60.0000 L32.0000,74.0000 L42.0000,67.0000 Z\" fill=\"#be185d\"/></svg>"},{"id":"crystal_hourglass","name":"星沙漏 · 时间胶囊","bg":"#1C1427","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M36.0000,28.0000 L72.0000,28.0000\" fill=\"none\" stroke=\"#e9d5ff\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M36.0000,80.0000 L72.0000,80.0000\" fill=\"none\" stroke=\"#e9d5ff\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M40 28 C40 46, 52 50, 52 54 C52 58, 40 62, 40 80\" fill=\"none\" stroke=\"#c084fc\" stroke-width=\"2.4\"/><path d=\"M68 28 C68 46, 56 50, 56 54 C56 58, 68 62, 68 80\" fill=\"none\" stroke=\"#c084fc\" stroke-width=\"2.4\"/><path d=\"M44.0000,38.0000 L64.0000,38.0000 L54.0000,50.0000 Z\" fill=\"#fbbf24\" fill-opacity=\"0.85\"/><path d=\"M43.0000,78.0000 L65.0000,78.0000 L54.0000,67.0000 Z\" fill=\"#fbbf24\"/><path d=\"M52.5000,58.0000 a1.5000,1.5000 0 1,0 3.0000,0 a1.5000,1.5000 0 1,0 -3.0000,0 Z\" fill=\"#fde68a\"/><path d=\"M52.5000,63.0000 a1.5000,1.5000 0 1,0 3.0000,0 a1.5000,1.5000 0 1,0 -3.0000,0 Z\" fill=\"#fde68a\"/></svg>"},{"id":"nebula_portal","name":"虫洞 · 折叠时空","bg":"#090910","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><g transform=\"translate(54 54) rotate(30) scale(1 1) translate(-54 -54)\"><path d=\"M26.0000,54.0000 a28.0000,15.0000 0 1,0 56.0000,0 a28.0000,15.0000 0 1,0 -56.0000,0 Z\" fill=\"none\" stroke=\"#8b5cf6\" stroke-width=\"3.2\" stroke-opacity=\"0.75\"/></g><g transform=\"translate(54 54) rotate(-30) scale(1 1) translate(-54 -54)\"><path d=\"M26.0000,54.0000 a28.0000,15.0000 0 1,0 56.0000,0 a28.0000,15.0000 0 1,0 -56.0000,0 Z\" fill=\"none\" stroke=\"#06b6d4\" stroke-width=\"3.2\" stroke-opacity=\"0.75\"/></g><g transform=\"translate(54 54) rotate(90) scale(1 1) translate(-54 -54)\"><path d=\"M26.0000,54.0000 a28.0000,15.0000 0 1,0 56.0000,0 a28.0000,15.0000 0 1,0 -56.0000,0 Z\" fill=\"none\" stroke=\"#a78bfa\" stroke-width=\"2.2\" stroke-opacity=\"0.5\"/></g><path d=\"M49.0000,54.0000 a5.0000,5.0000 0 1,0 10.0000,0 a5.0000,5.0000 0 1,0 -10.0000,0 Z\" fill=\"#f8fafc\"/></svg>"},{"id":"compass_star","name":"北极星 · 航海罗盘","bg":"#132226","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M27.0000,54.0000 a27.0000,27.0000 0 1,0 54.0000,0 a27.0000,27.0000 0 1,0 -54.0000,0 Z\" fill=\"none\" stroke=\"#e2c07d\" stroke-width=\"2\" stroke-opacity=\"0.65\"/><path d=\"M54.0000,24.0000 L60.0000,48.0000 L84.0000,54.0000 L60.0000,60.0000 L54.0000,84.0000 L48.0000,60.0000 L24.0000,54.0000 L48.0000,48.0000 Z\" fill=\"#e2c07d\"/><path d=\"M54.0000,24.0000 L60.0000,48.0000 L54.0000,54.0000 L48.0000,48.0000 Z\" fill=\"#dc2626\"/><path d=\"M54.0000,84.0000 L48.0000,60.0000 L54.0000,54.0000 L60.0000,60.0000 Z\" fill=\"#f8fafc\"/><path d=\"M50.5000,54.0000 a3.5000,3.5000 0 1,0 7.0000,0 a3.5000,3.5000 0 1,0 -7.0000,0 Z\" fill=\"#132226\"/></svg>"},{"id":"fuji_mist","name":"雪顶山峦 · 晨雾微光","bg":"#ECE7DF","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M58.5000,36.0000 a9.5000,9.5000 0 1,0 19.0000,0 a9.5000,9.5000 0 1,0 -19.0000,0 Z\" fill=\"#d94e34\"/><path d=\"M23 73 L46 38 L58 38 L85 73 Z\" fill=\"#2b4162\"/><path d=\"M46 38 L58 38 L65 48 L59 46 L54 51 L49 46 L42 49 Z\" fill=\"#ffffff\"/><path d=\"M24 77 L84 77\" fill=\"none\" stroke=\"#2b4162\" stroke-width=\"2\" stroke-opacity=\"0.35\" stroke-linecap=\"round\"/></svg>"},{"id":"koi_pond","name":"双鲤戏水 · 太极锦鲤","bg":"#0E272A","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M25.0000,54.0000 a29.0000,29.0000 0 1,0 58.0000,0 a29.0000,29.0000 0 1,0 -58.0000,0 Z\" fill=\"none\" stroke=\"#2dd4bf\" stroke-width=\"1.2\" stroke-opacity=\"0.28\"/><path d=\"M33.0000,54.0000 a21.0000,21.0000 0 1,0 42.0000,0 a21.0000,21.0000 0 1,0 -42.0000,0 Z\" fill=\"none\" stroke=\"#2dd4bf\" stroke-width=\"1\" stroke-opacity=\"0.18\"/><path d=\"M35 48 C35 32, 60 28, 66 39 C60 36, 48 40, 45 50 C43 56, 35 55, 35 48 Z\" fill=\"#f97316\"/><path d=\"M35 48 L27 42 L30 52 Z\" fill=\"#fb923c\"/><path d=\"M52 38 L57 31 L59 38 Z\" fill=\"#fb923c\"/><path d=\"M59.8000,37.0000 a1.2000,1.2000 0 1,0 2.4000,0 a1.2000,1.2000 0 1,0 -2.4000,0 Z\" fill=\"#0e272a\"/><path d=\"M73 60 C73 76, 48 80, 42 69 C48 72, 60 68, 63 58 C65 52, 73 53, 73 60 Z\" fill=\"#f8fafc\"/><path d=\"M73 60 L81 66 L78 56 Z\" fill=\"#cbd5e1\"/><path d=\"M56 70 L51 77 L49 70 Z\" fill=\"#cbd5e1\"/><path d=\"M45.8000,71.0000 a1.2000,1.2000 0 1,0 2.4000,0 a1.2000,1.2000 0 1,0 -2.4000,0 Z\" fill=\"#0e272a\"/></svg>"},{"id":"matcha_tea","name":"抹茶碗 · 一期一会","bg":"#F0EDE4","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M29 48 C29 69, 39 76, 54 76 C69 76, 79 69, 79 48 Z\" fill=\"#57534e\"/><path d=\"M33 52 C34 65, 41 72, 50 73\" fill=\"none\" stroke=\"#78716c\" stroke-width=\"1.8\" stroke-linecap=\"round\"/><path d=\"M45.5000,75.0000 h17.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v1.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-17.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-1.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#44403c\"/><path d=\"M29.0000,48.0000 a25.0000,7.5000 0 1,0 50.0000,0 a25.0000,7.5000 0 1,0 -50.0000,0 Z\" fill=\"#4d7c0f\" stroke=\"#78716c\" stroke-width=\"2\"/><path d=\"M38.0000,47.5000 a14.0000,3.5000 0 1,0 28.0000,0 a14.0000,3.5000 0 1,0 -28.0000,0 Z\" fill=\"#84cc16\" fill-opacity=\"0.55\"/><path d=\"M46.8000,47.0000 a1.2000,1.2000 0 1,0 2.4000,0 a1.2000,1.2000 0 1,0 -2.4000,0 Z\" fill=\"#ecfccb\"/><path d=\"M54.0000,48.0000 a1.0000,1.0000 0 1,0 2.0000,0 a1.0000,1.0000 0 1,0 -2.0000,0 Z\" fill=\"#ecfccb\"/><path d=\"M60.0000,45.0000 L77.0000,30.0000\" fill=\"none\" stroke=\"#a16207\" stroke-width=\"2.6\" stroke-linecap=\"round\"/></svg>"},{"id":"paper_lantern","name":"夜灯笼 · 暖光微醺","bg":"#1A1110","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><defs><radialGradient id=\"i43g24\" gradientUnits=\"userSpaceOnUse\" cx=\"54.00\" cy=\"54.00\" r=\"54.00\"><stop offset=\"0.00\" stop-color=\"#fef08a\"/><stop offset=\"0.55\" stop-color=\"#ef4444\"/><stop offset=\"1.00\" stop-color=\"#991b1b\"/></radialGradient></defs><path d=\"M54.0000,24.0000 L54.0000,32.0000\" fill=\"none\" stroke=\"#d6d3d1\" stroke-width=\"2\"/><path d=\"M46.5000,31.0000 h15.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v1.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-15.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-1.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#451a03\"/><path d=\"M35.0000,53.0000 a19.0000,20.0000 0 1,0 38.0000,0 a19.0000,20.0000 0 1,0 -38.0000,0 Z\" fill=\"url(#i43g24)\"/><path d=\"M44.0000,53.0000 a10.0000,20.0000 0 1,0 20.0000,0 a10.0000,20.0000 0 1,0 -20.0000,0 Z\" fill=\"none\" stroke=\"#7f1d1d\" stroke-width=\"1.3\" stroke-opacity=\"0.55\"/><path d=\"M36.0000,47.0000 L72.0000,47.0000\" fill=\"none\" stroke=\"#7f1d1d\" stroke-width=\"1.2\" stroke-opacity=\"0.45\"/><path d=\"M36.0000,59.0000 L72.0000,59.0000\" fill=\"none\" stroke=\"#7f1d1d\" stroke-width=\"1.2\" stroke-opacity=\"0.45\"/><path d=\"M46.5000,71.0000 h15.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v1.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-15.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-1.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#451a03\"/><path d=\"M54.0000,75.0000 L54.0000,83.0000\" fill=\"none\" stroke=\"#fbbf24\" stroke-width=\"2.4\" stroke-linecap=\"round\"/></svg>"},{"id":"torii_gate","name":"朱红鸟居 · 静谧之门","bg":"#F7E8D8","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M26 35 Q54 41 82 35 L80 41 Q54 46 28 41 Z\" fill=\"#c83e2b\"/><path d=\"M34.0000,47.0000 h40.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v2.5000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-40.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-2.5000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#c83e2b\"/><path d=\"M38.0000,40.0000 h5.5000 v33.0000 h-5.5000 z\" fill=\"#c83e2b\"/><path d=\"M64.5000,40.0000 h5.5000 v33.0000 h-5.5000 z\" fill=\"#c83e2b\"/><path d=\"M51.5000,40.0000 h5.0000 v9.0000 h-5.0000 z\" fill=\"#262626\"/><path d=\"M28.0000,76.0000 L80.0000,76.0000\" fill=\"none\" stroke=\"#c83e2b\" stroke-width=\"1.8\" stroke-opacity=\"0.4\" stroke-linecap=\"round\"/></svg>"},{"id":"ink_bamboo","name":"墨竹 · 留白印章","bg":"#F4F1EA","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M42.0000,80.0000 L46.0000,28.0000\" fill=\"none\" stroke=\"#1f3a2e\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M41.0000,54.0000 L48.0000,54.0000\" fill=\"none\" stroke=\"#f4f1ea\" stroke-width=\"1.5\"/><path d=\"M46 42 Q59 35 67 40 Q56 46 46 42 Z\" fill=\"#1f3a2e\"/><path d=\"M44 58 Q31 51 25 56 Q34 62 44 58 Z\" fill=\"#1f3a2e\"/><path d=\"M46 33 Q55 24 63 26 Q54 35 46 33 Z\" fill=\"#2d5a47\"/><path d=\"M66.5000,65.0000 h8.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v8.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-8.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-8.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#c83e2b\"/><path d=\"M68.0000,68.0000 L73.0000,73.0000\" fill=\"none\" stroke=\"#f4f1ea\" stroke-width=\"1.3\"/><path d=\"M73.0000,68.0000 L68.0000,73.0000\" fill=\"none\" stroke=\"#f4f1ea\" stroke-width=\"1.3\"/></svg>"},{"id":"pixel_heart","name":"像素之心 · 8-Bit 脉冲","bg":"#16161D","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M34 36 h12 v6 h16 v-6 h12 v6 h6 v18 h-6 v6 h-6 v6 h-6 v6 h-12 v-6 h-6 v-6 h-6 v-6 h-6 v-18 h6 z\" fill=\"#f43f5e\"/><path d=\"M34.0000,42.0000 h6.0000 v6.0000 h-6.0000 z\" fill=\"#ffffff\" fill-opacity=\"0.85\"/><path d=\"M40.0000,42.0000 h6.0000 v6.0000 h-6.0000 z\" fill=\"#fda4af\"/></svg>"},{"id":"floppy_disk","name":"3.5寸软盘 · 复古记忆","bg":"#1D2B53","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M30 28 H72 L80 36 V78 A2 2 0 0 1 78 80 H30 A2 2 0 0 1 28 78 V30 A2 2 0 0 1 30 28 Z\" fill=\"#3b82f6\"/><path d=\"M39.5000,28.0000 h25.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v16.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-25.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-16.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#e2e8f0\"/><path d=\"M57.0000,31.0000 h4.0000 a1.0000,1.0000 0 0,1 1.0000,1.0000 v11.0000 a1.0000,1.0000 0 0,1 -1.0000,1.0000 h-4.0000 a1.0000,1.0000 0 0,1 -1.0000,-1.0000 v-11.0000 a1.0000,1.0000 0 0,1 1.0000,-1.0000 z\" fill=\"#1d2b53\"/><path d=\"M37.0000,54.0000 h34.0000 a2.0000,2.0000 0 0,1 2.0000,2.0000 v22.0000 a2.0000,2.0000 0 0,1 -2.0000,2.0000 h-34.0000 a2.0000,2.0000 0 0,1 -2.0000,-2.0000 v-22.0000 a2.0000,2.0000 0 0,1 2.0000,-2.0000 z\" fill=\"#f8fafc\"/><path d=\"M35.0000,54.0000 h38.0000 v6.0000 h-38.0000 z\" fill=\"#f59e0b\"/><path d=\"M40.0000,67.0000 L68.0000,67.0000\" fill=\"none\" stroke=\"#cbd5e1\" stroke-width=\"2\"/><path d=\"M40.0000,73.0000 L62.0000,73.0000\" fill=\"none\" stroke=\"#cbd5e1\" stroke-width=\"2\"/></svg>"},{"id":"arcade_ghost","name":"街机幽灵 · 霓虹迷宫","bg":"#0D0D1A","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M32 76 L32 50 A22 22 0 0 1 76 50 L76 76 L68.5 70 L61 76 L54 70 L47 76 L39.5 70 Z\" fill=\"#22d3ee\"/><path d=\"M40.5000,48.0000 a5.5000,5.5000 0 1,0 11.0000,0 a5.5000,5.5000 0 1,0 -11.0000,0 Z\" fill=\"#ffffff\"/><path d=\"M56.5000,48.0000 a5.5000,5.5000 0 1,0 11.0000,0 a5.5000,5.5000 0 1,0 -11.0000,0 Z\" fill=\"#ffffff\"/><path d=\"M45.4000,48.0000 a2.6000,2.6000 0 1,0 5.2000,0 a2.6000,2.6000 0 1,0 -5.2000,0 Z\" fill=\"#1e293b\"/><path d=\"M61.4000,48.0000 a2.6000,2.6000 0 1,0 5.2000,0 a2.6000,2.6000 0 1,0 -5.2000,0 Z\" fill=\"#1e293b\"/></svg>"},{"id":"melting_clock","name":"液态时钟 · 超现实","bg":"#26201B","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M25.0000,53.0000 L83.0000,53.0000\" fill=\"none\" stroke=\"#a16207\" stroke-width=\"3.5\" stroke-linecap=\"round\"/><path d=\"M50.5000,25.0000 h5.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v1.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-5.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-1.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#f3d382\"/><path d=\"M35 37 C35 28, 72 28, 72 39 C72 49, 66 53, 66 72 C66 79, 55 79, 54 69 C53 58, 35 55, 35 37 Z\" fill=\"#fffbeb\" stroke=\"#f3d382\" stroke-width=\"3.2\"/><path d=\"M49.8000,44.0000 a2.2000,2.2000 0 1,0 4.4000,0 a2.2000,2.2000 0 1,0 -4.4000,0 Z\" fill=\"#78350f\"/><path d=\"M52.0000,44.0000 L52.0000,34.0000\" fill=\"none\" stroke=\"#78350f\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M52.0000,44.0000 L61.0000,49.0000\" fill=\"none\" stroke=\"#78350f\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M58.7000,68.0000 a1.3000,1.3000 0 1,0 2.6000,0 a1.3000,1.3000 0 1,0 -2.6000,0 Z\" fill=\"#b45309\"/></svg>"},{"id":"coffee_steam","name":"浓缩咖啡 · 灵感热气","bg":"#F5EBE1","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M33 49 H67 V62 A16 16 0 0 1 33 62 Z\" fill=\"#6f4e37\"/><path d=\"M33.0000,49.0000 a17.0000,4.0000 0 1,0 34.0000,0 a17.0000,4.0000 0 1,0 -34.0000,0 Z\" fill=\"#d4a373\" stroke=\"#6f4e37\" stroke-width=\"2\"/><path d=\"M67 52 H72 A5.5 5.5 0 0 1 72 63 H67\" fill=\"none\" stroke=\"#6f4e37\" stroke-width=\"3.2\"/><path d=\"M28.0000,79.0000 a22.0000,3.2000 0 1,0 44.0000,0 a22.0000,3.2000 0 1,0 -44.0000,0 Z\" fill=\"#d4a373\"/><path d=\"M43 40 Q40 34 44 28\" fill=\"none\" stroke=\"#b08968\" stroke-width=\"2.4\" stroke-linecap=\"round\"/><path d=\"M55 39 Q52 33 56 26\" fill=\"none\" stroke=\"#b08968\" stroke-width=\"2.4\" stroke-linecap=\"round\"/></svg>"},{"id":"rubber_duck","name":"波普小鸭 · 浴室哲学","bg":"#2563EB","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M29 60 C29 53, 39 52, 46 53 C42 46, 44 35, 54 34 C63 33, 68 40, 65 48 C72 51, 75 58, 71 66 C67 73, 29 73, 29 60 Z\" fill=\"#facc15\"/><path d=\"M65 42 L76 44 L65 48 Z\" fill=\"#f97316\"/><path d=\"M54.7000,40.5000 a2.3000,2.3000 0 1,0 4.6000,0 a2.3000,2.3000 0 1,0 -4.6000,0 Z\" fill=\"#1e293b\"/><path d=\"M56.9000,39.8000 a0.8000,0.8000 0 1,0 1.6000,0 a0.8000,0.8000 0 1,0 -1.6000,0 Z\" fill=\"#ffffff\"/><path d=\"M44 58 Q54 63 62 57\" fill=\"none\" stroke=\"#eab308\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M32 76 Q54 80 76 76\" fill=\"none\" stroke=\"#93c5fd\" stroke-width=\"2.2\" stroke-opacity=\"0.75\" stroke-linecap=\"round\"/></svg>"},{"id":"bonsai_tree","name":"悬浮盆景 · 微观生态","bg":"#17201C","svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 108 108\"><path d=\"M36.0000,68.0000 L72.0000,68.0000 L67.0000,79.0000 L41.0000,79.0000 Z\" fill=\"#d6d3d1\"/><path d=\"M35.5000,65.0000 h37.0000 a1.5000,1.5000 0 0,1 1.5000,1.5000 v1.0000 a1.5000,1.5000 0 0,1 -1.5000,1.5000 h-37.0000 a1.5000,1.5000 0 0,1 -1.5000,-1.5000 v-1.0000 a1.5000,1.5000 0 0,1 1.5000,-1.5000 z\" fill=\"#a8a29e\"/><path d=\"M54 65 C55 56, 46 52, 46 46 C46 41, 56 41, 56 35\" fill=\"none\" stroke=\"#a16207\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M52 53 L64 49\" fill=\"none\" stroke=\"#a16207\" stroke-width=\"2.8\" stroke-linecap=\"round\"/><path d=\"M31 46 A8 8 0 0 1 45 43 A8 8 0 0 1 56 46 Z\" fill=\"#22c55e\"/><path d=\"M46 36 A9 9 0 0 1 63 32 A9 9 0 0 1 75 36 Z\" fill=\"#4ade80\"/><path d=\"M56 50 A7 7 0 0 1 73 50 Z\" fill=\"#16a34a\"/></svg>"}];
;
// 音效预设数据：取自 App 的 SoundFxModels.kt（13 套 + 原声）
// 频点与 App 的 EQ_CENTER_FREQS 一一对应
window.SONANCE_EQ = {
  freqs: [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000],
  categories: ['原声', '自然', '耳机', '外放', '空间'],
  presets: [
    { id: 'off', name: '原声', cat: '原声', desc: '不做任何处理，保持原始录音', eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { id: 'extreme_hifi', name: '极致 · Hi-Fi', cat: '自然', desc: '轻量清理 250 Hz 微浊，打开极高频延伸与横向解析力，零混响、零压限', eq: [1.6, 1.2, 0.2, -1.6, -0.4, 0.5, 1.3, 2.0, 2.2, 2.6] },
    { id: 'clear', name: '清晨 · 通透', cat: '自然', desc: '收净 250 Hz 浑浊，9.5 kHz 空气搁架点亮光泽，像揭开一层薄纱', eq: [0.6, 0.8, -0.6, -3.2, -0.8, 0.8, 2.2, 2.8, 2.0, 1.6] },
    { id: 'vocal', name: '人声 · 贴耳', cat: '自然', desc: '退开伴奏低中频掩蔽，保留嗓音厚度，托起唇齿与呼吸', eq: [-1.6, 0.2, 1.6, -3.2, 1.2, 3.2, 4.4, 2.8, 1.0, 0.6] },
    { id: 'bass', name: '低频 · 有弹性', cat: '自然', desc: '90 Hz 宽搁架叠加谐波合成，鼓点像气垫一样有弹性', eq: [0.8, 2.4, 0.8, -3.6, -0.6, 1.0, 1.8, 2.2, 1.2, 0.8] },
    { id: 'night', name: '深夜 · 轻柔', cat: '自然', desc: '小音量等响度曲线，柔化刺耳区，夜里久听不累', eq: [1.0, 1.8, 1.4, 0.4, 0.2, -0.2, -1.8, -2.8, -1.8, -0.6] },
    { id: 'in_ear', name: '入耳 · 柔顺', cat: '耳机', desc: '参考 Hi-Fi 入耳目标曲线：饱满低音，8 kHz 齿音去刺', eq: [1.2, 1.4, 0.0, -2.6, 0.2, 1.6, 2.2, 0.4, -2.2, 1.6] },
    { id: 'over_ear', name: '头戴 · 厅堂', cat: '耳机', desc: '疏通罩腔共振，融合早期反射与宽舒声场，消除头中效应', eq: [1.2, 1.6, 0.4, -2.6, 0.4, 1.6, 2.6, 2.0, 1.2, 1.4] },
    { id: 'phone', name: '手机 · 外放', cat: '外放', desc: '58 Hz 高通防破音，高通前合成谐波低音补足厚度', eq: [-5.0, -1.2, 1.8, 3.4, 4.0, 1.6, -2.0, -1.0, 1.8, 2.2] },
    { id: 'tablet', name: '平板 · 立体', cat: '外放', desc: '多扬声器大音腔调校，142% 宽距环绕与明亮人声', eq: [-2.0, 1.4, 1.8, -1.8, 0.6, 1.6, 2.6, 2.2, 2.0, 1.6] },
    { id: 'car', name: '车载 · 动感', cat: '外放', desc: '穿透胎噪与路噪，清理门板 250 Hz 共振', eq: [1.2, 3.0, 1.4, -3.2, -0.4, 1.6, 2.8, 2.0, 1.4, 1.4] },
    { id: 'live', name: '现场 · 微醺', cat: '空间', desc: '释放鼓点瞬态，还原 Livehouse 舞台宽度与临场感', eq: [1.2, 2.2, 0.8, -2.6, 0.2, 1.2, 2.4, 3.0, 2.0, 1.4] },
    { id: 'panorama', name: '全景 · 环绕', cat: '空间', desc: '低频锚定中心，侧翼大跨度延展，360° 包围感', eq: [1.4, 2.2, 0.6, -2.6, -0.2, 1.0, 2.0, 2.6, 2.4, 1.8] },
    { id: 'cinema', name: '影院 · 宽广', cat: '空间', desc: '巨幕低频氛围与厅堂余韵，保留宏大动态起伏', eq: [2.0, 2.6, 1.2, -2.6, -0.4, 1.0, 2.0, 2.6, 2.0, 1.4] }
  ]
};
;
/* 颜色工具 + 封面取色（复刻 App 的莫兰迪取色思路）
 * - 32×32 降采样，过滤过亮/过暗像素
 * - 36 个色相桶按「饱和度 × 数量」加权取主色
 * - 灰度封面锁饱和度 0（对应 App「黑白封面锁 0」）
 */
(function () {
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  function hexToRgb(hex) {
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h.slice(0, 6), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHex([r, g, b]) {
    return '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  }
  function rgbToHsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h /= 6;
    }
    return [h * 360, s, l];
  }
  function hslToRgb([h, s, l]) {
    h = ((h % 360) + 360) % 360 / 360;
    if (s === 0) return [l * 255, l * 255, l * 255];
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = t => {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
  }

  // OKLab 插值：颜色过渡中间不会发灰
  const toLin = c => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const toSrgb = c => 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);
  function rgbToOklab([r, g, b]) {
    r = toLin(r); g = toLin(g); b = toLin(b);
    const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
    const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
    const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
    return [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
      1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
      0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s];
  }
  function oklabToRgb([L, a, b]) {
    const l = Math.pow(L + 0.3963377774 * a + 0.2158037573 * b, 3);
    const m = Math.pow(L - 0.1055613458 * a - 0.0638541728 * b, 3);
    const s = Math.pow(L - 0.0894841775 * a - 1.2914855480 * b, 3);
    return [toSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
      toSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
      toSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)];
  }
  function mix(hexA, hexB, t) {
    if (t <= 0) return hexA; if (t >= 1) return hexB;
    const A = rgbToOklab(hexToRgb(hexA)), B = rgbToOklab(hexToRgb(hexB));
    return rgbToHex(oklabToRgb([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]));
  }

  /** 明亮晕染用：压饱和、钉亮度 */
  function pastel(hex, l = 0.82, sMax = 0.45) {
    const [h, s] = rgbToHsl(hexToRgb(hex));
    return rgbToHex(hslToRgb([h, Math.min(s, sMax), l]));
  }
  /** 按钮/强调用：加深 */
  function deep(hex, l = 0.42, sMin = 0.25) {
    const [h, s] = rgbToHsl(hexToRgb(hex));
    return rgbToHex(hslToRgb([h, s < 0.06 ? 0 : clamp(Math.max(s, sMin), 0, 0.7), l]));
  }
  function shiftHue(hex, deg) {
    const [h, s, l] = rgbToHsl(hexToRgb(hex));
    return rgbToHex(hslToRgb([h + deg, s, l]));
  }
  function luminance(hex) {
    const [r, g, b] = hexToRgb(hex).map(toLin);
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  /** 从图片提取主色（返回 { main, isGray }） */
  function extract(img) {
    const N = 32;
    const cv = document.createElement('canvas');
    cv.width = cv.height = N;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, N, N);
    const data = ctx.getImageData(0, 0, N, N).data;
    const buckets = Array.from({ length: 36 }, () => ({ w: 0, r: 0, g: 0, b: 0 }));
    let satSum = 0, cnt = 0, fr = 0, fg = 0, fb = 0;
    for (let i = 0; i < data.length; i += 4) {
      const rgb = [data[i], data[i + 1], data[i + 2]];
      const [h, s, l] = rgbToHsl(rgb);
      fr += rgb[0]; fg += rgb[1]; fb += rgb[2];
      if (l > 0.92 || l < 0.08) continue;
      satSum += s; cnt++;
      const bk = buckets[Math.floor(h / 10) % 36];
      const w = s * s + 0.02;
      bk.w += w; bk.r += rgb[0] * w; bk.g += rgb[1] * w; bk.b += rgb[2] * w;
    }
    const total = data.length / 4;
    const avg = [fr / total, fg / total, fb / total];
    if (!cnt || satSum / cnt < 0.08) {
      const [, , l] = rgbToHsl(avg);
      return { main: rgbToHex(hslToRgb([0, 0, l])), isGray: true };
    }
    // 相邻桶合并，避免色相边界把主色劈开
    let best = 0, bestW = -1;
    for (let i = 0; i < 36; i++) {
      const w = buckets[i].w + 0.5 * (buckets[(i + 35) % 36].w + buckets[(i + 1) % 36].w);
      if (w > bestW) { bestW = w; best = i; }
    }
    const b = buckets[best];
    return { main: rgbToHex([b.r / b.w, b.g / b.w, b.b / b.w]), isGray: false };
  }

  window.SColor = { hexToRgb, rgbToHex, rgbToHsl, hslToRgb, mix, pastel, deep, shiftHue, luminance, extract, clamp };
})();
;
/* 界面图标（24×24，圆润填充风格，贴近 App 截图里的 Material Rounded 图标）
 * 用法：HTML 里写 <i data-ic="play"></i>，调用 SIcons.hydrate() 替换为 SVG
 */
(function () {
  const P = {
    play: '<path d="M8 5.6v12.8c0 .8.9 1.3 1.6.9l10-6.4c.6-.4.6-1.4 0-1.8l-10-6.4C8.9 4.3 8 4.8 8 5.6z"/>',
    pause: '<rect x="6.5" y="5" width="4" height="14" rx="1.6"/><rect x="13.5" y="5" width="4" height="14" rx="1.6"/>',
    prev: '<path d="M11.5 7.2v9.6c0 .8-.9 1.2-1.5.7L4.6 13c-.5-.4-.5-1.2 0-1.6L10 6.5c.6-.5 1.5-.1 1.5.7zm8 0v9.6c0 .8-.9 1.2-1.5.7L12.6 13c-.5-.4-.5-1.2 0-1.6L18 6.5c.6-.5 1.5-.1 1.5.7z"/>',
    next: '<path d="M12.5 7.2v9.6c0 .8.9 1.2 1.5.7l5.4-4.5c.5-.4.5-1.2 0-1.6L14 6.5c-.6-.5-1.5-.1-1.5.7zm-8 0v9.6c0 .8.9 1.2 1.5.7l5.4-4.5c.5-.4.5-1.2 0-1.6L6 6.5c-.6-.5-1.5-.1-1.5.7z"/>',
    skipPrev: '<rect x="5" y="6" width="2.4" height="12" rx="1.2"/><path d="M18.5 7v10c0 .8-.9 1.3-1.6.8l-7.3-5c-.6-.4-.6-1.2 0-1.6l7.3-5c.7-.5 1.6 0 1.6.8z"/>',
    skipNext: '<rect x="16.6" y="6" width="2.4" height="12" rx="1.2"/><path d="M5.5 7v10c0 .8.9 1.3 1.6.8l7.3-5c.6-.4.6-1.2 0-1.6l-7.3-5c-.7-.5-1.6 0-1.6.8z"/>',
    shuffle: '<path d="M4 7h2.6c1.3 0 2.5.6 3.3 1.7l4.2 6.6c.8 1.1 2 1.7 3.3 1.7H19" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M4 17h2.6c1.3 0 2.5-.6 3.3-1.7l4.2-6.6c.8-1.1 2-1.7 3.3-1.7H19" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M17.5 4.5 20.5 7l-3 2.5zM17.5 14.5l3 2.5-3 2.5z"/>',
    queue: '<rect x="3.5" y="6" width="11" height="2.2" rx="1.1"/><rect x="3.5" y="11" width="11" height="2.2" rx="1.1"/><rect x="3.5" y="16" width="7" height="2.2" rx="1.1"/><path d="M17 6.5v8.2a2.6 2.6 0 1 0 2 2.5V9h2V6.5z"/>',
    heart: '<path d="M12 20.3 10.6 19C5.6 14.5 2.5 11.7 2.5 8.2 2.5 5.4 4.7 3.3 7.4 3.3c1.6 0 3.1.7 4.1 1.9l.5.6.5-.6c1-1.2 2.5-1.9 4.1-1.9 2.7 0 4.9 2.1 4.9 4.9 0 3.5-3.1 6.3-8.1 10.8z"/>',
    download: '<path d="M12 4v10.2m0 0-4.2-4.2M12 14.2l4.2-4.2" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><rect x="5" y="17.6" width="14" height="2.4" rx="1.2"/>',
    search: '<circle cx="10.5" cy="10.5" r="6" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="m15 15 5 5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
    gear: '<path d="M12 8.6a3.4 3.4 0 1 0 0 6.8 3.4 3.4 0 0 0 0-6.8zm8.2 2.2-1.9-.4a6.6 6.6 0 0 0-.7-1.6l1.1-1.6-1.9-1.9-1.6 1.1c-.5-.3-1-.5-1.6-.7l-.4-1.9h-2.6l-.4 1.9c-.6.2-1.1.4-1.6.7L7 5.3 5.1 7.2l1.1 1.6c-.3.5-.5 1-.7 1.6l-1.9.4v2.6l1.9.4c.2.6.4 1.1.7 1.6l-1.1 1.6L7 18.9l1.6-1.1c.5.3 1 .5 1.6.7l.4 1.9h2.6l.4-1.9c.6-.2 1.1-.4 1.6-.7l1.6 1.1 1.9-1.9-1.1-1.6c.3-.5.5-1 .7-1.6l1.9-.4z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>',
    layers: '<path d="m12 3.5 9 4.8-9 4.8-9-4.8z"/><path d="m4.6 12 7.4 4 7.4-4 1.6.9-9 4.8-9-4.8z" opacity=".75"/><path d="m4.6 15.6 7.4 4 7.4-4 1.6.9-9 4.8-9-4.8z" opacity=".5"/>',
    chevronDown: '<path d="m6.5 9.5 5.5 5.5 5.5-5.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
    lyrics: '<rect x="4" y="6" width="9" height="2.2" rx="1.1"/><rect x="4" y="11" width="14" height="2.2" rx="1.1"/><rect x="4" y="16" width="11" height="2.2" rx="1.1"/>',
    volume: '<path d="M4 9.5v5h3.2l4.3 3.8V5.7L7.2 9.5z"/><path d="M15 9a4.2 4.2 0 0 1 0 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    sliders: '<path d="M7 4v16M12 4v16M17 4v16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><rect x="4.5" y="13" width="5" height="3" rx="1.5"/><rect x="9.5" y="7" width="5" height="3" rx="1.5"/><rect x="14.5" y="11" width="5" height="3" rx="1.5"/>',
    locate: '<circle cx="12" cy="12" r="6.2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="2.4"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    dice: '<rect x="4" y="4" width="16" height="16" rx="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="9" cy="9" r="1.5"/><circle cx="15" cy="15" r="1.5"/><circle cx="15" cy="9" r="1.5"/><circle cx="9" cy="15" r="1.5"/>',
    vinyl: '<circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="2.6"/><path d="M12 6.2a5.8 5.8 0 0 1 5.8 5.8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity=".7"/>',
    more: '<circle cx="12" cy="5.5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="18.5" r="1.8"/>',
    close: '<path d="m7 7 10 10M17 7 7 17" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
    mic: '<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M6 11.5a6 6 0 0 0 12 0M12 17.5v3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    speaker: '<rect x="6" y="3" width="12" height="18" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="14.5" r="3"/><circle cx="12" cy="7.5" r="1.3"/>',
    headphone: '<path d="M4 15v-2.5a8 8 0 0 1 16 0V15" fill="none" stroke="currentColor" stroke-width="2"/><rect x="3.5" y="13.5" width="4.5" height="7" rx="2"/><rect x="16" y="13.5" width="4.5" height="7" rx="2"/>',
    tv: '<rect x="3" y="5" width="18" height="12" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8.5 20.5h7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    nas: '<rect x="5" y="3.5" width="14" height="17" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="9" cy="8" r="1.2"/><circle cx="9" cy="12" r="1.2"/><path d="M12 8h4M12 12h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    phone: '<rect x="6.5" y="2.5" width="11" height="19" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10.5 18.5h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    folder: '<path d="M3.5 7.5c0-1.1.9-2 2-2h4l2 2h7c1.1 0 2 .9 2 2v7.5c0 1.1-.9 2-2 2h-13c-1.1 0-2-.9-2-2z"/>',
    usb: '<path d="M12 3v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="m9.5 5.5 2.5-3 2.5 3z"/><path d="M12 13l-4-2.5V8M12 15l4-2.5V10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="19" r="2.2"/>',
    tag: '<path d="M3.5 12.2V5.5c0-1.1.9-2 2-2h6.7l8.3 8.3c.8.8.8 2 0 2.8l-6.7 6.7c-.8.8-2 .8-2.8 0z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8.2" cy="8.2" r="1.6"/>',
    info: '<circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><rect x="11" y="10.5" width="2" height="6.5" rx="1"/><circle cx="12" cy="7.6" r="1.3"/>',
    open: '<path d="M14 4h6v6M20 4l-8.5 8.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    scan: '<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M4 12h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    widget: '<rect x="3.5" y="3.5" width="7.5" height="7.5" rx="2"/><rect x="13" y="3.5" width="7.5" height="7.5" rx="2" opacity=".6"/><rect x="3.5" y="13" width="17" height="7.5" rx="2" opacity=".8"/>',
    cast: '<path d="M3.5 17.5a3 3 0 0 1 3 3M3.5 13.5a7 7 0 0 1 7 7M3.5 9.5a11 11 0 0 1 11 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8 4.5h10a2.5 2.5 0 0 1 2.5 2.5v10A2.5 2.5 0 0 1 18 19.5h-1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" fill="none" stroke="currentColor" stroke-width="2.2"/>',
    sparkle: '<path d="M12 3.5c.6 3.9 2.6 5.9 6.5 6.5-3.9.6-5.9 2.6-6.5 6.5-.6-3.9-2.6-5.9-6.5-6.5 3.9-.6 5.9-2.6 6.5-6.5z"/><path d="M18.5 15c.3 1.7 1.1 2.5 2.8 2.8-1.7.3-2.5 1.1-2.8 2.8-.3-1.7-1.1-2.5-2.8-2.8 1.7-.3 2.5-1.1 2.8-2.8z" opacity=".7"/>',
    shield: '<path d="M12 3 5 6v5.5c0 4.4 3 8.2 7 9.5 4-1.3 7-5.1 7-9.5V6z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="m9 12 2.2 2.2L15.5 10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
    code: '<path d="m8.5 7-5 5 5 5M15.5 7l5 5-5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>',
    arrowDown: '<path d="M12 5v14m0 0-5-5m5 5 5-5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M5 15H4.5A2.5 2.5 0 0 1 2 12.5v-8A2.5 2.5 0 0 1 4.5 2h8A2.5 2.5 0 0 1 15 4.5V5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    chat: '<path d="M4.5 5.5A2.5 2.5 0 0 1 7 3h10a2.5 2.5 0 0 1 2.5 2.5v8A2.5 2.5 0 0 1 17 16H9.5l-4.2 3.5c-.6.5-1.3.1-1.3-.7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="9" cy="9.5" r="1.2"/><circle cx="12" cy="9.5" r="1.2"/><circle cx="15" cy="9.5" r="1.2"/>',
    github: '<path d="M12 2C6.48 2 2 6.58 2 12.23c0 4.52 2.87 8.35 6.84 9.7.5.1.68-.22.68-.49 0-.24-.01-1.04-.01-1.88-2.78.62-3.37-1.2-3.37-1.2-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.63.07-.63 1 .07 1.53 1.05 1.53 1.05.9 1.56 2.35 1.11 2.92.85.09-.66.35-1.11.63-1.37-2.22-.26-4.56-1.14-4.56-5.06 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.27 2.75 1.05a9.35 9.35 0 0 1 5 0c1.91-1.32 2.75-1.05 2.75-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.93-2.34 4.8-4.57 5.05.36.32.68.94.68 1.9 0 1.37-.01 2.48-.01 2.82 0 .27.18.6.69.49A10.22 10.22 0 0 0 22 12.23C22 6.58 17.52 2 12 2z"/>'
  };

  function svg(name, cls) {
    const p = P[name];
    if (!p) return '';
    return `<svg class="ic${cls ? ' ' + cls : ''}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${p}</svg>`;
  }
  function hydrate(root = document) {
    root.querySelectorAll('i[data-ic]').forEach(i => {
      const s = svg(i.dataset.ic, i.className);
      if (s) i.outerHTML = s;
    });
  }
  window.SIcons = { svg, hydrate };
})();
;
/* 生成式封面：延续 App 内置封面（BuiltinCovers）与封面墙占位图的视觉语言
 * 「渐变 + 几何母题」：圆锥渐变、同心环、波点、落日、扭曲棋盘、单字排版、网点、包豪斯
 * 全部由 CSS / 内联 SVG 绘制，零图片、零版权问题。
 */
(function () {
  const C = {
    sunset:   { motif: 'sunset',   title: '飞鸟与海',   artist: '山水乐队', glow: '#F09A8E', ink: '#fff',
                v: { a: '#F4A3A0', b: '#F8C99B', c: '#FBD27A', d: '#4C7C9B', e: '#2E5A79' } },
    conicA:   { motif: 'conic',    title: '第一缕光',   artist: '林间',     glow: '#9B6BF0', ink: '#fff',
                v: { a: '#2EC4B6', b: '#7B2FF7', c: '#F72585' } },
    rings:    { motif: 'rings',    title: '回声',       artist: 'Mono Lake', glow: '#3FCFB8', ink: '#fff',
                v: { a: '#3EE6C8', b: '#2A1B3D' } },
    dotsCoral:{ motif: 'dots',     title: '橘子汽水',   artist: '海盐',     glow: '#E98D72', ink: '#fff',
                v: { a: '#F08A6C', b: '#1E4D45' } },
    dotsLime: { motif: 'dots',     title: '萤火',       artist: '青柠',     glow: '#8C8FE8', ink: '#fff',
                v: { a: '#B5F25C', b: '#25235E' } },
    type:     { motif: 'type',     title: '清音',       artist: '山水',     glow: '#E4B3B3', ink: '#3b3a1a',
                v: { a: '#6E7F1E', b: '#F2DCDC' }, char: '清' },
    checker:  { motif: 'checker',  title: 'Op.14 迷宫', artist: '白日梦',   glow: '#3F9A62', ink: '#1d1d1d',
                v: { a: '#161616', b: '#F3EAD8', c: '#E0482B' } },
    conicB:   { motif: 'conic',    title: '旷野',       artist: '无名氏',   glow: '#38B07C', ink: '#fff',
                v: { a: '#1E3A8A', b: '#22C55E', c: '#FACC15' } },
    halftone: { motif: 'halftone', title: '正午',       artist: 'Sonance',  glow: '#E2CB3C', ink: '#1a1a1a',
                v: { a: '#F5DC3A', b: '#1A1A1A', c: '#C8321E' } },
    arcs:     { motif: 'arcs',     title: '几何午后',   artist: '包豪斯',   glow: '#E8935E', ink: '#1f2a44',
                v: { a: '#F1E9DA', b: '#2D4FA3', c: '#E8743B', d: '#D63A2F' } },
    dusk:     { motif: 'sunset',   title: '黄昏车站',   artist: '海盐',     glow: '#B48AD9', ink: '#fff',
                v: { a: '#8E7CC3', b: '#E7A3C4', c: '#FFD9A0', d: '#3E3A73', e: '#26234F' } },
    mint:     { motif: 'rings',    title: '薄荷雨',     artist: '林间',     glow: '#6FCBA7', ink: '#fff',
                v: { a: '#BFF0DB', b: '#2F7D67' } }
  };

  function sunsetSvg(v) {
    return `<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs><linearGradient id="__S" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${v.a}"/><stop offset="1" stop-color="${v.b}"/></linearGradient>
      <mask id="__M"><rect width="100" height="100" fill="#fff"/>${[50, 54.5, 58.5, 62, 65].map((y, i) => `<rect y="${y}" width="100" height="${1 + i * 0.45}" fill="#000"/>`).join('')}</mask></defs>
      <rect width="100" height="100" fill="url(#__S)"/>
      <circle cx="50" cy="56" r="21" fill="${v.c}" mask="url(#__M)"/>
      <path d="M0 64 Q12 61 25 64 T50 64 T75 64 T100 64 V100 H0Z" fill="${v.d}"/>
      <path d="M0 74 Q12 71 25 74 T50 74 T75 74 T100 74 V100 H0Z" fill="${v.e}" opacity=".85"/>
      <path d="M0 86 Q12 83 25 86 T50 86 T75 86 T100 86 V100 H0Z" fill="${v.e}"/>
      <path d="M44 66h12M46 69h8M48 72h4" stroke="${v.c}" stroke-width="1" opacity=".55" stroke-linecap="round"/>
      <path d="M22 22l2 1.4 2-1.4M30 17l1.6 1.1 1.6-1.1M36 24l1.4 1 1.4-1" fill="none" stroke="#5a4a5a" stroke-width=".7" stroke-linecap="round" opacity=".6"/>
      <text x="7" y="10" font-size="3.4" fill="#5a4a5a" opacity=".55" font-family="Inter,sans-serif" letter-spacing=".3">SIDE A / SUNSET</text>
    </svg>`;
  }
  function checkerSvg(v) {
    // 预计算扭曲棋盘纯矢量路径，不用 SVG feTurbulence / feDisplacementMap 实时滤镜
    const step = 11.5, x0 = -7, y0 = -7;
    const warp = (x, y) => {
      const dx = x - 50, dy = y - 44, r = Math.hypot(dx, dy);
      const bulge = Math.exp(-(r * r) / 1500) * 6.5;
      const k = r > 0.1 ? bulge / r : 0;
      const wx = x + dx * k + Math.sin(y * 0.085) * 4.2;
      const wy = y + dy * k + Math.cos(x * 0.085) * 4.2;
      return `${wx.toFixed(1)},${wy.toFixed(1)}`;
    };
    let d = '';
    for (let j = 0; j < 10; j++) {
      for (let i = 0; i < 10; i++) {
        if ((i + j) % 2 !== 0) continue;
        const x = x0 + i * step, y = y0 + j * step, mx = x + step / 2, my = y + step / 2;
        d += `M${warp(x, y)}Q${warp(mx, y)} ${warp(x + step, y)}Q${warp(x + step, my)} ${warp(x + step, y + step)}Q${warp(mx, y + step)} ${warp(x, y + step)}Q${warp(x, my)} ${warp(x, y)}Z`;
      }
    }
    return `<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <rect width="100" height="100" fill="${v.b}"/>
      <path d="${d}" fill="${v.a}"/>
      <circle cx="50" cy="44" r="22" fill="none" stroke="${v.c}" stroke-width="3.2"/>
      <rect x="5" y="5" width="15" height="6" rx="1" fill="${v.b}"/>
      <text x="7" y="9.6" font-size="3.6" fill="#333" font-family="Inter,sans-serif">OP / 14</text>
    </svg>`;
  }

  let uid = 0;
  /** 返回封面 HTML 字符串；opts.cap=true 时带标题文字 */
  function html(id, opts = {}) {
    const c = C[id] || C.sunset;
    const v = c.v;
    const vars = Object.entries(v).map(([k, val]) => `--${k}:${val}`).join(';');
    let inner = '';
    if (c.motif === 'sunset') {
      const n = 'cvs' + (uid++);
      inner = sunsetSvg(v).replace(/__S/g, n + 's').replace(/__M/g, n + 'm');
    } else if (c.motif === 'checker') {
      inner = checkerSvg(v);
    } else if (c.motif === 'type') {
      inner = `<span class="cv-char">${c.char}</span><span class="cv-mini">${c.title}<br><small>${c.artist}</small></span>`;
    } else if (c.motif === 'halftone') {
      inner = '<span class="cv-ht"></span><span class="cv-ht2"></span><span class="cv-script">so fine</span>';
    } else if (c.motif === 'arcs') {
      inner = '<span class="cv-arc1"></span><span class="cv-arc2"></span><span class="cv-arc3"></span>';
    }
    const cap = opts.cap ? `<span class="cv-cap" style="color:${c.ink}"><b>${c.title}</b><small>${c.artist}</small></span>` : '';
    return `<div class="cv cv-${c.motif}${opts.cls ? ' ' + opts.cls : ''}" style="${vars}" data-cover="${id}">${inner}${cap}</div>`;
  }

  /** 预留共享定义钩子（已改用纯矢量绘制，零 CPU 滤镜开销） */
  function injectDefs() {}

  window.SCovers = { list: C, html, injectDefs, get: id => C[id] || C.sunset };
})();
;
/* 核心：全站配置、统一 rAF 调度、可见性、进场动画、通用工具 */
(function () {
  const S = (window.Sonance = window.Sonance || {});

  S.config = {
    version: '2.5',
    quarkUrl: 'https://pan.quark.cn/s/f5e9b71419b3',
    quarkCode: '我用夸克网盘给你分享了「山水有清音」，点击链接或复制整段内容，打开「夸克网盘APP」即可获取。\n亝一五枫及并词让哈走看忛\n/~602e3cRirc~:/',
    qqGroup: '1129486853',
    wechat: 'gxslcl',
    sha256: '6F96F0780C00067027455C92B7C40075CB0EC5AC6DFB6169E4D44FABFA03E913',
    minAndroid: 'Android 7.0+',
    repo: 'https://github.com/gxslcl/Sonance'
  };

  S.reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  S.motionOn = !S.reduced; // 迷你播放条上的水滴键可以开关全站动效

  /* ---------- 统一 rAF 调度：只跑可见模块 ---------- */
  const tasks = new Set();
  let last = performance.now();
  S.time = 0;
  S.fps = 60;
  let fpsAcc = 0, fpsN = 0;
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    S.time += dt;
    fpsAcc += dt; fpsN++;
    if (fpsAcc > 0.5) { S.fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }
    tasks.forEach(t => {
      if (t.el && !t.el.__visible) return;
      try { t.fn(dt, S.time); } catch (e) { console.error(e); tasks.delete(t); }
    });
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  /** 注册每帧任务；传 el 时只在 el 可见时执行 */
  S.tick = function (fn, el) {
    const t = { fn, el };
    if (el) S.watch(el);
    tasks.add(t);
    return () => tasks.delete(t);
  };

  /* ---------- 可见性 ---------- */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      e.target.__visible = e.isIntersecting;
      e.target.dispatchEvent(new CustomEvent(e.isIntersecting ? 's:show' : 's:hide'));
    });
  }, { rootMargin: '120px 0px' });
  S.watch = el => { if (!el.__watched) { el.__watched = true; el.__visible = false; io.observe(el); } };

  /* ---------- 进场动画 ---------- */
  function initReveal() {
    const items = document.querySelectorAll('[data-reveal]');
    const rio = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        const el = e.target;
        const group = el.parentElement ? [...el.parentElement.querySelectorAll(':scope > [data-reveal]')] : [el];
        const idx = Math.max(0, group.indexOf(el));
        el.style.transitionDelay = (idx * 60) + 'ms';
        el.classList.add('in');
        rio.unobserve(el);
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    items.forEach(el => rio.observe(el));
  }

  /* ---------- 工具 ---------- */
  S.$ = (sel, root = document) => root.querySelector(sel);
  S.$$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  S.lerp = (a, b, t) => a + (b - a) * t;
  S.clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  S.smooth = (e0, e1, x) => { const t = S.clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
  /** 帧率无关的指数趋近：rate 越大越快（单位 1/秒） */
  S.approach = (cur, target, rate, dt) => target + (cur - target) * Math.exp(-rate * dt);

  /** 颜色变量补间（OKLab 插值） */
  S.tweenColors = function (el, from, to, ms, onFrame) {
    if (el.__tw) el.__tw.cancel = true;
    const job = { cancel: false };
    el.__tw = job;
    const t0 = performance.now();
    const step = now => {
      if (job.cancel) return;
      const k = S.reduced ? 1 : S.clamp((now - t0) / ms, 0, 1);
      const e = 1 - Math.pow(1 - k, 3);
      const cur = {};
      for (const key in to) cur[key] = SColor.mix(from[key] || to[key], to[key], e);
      onFrame(cur);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  /** 封面主色 → 一套晕染色板 */
  S.palette = function (glow, dark) {
    if (dark) return dark;
    const c = SColor;
    return {
      g1: c.pastel(glow, 0.80, 0.52),
      g2: c.pastel(c.shiftHue(glow, 28), 0.84, 0.46),
      g3: c.pastel(c.shiftHue(glow, -32), 0.86, 0.40),
      bg: c.pastel(glow, 0.955, 0.30),
      drop: c.deep(glow, 0.46)
    };
  };

  S.toast = function (msg) {
    let t = document.getElementById('toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t.__h);
    t.__h = setTimeout(() => t.classList.remove('show'), 2200);
  };

  S.copy = function (text, okMsg) {
    const done = () => S.toast(okMsg || '已复制到剪贴板');
    const fallback = () => {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        done();
      } catch (_) {
        S.toast('请手动长按复制');
      }
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else {
      fallback();
    }
  };

  S.ready = [];
  S.onReady = fn => S.ready.push(fn);

  document.addEventListener('DOMContentLoaded', () => {
    document.documentElement.classList.add('js');
    if (S.reduced) document.documentElement.classList.add('reduced');
    SCovers.injectDefs();
    SIcons.hydrate();
    // 配置注入
    S.$$('[data-cfg]').forEach(el => {
      const k = el.dataset.cfg;
      if (k === 'quarkUrl') el.setAttribute('href', S.config.quarkUrl);
      else if (S.config[k] != null) el.textContent = S.config[k];
    });
    if (S.config.repo) {
      S.$$('[data-repo]').forEach(el => {
        el.href = S.config.repo;
        el.target = '_blank';
        el.rel = 'noopener noreferrer';
        el.hidden = false;
      });
    }
    S.ready.forEach(fn => { try { fn(); } catch (e) { console.error(e); } });
    // 离开视口的章节自动暂停 CSS 动画
    S.$$('section[data-cover]').forEach(sec => {
      sec.addEventListener('s:hide', () => sec.classList.add('offscreen'));
      sec.addEventListener('s:show', () => sec.classList.remove('offscreen'));
      S.watch(sec);
    });
    SIcons.hydrate();
    initReveal();
  });
})();
;
/* 背景音乐 · 星轨（原创 G 大调太空抒情氛围曲，纯 Web Audio API 现场合成，~66 BPM，16 小节循环）
 * - 零外部音频文件、零版权风险、零网络体积开销
 * - Rhodes 电钢分解和弦 + 柔美带颤音主旋律 + 太空和声垫 + 2.8s 立体声厅堂混响与柔波回声
 * - 进入页面尝试自动播放；被浏览器策略拦截时在首次交互无缝开启，音效试听/麦克风时自动避让
 */
(function () {
  const S = (window.Sonance = window.Sonance || {});

  const BEAT = 60 / 66;     // ~0.909s
  const STEP = BEAT / 2;    // eighth note (~0.4545s)
  const STEPS_PER_BAR = 8;
  const TOTAL_BARS = 16;

  // G 大调音阶频率表
  const N = {
    E2: 82.41, G2: 98.00, A2: 110.00, B2: 123.47,
    C3: 130.81, D3: 146.83, E3: 164.81, Fs3: 185.00, G3: 196.00, A3: 220.00, B3: 246.94,
    C4: 261.63, D4: 293.66, E4: 329.63, Fs4: 369.99, G4: 392.00, A4: 440.00, B4: 493.88,
    C5: 523.25, D5: 587.33, E5: 659.25, Fs5: 739.99, G5: 783.99
  };

  // 抒情和声进行：Gmaj7 -> Bm7 -> Em7 -> Cmaj7 | Am7 -> Bm7 -> Cmaj7 -> D7sus4
  const PROG = [
    { bass: N.G2, pad: [N.G3, N.B3, N.D4, N.Fs4], arp: [N.G3, N.D4, N.Fs4, N.B4, N.Fs4, N.D4] },
    { bass: N.B2, pad: [N.B3, N.D4, N.Fs4, N.A4], arp: [N.B3, N.Fs4, N.A4, N.D5, N.A4, N.Fs4] },
    { bass: N.E2, pad: [N.E3, N.G3, N.B3, N.D4],  arp: [N.E3, N.B3, N.D4, N.G4, N.D4, N.B3] },
    { bass: N.C3, pad: [N.C4, N.E4, N.G4, N.B4],  arp: [N.C4, N.G4, N.B4, N.E5, N.B4, N.G4] },
    { bass: N.A2, pad: [N.A3, N.C4, N.E4, N.G4],  arp: [N.A3, N.E4, N.G4, N.C5, N.G4, N.E4] },
    { bass: N.B2, pad: [N.B3, N.D4, N.Fs4, N.A4], arp: [N.B3, N.Fs4, N.A4, N.D5, N.A4, N.Fs4] },
    { bass: N.C3, pad: [N.C4, N.E4, N.G4, N.B4],  arp: [N.C4, N.G4, N.B4, N.E5, N.B4, N.G4] },
    { bass: N.D3, pad: [N.D4, N.G4, N.A4, N.C5],  arp: [N.D4, N.G4, N.A4, N.D5, N.A4, N.G4] }
  ];

  // 原创 16 小节抒情主旋律（太空舒缓叙事感：[freq, durBeats, vel]）
  const LEAD = {
    0:  { 1: [N.B4, 1.4, 0.82], 3: [N.D5, 1.6, 0.90], 6: [N.B4, 1.4, 0.78] },
    1:  { 0: [N.A4, 2.4, 0.86], 5: [N.Fs4, 1.8, 0.72] },
    2:  { 1: [N.G4, 1.4, 0.80], 3: [N.B4, 1.6, 0.88], 6: [N.A4, 1.4, 0.76] },
    3:  { 0: [N.G4, 3.2, 0.84] },
    4:  { 1: [N.E4, 1.2, 0.76], 3: [N.G4, 1.4, 0.82], 5: [N.A4, 1.8, 0.88] },
    5:  { 0: [N.B4, 2.2, 0.88], 4: [N.D5, 2.2, 0.90] },
    6:  { 0: [N.E5, 2.0, 0.92], 3: [N.D5, 1.4, 0.84], 6: [N.B4, 1.6, 0.80] },
    7:  { 0: [N.A4, 3.4, 0.84] },
    8:  { 1: [N.D5, 1.4, 0.90], 3: [N.Fs5, 1.8, 0.95], 6: [N.E5, 1.4, 0.86] },
    9:  { 0: [N.D5, 2.6, 0.90], 5: [N.B4, 1.8, 0.78] },
    10: { 1: [N.B4, 1.4, 0.82], 3: [N.E5, 1.8, 0.92], 6: [N.D5, 1.4, 0.84] },
    11: { 0: [N.B4, 3.0, 0.86] },
    12: { 1: [N.C5, 1.4, 0.84], 3: [N.B4, 1.2, 0.80], 5: [N.A4, 1.8, 0.82] },
    13: { 0: [N.B4, 2.2, 0.84], 4: [N.G4, 2.2, 0.78] },
    14: { 0: [N.G4, 1.8, 0.80], 3: [N.A4, 1.8, 0.84], 6: [N.B4, 1.6, 0.86] },
    15: { 0: [N.A4, 2.0, 0.82], 4: [N.G4, 3.2, 0.84] }
  };

  const ARP_STEPS = new Set([0, 2, 3, 4, 6, 7]);

  let ctx = null, masterGain = null, duckGain = null, dryBus = null, wetBus = null, delayIn = null;
  let timer = null, stepIdx = 0, nextTime = 0;
  let state = 'muted'; // 'playing' | 'armed' | 'muted'
  let userMuted = false, ducked = false, toastShown = false;
  let btn = null, lbl = null;

  function makeImpulse(c, seconds = 2.8) {
    const len = Math.floor(c.sampleRate * seconds);
    const buf = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = buf.getChannelData(ch);
      let lp = 0;
      for (let i = 0; i < len; i++) {
        const env = Math.pow(1 - i / len, 2.5);
        const w = (Math.random() * 2 - 1) * env;
        lp = lp * 0.74 + w * 0.26;
        data[i] = lp * 0.85;
      }
    }
    return buf;
  }

  function ensureGraph() {
    if (ctx) return true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.ratio.value = 3;

    masterGain = ctx.createGain();
    masterGain.gain.value = 0.0001;

    duckGain = ctx.createGain();
    duckGain.gain.value = ducked ? 0.14 : 1.0;

    dryBus = ctx.createGain();
    dryBus.gain.value = 0.74;

    wetBus = ctx.createGain();
    wetBus.gain.value = 0.46;

    const rev = ctx.createConvolver();
    rev.buffer = makeImpulse(ctx, 2.8);

    // 柔和回声延迟线（增强星际空间感）
    delayIn = ctx.createGain();
    delayIn.gain.value = 0.22;
    const dly = ctx.createDelay(1.0);
    dly.delayTime.value = STEP * 0.75; // 附点十六分音符律动回声
    const dlyLP = ctx.createBiquadFilter();
    dlyLP.type = 'lowpass';
    dlyLP.frequency.value = 1150;
    const dlyFb = ctx.createGain();
    dlyFb.gain.value = 0.24;

    delayIn.connect(dly);
    dly.connect(dlyLP);
    dlyLP.connect(dlyFb);
    dlyFb.connect(dly);
    dlyLP.connect(wetBus);
    dlyLP.connect(dryBus);

    dryBus.connect(comp);
    wetBus.connect(rev);
    rev.connect(comp);
    comp.connect(duckGain);
    duckGain.connect(masterGain);
    masterGain.connect(ctx.destination);
    return true;
  }

  function playPadAndBass(chord, t, barDur) {
    // 深沉温暖的次低音根音
    const sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.value = chord.bass;
    const sg = ctx.createGain();
    sg.gain.setValueAtTime(0.0001, t);
    sg.gain.linearRampToValueAtTime(0.14, t + 0.35);
    sg.gain.setValueAtTime(0.14, t + barDur - 0.8);
    sg.gain.exponentialRampToValueAtTime(0.0001, t + barDur + 0.3);
    sub.connect(sg);
    sg.connect(dryBus);
    sub.start(t);
    sub.stop(t + barDur + 0.35);

    // 太空氛围和声垫
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 430;

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.055, t + 1.5);
    g.gain.setValueAtTime(0.055, t + barDur - 1.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + barDur + 0.45);
    lp.connect(g);
    g.connect(dryBus);
    g.connect(wetBus);

    chord.pad.forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = i === 0 ? 'triangle' : 'sine';
      o.frequency.value = f;
      o.detune.value = (i % 2 ? 1 : -1) * 4.2;
      const vg = ctx.createGain();
      vg.gain.value = i === 0 ? 0.36 : 0.22;
      o.connect(vg);
      vg.connect(lp);
      o.start(t);
      o.stop(t + barDur + 0.5);
    });
  }

  function playRhodesArp(freq, t, panVal) {
    const dur = 1.9;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1100, t);
    lp.frequency.exponentialRampToValueAtTime(420, t + 0.9);

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, t);
    env.gain.linearRampToValueAtTime(0.068, t + 0.022);
    env.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    const o1 = ctx.createOscillator();
    o1.type = 'sine';
    o1.frequency.value = freq;
    const o2 = ctx.createOscillator();
    o2.type = 'sine';
    o2.frequency.value = freq * 2;
    const g2 = ctx.createGain();
    g2.gain.value = 0.14;

    o1.connect(lp);
    o2.connect(g2); g2.connect(lp);
    lp.connect(env);

    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (pan) {
      pan.pan.value = panVal;
      env.connect(pan);
      pan.connect(dryBus);
      pan.connect(wetBus);
    } else {
      env.connect(dryBus);
      env.connect(wetBus);
    }
    o1.start(t); o2.start(t);
    o1.stop(t + dur + 0.05); o2.stop(t + dur + 0.05);
  }

  function playLead(freq, t, durBeats, vel) {
    const dur = durBeats * BEAT;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1800, t);
    lp.frequency.exponentialRampToValueAtTime(680, t + Math.min(dur, 1.5));

    const env = ctx.createGain();
    const peak = 0.13 * vel;
    env.gain.setValueAtTime(0.0001, t);
    env.gain.linearRampToValueAtTime(peak, t + 0.045);
    env.gain.exponentialRampToValueAtTime(peak * 0.58, t + 0.45);
    env.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.55);

    const o1 = ctx.createOscillator();
    o1.type = 'sine';
    o1.frequency.value = freq;

    const o2 = ctx.createOscillator();
    o2.type = 'triangle';
    o2.frequency.value = freq;
    const g2 = ctx.createGain();
    g2.gain.value = 0.22;

    // 长音加入柔美颤音
    let lfo = null;
    if (durBeats >= 1.5) {
      lfo = ctx.createOscillator();
      lfo.frequency.value = 4.5;
      const lg = ctx.createGain();
      lg.gain.setValueAtTime(0, t);
      lg.gain.linearRampToValueAtTime(4.2, t + 0.45);
      lfo.connect(lg);
      lg.connect(o1.detune);
      lg.connect(o2.detune);
      lfo.start(t);
      lfo.stop(t + dur + 0.6);
    }

    o1.connect(lp);
    o2.connect(g2); g2.connect(lp);
    lp.connect(env);
    env.connect(dryBus);
    env.connect(wetBus);
    env.connect(delayIn);

    o1.start(t); o2.start(t);
    o1.stop(t + dur + 0.6); o2.stop(t + dur + 0.6);
  }

  function scheduleStep(idx, t) {
    const bar = Math.floor(idx / STEPS_PER_BAR) % TOTAL_BARS;
    const step = idx % STEPS_PER_BAR;
    const chord = PROG[bar % PROG.length];

    if (step === 0) {
      playPadAndBass(chord, t, STEPS_PER_BAR * STEP);
    }
    if (ARP_STEPS.has(step)) {
      const aIdx = step < 2 ? 0 : step - 1;
      const note = chord.arp[aIdx % chord.arp.length];
      playRhodesArp(note, t, (aIdx % 2 ? 0.24 : -0.24));
    }
    const mel = LEAD[bar] && LEAD[bar][step];
    if (mel) playLead(mel[0], t, mel[1], mel[2]);
  }

  function pump() {
    if (!ctx || ctx.state !== 'running') return;
    while (nextTime < ctx.currentTime + 0.45) {
      scheduleStep(stepIdx, nextTime);
      nextTime += STEP;
      stepIdx = (stepIdx + 1) % (TOTAL_BARS * STEPS_PER_BAR);
    }
  }

  function syncUI() {
    if (!btn) return;
    btn.classList.toggle('playing', state === 'playing');
    btn.classList.toggle('armed', state === 'armed');
    btn.setAttribute('aria-pressed', String(state === 'playing'));
    if (lbl) lbl.textContent = '星轨';
  }

  function clearUnlock() {
    ['pointerdown', 'keydown', 'touchstart'].forEach(ev =>
      window.removeEventListener(ev, onFirstGesture, true)
    );
  }

  function onFirstGesture(e) {
    if (userMuted || state === 'playing') { clearUnlock(); return; }
    if (e.target && e.target.closest && e.target.closest('#bgmBtn')) {
      clearUnlock();
      return;
    }
    clearUnlock();
    play(false);
  }

  function startLoop() {
    if (timer) return;
    nextTime = ctx.currentTime + 0.06;
    pump();
    timer = setInterval(pump, 160);
    masterGain.gain.cancelScheduledValues(ctx.currentTime);
    masterGain.gain.setValueAtTime(Math.max(0.0001, masterGain.gain.value), ctx.currentTime);
    masterGain.gain.linearRampToValueAtTime(0.38, ctx.currentTime + 1.4);
    state = 'playing';
    syncUI();
  }

  async function play(fromUser = false) {
    if (!ensureGraph()) return;
    if (fromUser) userMuted = false;
    clearUnlock();
    try {
      if (ctx.state === 'suspended') await ctx.resume();
    } catch (_) {}

    if (ctx.state === 'running') {
      startLoop();
    } else {
      state = 'armed';
      syncUI();
      ['pointerdown', 'keydown', 'touchstart'].forEach(ev =>
        window.addEventListener(ev, onFirstGesture, { capture: true, passive: true })
      );
      if (!toastShown && !fromUser) {
        toastShown = true;
        S.toast('点击页面任意处开启背景音乐 · 星轨');
      }
    }
  }

  function pause(fromUser = false) {
    if (fromUser) userMuted = true;
    clearUnlock();
    if (timer) { clearInterval(timer); timer = null; }
    if (ctx && masterGain) {
      const t = ctx.currentTime;
      masterGain.gain.cancelScheduledValues(t);
      masterGain.gain.setValueAtTime(masterGain.gain.value, t);
      masterGain.gain.linearRampToValueAtTime(0.0001, t + 0.3);
      setTimeout(() => {
        if (state === 'muted' && ctx && ctx.state === 'running') {
          ctx.suspend().catch(() => {});
        }
      }, 340);
    }
    state = 'muted';
    syncUI();
  }

  function toggle() {
    if (state === 'playing') pause(true);
    else play(true);
  }

  function duck(on) {
    ducked = !!on;
    if (!ctx || !duckGain) return;
    const t = ctx.currentTime;
    duckGain.gain.cancelScheduledValues(t);
    duckGain.gain.setTargetAtTime(ducked ? 0.14 : 1.0, t, ducked ? 0.15 : 0.35);
  }

  S.bgm = { play, pause, toggle, duck };

  S.onReady(() => {
    btn = S.$('#bgmBtn');
    lbl = S.$('.bgm-lbl', btn);
    if (btn) btn.addEventListener('click', toggle);
    play(false);
  });
})();
;
/* <s-drop>：水滴播放键
 * 对应 App 的 PlayButtonShape.DROPLET：播放时有机形变，暂停 / 关闭动效时平滑回到正圆。
 * 光晕是同形状的模糊副本，颜色取 --drop（跟随当前封面）。
 * 属性：playing（播放态形变）、ambient（常驻轻微呼吸）、shape="normal"（普通正圆）
 */
(function () {
  const N = 7, R = 40;
  let seq = 0;

  function pathFor(pts) {
    // 闭合 Catmull-Rom → 三次贝塞尔
    let d = `M${pts[0][0].toFixed(2)},${pts[0][1].toFixed(2)}`;
    for (let i = 0; i < pts.length; i++) {
      const p0 = pts[(i - 1 + N) % N], p1 = pts[i], p2 = pts[(i + 1) % N], p3 = pts[(i + 2) % N];
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += `C${c1x.toFixed(2)},${c1y.toFixed(2)} ${c2x.toFixed(2)},${c2y.toFixed(2)} ${p2[0].toFixed(2)},${p2[1].toFixed(2)}`;
    }
    return d + 'Z';
  }

  class SDrop extends HTMLElement {
    static get observedAttributes() { return ['playing', 'ambient', 'shape']; }
    connectedCallback() {
      if (this.__built) return;
      this.__built = true;
      const id = 'dg' + (seq++);
      const gid = 'dgg' + (seq++);
      const ic = document.createElement('span');
      ic.className = 'drop-ic';
      while (this.firstChild) ic.appendChild(this.firstChild);
      this.innerHTML = `<svg class="drop-svg" viewBox="-80 -80 160 160" aria-hidden="true">
        <defs>
          <radialGradient id="${gid}" cx="50%" cy="50%" r="50%">
            <stop offset="45%" style="stop-color:var(--drop);stop-opacity:.48"/>
            <stop offset="100%" style="stop-color:var(--drop);stop-opacity:0"/>
          </radialGradient>
          <radialGradient id="${id}" cx="35%" cy="28%" r="85%">
            <stop offset="0" style="stop-color:var(--drop-hi, #fff);stop-opacity:.38"/>
            <stop offset=".45" style="stop-color:var(--drop);stop-opacity:0"/>
          </radialGradient>
        </defs>
        <circle class="drop-glow" cx="0" cy="0" r="68" fill="url(#${gid})"/>
        <path class="drop-body"/>
        <path class="drop-sheen" fill="url(#${id})"/>
      </svg>`;
      this.appendChild(ic);
      this.body = this.querySelector('.drop-body');
      this.sheen = this.querySelector('.drop-sheen');
      this.amp = 0;
      this.phase = Math.random() * 10;
      this.press = 0;
      this.acc = 0;
      this.__forceRender = false;
      this.render(0);
      if (!this.hasAttribute('tabindex') && !this.closest('a,button')) this.tabIndex = 0;
      this.addEventListener('pointerdown', () => { this.press = 1; this.__forceRender = true; });
      this.__untick = Sonance.tick(dt => this.update(dt), this);
    }
    disconnectedCallback() { /* 保留：元素可能被移动后重新挂载 */ }
    target() {
      if (!Sonance.motionOn || this.getAttribute('shape') === 'normal') return 0;
      if (this.hasAttribute('playing')) return 0.085;
      if (this.hasAttribute('ambient')) return 0.045;
      return 0;
    }
    update(dt) {
      const tgt = this.target();
      this.amp = Sonance.approach(this.amp, tgt, 4, dt);
      this.press = Sonance.approach(this.press, 0, 9, dt);
      if (this.amp < 0.0005 && tgt === 0 && this.__still && this.press < 0.01) return;
      this.__still = this.amp < 0.0005;
      this.phase += dt;
      this.acc += dt;
      if (this.acc < 1 / 24 && !this.__forceRender) return;
      this.acc = 0;
      this.__forceRender = false;
      this.render(this.phase);
    }
    render(t) {
      const a = this.amp, s = 1 - this.press * 0.08;
      const pts = [];
      for (let i = 0; i < N; i++) {
        const ang = (i / N) * Math.PI * 2 - Math.PI / 2;
        const k = 1 + a * (0.62 * Math.sin(t * 1.35 + i * 1.7) + 0.38 * Math.sin(t * 2.2 + i * 2.9));
        pts.push([Math.cos(ang) * R * k * s, Math.sin(ang) * R * k * s]);
      }
      const d = pathFor(pts);
      this.body.setAttribute('d', d);
      this.sheen.setAttribute('d', d);
    }
  }
  customElements.define('s-drop', SDrop);
})();
;
/* 滚动即换歌：每个章节绑定一张封面，滚动位置驱动全站晕染颜色插值
 * 对应 App 的 GlowTransition.SWIPE（跟手）：滑到一半，颜色就混到一半。
 */
(function () {
  const S = window.Sonance;
  const DARK = { g1: '#6B4426', g2: '#3D2B1E', g3: '#4A3020', bg: '#1A1410', drop: '#D98A22' };
  const KEYS = ['g1', 'g2', 'g3', 'bg'];

  const G = (S.glow = { sections: [], active: -1, dirty: true, maxScroll: 0, vh: 800 });
  let glowEl = null;
  let lastPaint = 0;

  G.setSectionGlow = function (el, hex, instant) {
    const sec = G.sections.find(s => s.el === el);
    if (!sec) return;
    const to = S.palette(hex);
    if (G.sections[G.active] === sec) {
      document.documentElement.style.setProperty('--drop', to.drop);
    }
    if (instant) { sec.pal = to; G.dirty = true; lastPaint = 0; return; }
    S.tweenColors(el, sec.pal, to, 900, cur => { sec.pal = cur; G.dirty = true; });
  };

  function measure() {
    const y0 = window.scrollY;
    G.vh = window.innerHeight || 800;
    G.maxScroll = Math.max(0, document.documentElement.scrollHeight - G.vh);
    G.sections.forEach(s => {
      const r = s.el.getBoundingClientRect();
      s.top = r.top + y0;
      s.h = r.height;
      s.mid = s.top + Math.min(r.height, G.vh) / 2;
    });
    G.dirty = true;
    lastPaint = 0;
  }

  function apply(forcePaint) {
    const secs = G.sections;
    if (!secs.length) return;
    const sy = window.scrollY;
    const y = sy + G.vh / 2;

    // 进度条每帧轻量化同步（不读 scrollHeight，不改 :root 变量）
    G.progress = G.maxScroll > 0 ? S.clamp(sy / G.maxScroll, 0, 1) : 0;
    document.dispatchEvent(new CustomEvent('s:progress', { detail: G.progress }));

    // 当前曲目 = 视口中线所在章节；仅切换章节时才改 :root 的 --drop
    let act = 0;
    secs.forEach((s, k) => { if (y >= s.top) act = k; });
    if (act !== G.active) {
      G.active = act;
      document.body.classList.toggle('on-dark', !!secs[act].dark);
      document.documentElement.style.setProperty('--drop', secs[act].pal.drop);
      document.dispatchEvent(new CustomEvent('s:track', { detail: { index: act, section: secs[act] } }));
      forcePaint = true;
    }

    // 节流背景渐变色重绘（最多约每 60ms 一次），避免快速滚动时整屏反复光栅化
    const now = performance.now();
    if (!forcePaint && now - lastPaint < 60) {
      G.dirty = true;
      return;
    }
    lastPaint = now;

    let i = 0;
    while (i < secs.length - 1 && y >= secs[i + 1].mid) i++;
    let pal;
    if (i >= secs.length - 1 || y < secs[0].mid) {
      pal = (y < secs[0].mid ? secs[0] : secs[secs.length - 1]).pal;
    } else {
      const a = secs[i], b = secs[i + 1];
      const t = S.smooth(0.18, 0.82, (y - a.mid) / (b.mid - a.mid));
      pal = {};
      KEYS.forEach(k => { pal[k] = SColor.mix(a.pal[k], b.pal[k], t); });
    }
    if (glowEl) {
      const st = glowEl.style;
      st.setProperty('--g1', pal.g1);
      st.setProperty('--g2', pal.g2);
      st.setProperty('--g3', pal.g3);
      st.setProperty('--bg-tone', pal.bg);
    }
  }

  S.onReady(() => {
    glowEl = document.getElementById('glow');
    G.sections = S.$$('section[data-cover]').map((el, idx) => {
      const dark = el.hasAttribute('data-dark');
      const cover = SCovers.get(el.dataset.cover);
      return {
        el, idx, dark,
        cover: el.dataset.cover,
        title: el.dataset.title || '',
        sub: el.dataset.sub || '',
        pal: dark ? { ...DARK } : S.palette(cover.glow)
      };
    });
    measure();
    apply(true);
    window.addEventListener('scroll', () => { G.dirty = true; }, { passive: true });
    window.addEventListener('resize', measure, { passive: true });
    window.addEventListener('load', measure);
    setTimeout(measure, 1200);
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(document.body);
    S.tick(() => { if (G.dirty) { G.dirty = false; apply(false); } });
  });
})();
;
/* 悬浮玻璃播放条 + 章节索引栏
 * 播放条照搬 App 的悬浮卡片：封面 / 曲名 / 歌手 / 上一曲 · 水滴键 · 下一曲 / 底边进度
 * 这里「曲目」= 章节，进度 = 整页滚动进度；水滴键开关全站动效。
 */
(function () {
  const S = window.Sonance;

  S.onReady(() => {
    const bar = document.getElementById('mini');
    const rail = document.getElementById('rail');
    if (!bar) return;
    const G = S.glow;
    const cv = S.$('.mini-cover', bar);
    const title = S.$('.mini-title', bar);
    const sub = S.$('.mini-sub', bar);
    const fill = S.$('.mini-progress i', bar);
    const drop = S.$('s-drop', bar);
    const playIc = S.$('.mini-play', bar);

    function go(delta) {
      const n = S.clamp(G.active + delta, 0, G.sections.length - 1);
      G.sections[n].el.scrollIntoView({ behavior: S.reduced ? 'auto' : 'smooth', block: 'start' });
    }
    S.$('.mini-prev', bar).addEventListener('click', () => go(-1));
    S.$('.mini-next', bar).addEventListener('click', () => go(1));

    function syncPlay() {
      if (S.motionOn) drop.setAttribute('playing', ''); else drop.removeAttribute('playing');
      playIc.innerHTML = SIcons.svg(S.motionOn ? 'pause' : 'play');
      playIc.setAttribute('aria-label', S.motionOn ? '暂停全站动效' : '恢复全站动效');
      document.documentElement.classList.toggle('motion-off', !S.motionOn);
    }
    playIc.addEventListener('click', () => {
      S.motionOn = !S.motionOn;
      syncPlay();
      S.toast(S.motionOn ? '动效已恢复' : '动效已暂停，页面保持静止');
    });
    syncPlay();

    // 章节索引栏
    if (rail) {
      rail.innerHTML = G.sections.map((s, i) =>
        `<button type="button" data-i="${i}" aria-label="跳到：${s.title}"><span>${String(i).padStart(2, '0')}</span><em>${s.title}</em></button>`).join('');
      rail.addEventListener('click', e => {
        const b = e.target.closest('button');
        if (b) G.sections[+b.dataset.i].el.scrollIntoView({ behavior: S.reduced ? 'auto' : 'smooth', block: 'start' });
      });
    }

    document.addEventListener('s:track', e => {
      const s = e.detail.section;
      const id = s.coverOverride || s.cover;
      cv.innerHTML = s.dark ? '<div class="cv cv-vinylmini"></div>' : SCovers.html(id);
      title.textContent = s.title;
      sub.textContent = s.sub;
      bar.classList.remove('swap'); void bar.offsetWidth; bar.classList.add('swap');
      if (rail) S.$$('button', rail).forEach((b, i) => b.classList.toggle('on', i === e.detail.index));
    });
    document.addEventListener('s:progress', e => {
      fill.style.transform = `scaleX(${e.detail})`;
      const show = window.scrollY > window.innerHeight * 0.55;
      bar.classList.toggle('show', show);
      if (rail) rail.classList.toggle('show', show);
    });
  });
})();
;
/* 手机里的播放页：用 HTML 实时搭建（不是截图），颜色才能跟着封面变
 * - 5 种晕染方式（GlowMode）  - 4 种切歌动效（PlayerSwitchMotion）
 * - 封面取色 → 晕染 / 水滴键颜色（PlayButtonColorMode.COVER）
 */
(function () {
  const S = window.Sonance;
  const GLOW_HINT = {
    bottom: '只从封面下边缘向外晕开',
    sides: '从封面左右两侧向外晕开',
    around: '封面四条边都向外晕开，上方也带一点',
    full: '扩散到屏幕边缘才淡出，范围最大',
    immersive: '整屏铺满封面主色，浓度更深，底部按钮区自动减淡'
  };
  const MOTION_HINT = {
    slide: '双封面并排横滑切换，标题同步随动',
    depth: '旧封面退后滑离，新封面弹性推入，文字错峰轻跟',
    tilt: '空间透视旋换 + 丝绸高光掠过，歌名纵向微滚切换',
    dissolve: '光学呼吸缩放 + 主色光雾溶切，东方留白静谧手感'
  };
  const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  function phoneColors(glow) {
    const c = SColor;
    return {
      pc: c.pastel(glow, 0.70, 0.42),
      pc2: c.pastel(glow, 0.88, 0.30),
      pcd: c.pastel(glow, 0.60, 0.40),
      base: c.pastel(glow, 0.93, 0.12),
      drop: c.deep(glow, 0.44)
    };
  }

  function create(root, opts = {}) {
    const ic = SIcons.svg;
    root.innerHTML = `
      <div class="ph-screen">
        <div class="ph-glows">${['bottom', 'sides', 'around', 'full', 'immersive'].map(g => `<i data-g="${g}"></i>`).join('')}</div>
        <div class="ph-status"><span>13:15</span><span class="ph-sicons"><i></i><i></i><b>53</b></span></div>
        <div class="ph-top">
          <span class="ph-circ">${ic('chevronDown')}</span>
          <span class="ph-viz"><i></i><i></i><i></i></span>
          <span class="ph-caps">${ic('vinyl')}<em></em>${ic('more')}</span>
        </div>
        <div class="ph-coverbox"><div class="ph-covers"></div></div>
        <div class="ph-badge"><span class="hires-badge"><b>Hi·Res</b><small>AUDIO</small></span></div>
        <div class="ph-info">
          <span class="ph-heart">${ic('heart')}</span>
          <div class="ph-meta"><b></b><span></span><small></small></div>
          <span class="ph-lypill">${ic('lyrics')}词</span>
        </div>
        <div class="ph-prog">
          <div class="ph-track"><i></i><b></b></div>
          <div class="ph-times"><span class="t0">0:00</span><span>1.0×</span><span class="t1">0:00</span></div>
        </div>
        <div class="ph-ctrl">
          <button type="button" class="ph-btn acc" tabindex="-1" aria-hidden="true">${ic('shuffle')}</button>
          <button type="button" class="ph-btn ph-prev" aria-label="上一首">${ic('prev')}</button>
          <s-drop playing class="ph-drop" role="button" aria-label="播放 / 暂停">${ic('pause')}</s-drop>
          <button type="button" class="ph-btn ph-next" aria-label="下一首">${ic('next')}</button>
          <button type="button" class="ph-btn" tabindex="-1" aria-hidden="true">${ic('queue')}</button>
        </div>
        <div class="ph-vol">${ic('volume')}<div class="ph-vtrack"><i></i></div><span class="acc">${ic('sliders')}</span></div>
        <div class="ph-home"></div>
      </div>`;

    const scr = S.$('.ph-screen', root);
    const covers = S.$('.ph-covers', root);
    const meta = S.$('.ph-meta', root);
    const fill = S.$('.ph-track i', root), knob = S.$('.ph-track b', root);
    const t0 = S.$('.t0', root), t1 = S.$('.t1', root);
    const drop = S.$('.ph-drop', root);

    const st = {
      list: opts.covers || ['sunset', 'halftone', 'checker', 'conicA'],
      idx: 0, glow: opts.glow || 'around', motion: opts.motion || 'slide',
      colors: null, playing: true, pos: 27, dur: 296, custom: null
    };

    function applyColors(c) {
      scr.style.setProperty('--pc', c.pc);
      scr.style.setProperty('--pc2', c.pc2);
      scr.style.setProperty('--pcd', c.pcd);
      scr.style.setProperty('--pbase', c.base);
      scr.style.setProperty('--drop', c.drop);
    }
    function setColors(glowHex, instant) {
      const to = phoneColors(glowHex);
      if (!st.colors || instant) { st.colors = to; applyColors(to); return; }
      S.tweenColors(scr, st.colors, to, 800, cur => { st.colors = cur; applyColors(cur); });
    }
    function setGlowMode(g) {
      st.glow = g;
      S.$$('.ph-glows i', root).forEach(i => i.classList.toggle('on', i.dataset.g === g));
      scr.dataset.glow = g;
    }
    function metaFor(item) {
      if (item.custom) return { title: item.title, artist: '你的图片', album: '本地预览' };
      const c = SCovers.get(item.id);
      return { title: c.title, artist: c.artist, album: c.title + ' · Single' };
    }
    function slideHtml(item) {
      if (item.custom) return `<div class="cv cv-img" style="background-image:url('${item.url}')"></div>`;
      return SCovers.html(item.id);
    }
    function current() { return st.custom || { id: st.list[st.idx] }; }
    function renderMeta(item) {
      const m = metaFor(item);
      meta.innerHTML = `<b>${m.title}</b><span>${m.artist}</span><small>${m.album}</small>`;
    }

    let lastSec = -1, lastDur = -1, barAcc = 1;

    function show(item, dir = 1, first = false) {
      const slide = document.createElement('div');
      slide.className = 'ph-slide';
      slide.innerHTML = slideHtml(item);
      const old = S.$$('.ph-slide', covers);
      const m = st.motion;
      if (!first && !S.reduced) {
        covers.style.setProperty('--dir', dir);
        slide.classList.add('in-' + m);
        old.forEach(o => { o.classList.remove('in-slide', 'in-depth', 'in-tilt', 'in-dissolve'); o.classList.add('out-' + m); setTimeout(() => o.remove(), 760); });
        meta.classList.remove('swap'); void meta.offsetWidth; meta.classList.add('swap');
        if (m === 'tilt') { const sh = document.createElement('i'); sh.className = 'ph-sheen'; covers.appendChild(sh); setTimeout(() => sh.remove(), 900); }
        if (m === 'dissolve') { const fog = document.createElement('i'); fog.className = 'ph-fog'; covers.appendChild(fog); setTimeout(() => fog.remove(), 900); }
      } else old.forEach(o => o.remove());
      covers.appendChild(slide);
      renderMeta(item);
      st.pos = first ? st.pos : 0;
      st.dur = 180 + Math.floor(Math.random() * 140);
      lastSec = -1; lastDur = -1; barAcc = 1;
      const glowHex = item.custom ? item.glow : SCovers.get(item.id).glow;
      setColors(glowHex, first);
      root.dispatchEvent(new CustomEvent('ph:cover', { detail: { item, glow: glowHex } }));
    }

    function step(d) {
      st.custom = null;
      st.idx = (st.idx + d + st.list.length) % st.list.length;
      show(current(), d);
    }
    function setCover(id) {
      st.custom = null;
      const i = st.list.indexOf(id);
      const d = i >= st.idx ? 1 : -1;
      st.idx = i < 0 ? 0 : i;
      show(current(), d);
    }
    function setCustom(url, glow, title) {
      st.custom = { custom: true, url, glow, title };
      show(st.custom, 1);
    }

    S.$('.ph-prev', root).addEventListener('click', () => step(-1));
    S.$('.ph-next', root).addEventListener('click', () => step(1));
    drop.addEventListener('click', () => {
      st.playing = !st.playing;
      drop.toggleAttribute('playing', st.playing);
      S.$('.drop-ic', drop).innerHTML = ic(st.playing ? 'pause' : 'play');
      scr.classList.toggle('paused', !st.playing);
    });

    // 进度推进（文本按整秒、进度条约 4Hz 更新，避免每帧无意义 DOM 写入）
    S.tick(dt => {
      if (st.playing && S.motionOn) st.pos = Math.min(st.dur, st.pos + dt);
      barAcc += dt;
      if (barAcc >= 0.25) {
        barAcc = 0;
        const k = st.pos / st.dur;
        fill.style.transform = `scaleX(${k})`;
        knob.style.left = (k * 100).toFixed(2) + '%';
      }
      const sec = Math.floor(st.pos);
      if (sec !== lastSec) { lastSec = sec; t0.textContent = fmt(sec); }
      if (st.dur !== lastDur) { lastDur = st.dur; t1.textContent = fmt(st.dur); }
    }, root);

    setGlowMode(st.glow);
    show(current(), 1, true);

    return {
      root, st, step, setCover, setCustom, setGlowMode,
      setMotion: m => { st.motion = m; },
      get playing() { return st.playing && S.motionOn; }
    };
  }

  window.SPhone = { create, GLOW_HINT, MOTION_HINT };

  /* ---------- 页面接线 ---------- */
  S.onReady(() => {
    // Hero：自动换歌
    const heroEl = S.$('[data-phone="hero"]');
    if (heroEl) {
      const heroSec = S.$('#hero');
      const hp = create(heroEl, { covers: ['sunset', 'halftone', 'checker', 'conicA', 'dotsCoral'], glow: 'around' });
      heroEl.addEventListener('ph:cover', e => {
        S.glow.setSectionGlow(heroSec, e.detail.glow);
        const sec = S.glow.sections.find(s => s.el === heroSec);
        if (sec && e.detail.item.id) sec.coverOverride = e.detail.item.id;
      });
      let acc = 0;
      S.tick(dt => {
        if (!hp.playing || document.hidden) return;
        acc += dt;
        if (acc > 6) { acc = 0; hp.step(1); }
      }, heroEl);
    }

    // 播放页演示
    const demoEl = S.$('[data-phone="demo"]');
    if (!demoEl) return;
    const sec = S.$('#player');
    const list = ['conicA', 'sunset', 'halftone', 'checker', 'rings', 'dotsCoral', 'type', 'conicB'];
    const ph = create(demoEl, { covers: list, glow: 'around' });
    const dots = S.$('#coverDots');
    dots.innerHTML = list.map((id, i) => `<button type="button" role="radio" aria-checked="${i === 0}" aria-label="封面：${SCovers.get(id).title}" data-id="${id}" class="${i === 0 ? 'on' : ''}">${SCovers.html(id)}</button>`).join('');
    dots.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      ph.setCover(b.dataset.id);
    });
    demoEl.addEventListener('ph:cover', e => {
      S.glow.setSectionGlow(sec, e.detail.glow);
      const s = S.glow.sections.find(x => x.el === sec);
      if (s) s.coverOverride = e.detail.item.id || null;
      S.$$('button', dots).forEach(b => {
        const on = b.dataset.id === e.detail.item.id;
        b.classList.toggle('on', on); b.setAttribute('aria-checked', on);
      });
    });

    const seg = (id, fn) => {
      const el = S.$(id);
      el.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        S.$$('button', el).forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', x === b); });
        fn(b.dataset.v);
      });
    };
    seg('#glowSeg', v => { ph.setGlowMode(v); S.$('#glowHint').textContent = GLOW_HINT[v]; });
    seg('#motionSeg', v => { ph.setMotion(v); S.$('#motionHint').textContent = MOTION_HINT[v]; ph.step(1); });
    S.$('#swPrev').addEventListener('click', () => ph.step(-1));
    S.$('#swNext').addEventListener('click', () => ph.step(1));

    // 水滴 / 普通
    const shapeDemo = S.$('#shapeDemo');
    seg('#shapeSeg', v => {
      shapeDemo.setAttribute('shape', v);
      S.$$('.ph-drop').forEach(d => d.setAttribute('shape', v));
    });
    shapeDemo.addEventListener('click', () => {
      const p = !shapeDemo.hasAttribute('playing');
      shapeDemo.toggleAttribute('playing', p);
      S.$('.drop-ic', shapeDemo).innerHTML = SIcons.svg(p ? 'pause' : 'play');
    });

    // 拖入 / 选择自己的图片：本地取色
    const zone = S.$('#dropZone'), file = S.$('#coverFile');
    function useFile(f) {
      if (!f || !f.type.startsWith('image/')) { S.toast('请选择一张图片'); return; }
      const url = URL.createObjectURL(f);
      const img = new Image();
      img.onload = () => {
        const { main } = SColor.extract(img);
        ph.setCustom(url, main, f.name.replace(/\.[^.]+$/, '').slice(0, 18) || '我的封面');
        S.toast('已从你的图片里取色：' + main.toUpperCase());
      };
      img.src = url;
    }
    file.addEventListener('change', () => useFile(file.files[0]));
    ['dragenter', 'dragover'].forEach(t => zone.addEventListener(t, e => { e.preventDefault(); zone.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(t => zone.addEventListener(t, e => { e.preventDefault(); zone.classList.remove('over'); }));
    zone.addEventListener('drop', e => useFile(e.dataTransfer.files[0]));
  });
})();
;
/* 五种全屏歌词演示（对应 App 的 LyricStyle）+ TTML 逐字高亮
 * 示例歌词为本站原创文字。
 */
(function () {
  const S = window.Sonance;
  const LINES = [
    { t: 0, x: '作词：山水有清音', credit: true },
    { t: 1.6, x: '作曲：Sonance', credit: true },
    { t: 3.2, x: '编曲：林间', credit: true },
    { t: 4.8, x: '风从山那边过来', tr: 'The wind comes over the hill' },
    { t: 8.4, x: '把昨天的雨 吹成今天的云', tr: "Turning yesterday's rain into today's clouds" },
    { t: 12.0, x: '我把耳机摘下一半', tr: 'I take off half of my headphones' },
    { t: 15.6, x: '听见溪水 在练习换气', tr: 'And hear the creek practising its breath' },
    { t: 19.2, x: '不必丝 也不必竹', tr: 'No need for strings, no need for flutes' },
    { t: 22.8, x: '整座山 都在轻轻地唱', tr: 'The whole mountain is softly singing' },
    { t: 26.4, x: '你听 那是清音', tr: 'Listen, that is the clear sound' },
    { t: 30.0, x: '落在每一片叶子的背面', tr: 'Landing on the back of every leaf' },
    { t: 33.6, x: '（间奏）', credit: true }
  ];
  const LOOP = 37.2;
  const HINT = {
    classic: '经典列表：当前句放大高亮，其余行逐级变淡',
    vertical: '竖屏歌词：从右往左竖排，像翻一本诗集',
    fluid: '流体声波景深：前后行逐级虚化，背景随声波起伏',
    vinyl: '黑胶环形声轨：歌词沿唱片外沿排成一道弧，带时间戳',
    spatial: '3D 双向深空星廊：歌词从远处左右交错飞来'
  };
  const ts = t => `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

  S.onReady(() => {
    const stage = S.$('#lyStage');
    if (!stage) return;
    const tabs = S.$('#lyTabs');
    let style = 'classic', els = [], p = 3, t = 4.8, idx = 3, needLayout = true;

    function build() {
      stage.className = 'ly-stage glass ly-' + style;
      let pre = '';
      if (style === 'fluid') pre = `<svg class="ly-wave" viewBox="0 0 1200 200" preserveAspectRatio="none" aria-hidden="true"><path d="M0 120 Q150 60 300 120 T600 120 T900 120 T1200 120 V200 H0Z"/><path d="M0 140 Q150 90 300 140 T600 140 T900 140 T1200 140 V200 H0Z"/></svg>`;
      if (style === 'vinyl') pre = '<div class="ly-disc" aria-hidden="true"><i></i></div><span class="ly-needle" aria-hidden="true"></span>';
      if (style === 'spatial') pre = '<div class="ly-stars" aria-hidden="true"></div>';
      stage.innerHTML = pre + `<p class="ly-hint">${HINT[style]}</p>` + LINES.map((l, k) =>
        `<div class="ly-line${l.credit ? ' credit' : ''}" data-k="${k}">${style === 'vinyl' ? `<small>${ts(l.t)}</small>` : ''}<span>${l.x}</span>${l.tr ? `<em>${l.tr}</em>` : ''}</div>`).join('');
      els = S.$$('.ly-line', stage);
      needLayout = false;
      layout(true);
    }

    function layout(force) {
      const W = stage.clientWidth, H = stage.clientHeight;
      const small = W < 560;
      const disc = style === 'vinyl' && force ? S.$('.ly-disc', stage) : null;
      els.forEach((el, k) => {
        const d = k - p;
        const ad = Math.abs(d);
        const cur = k === idx;
        if (cur !== el.__cur || force) { el.classList.toggle('cur', cur); el.__cur = cur; }
        let tr = '', op = 1, blur = 0;
        if (style === 'classic' || style === 'fluid') {
          const lh = small ? 46 : 58;
          const sc = cur ? 1 : 0.86;
          tr = `translate(-50%, -50%) translateY(${d * lh + (d > 0 ? 14 : 0)}px) scale(${sc})`;
          op = ad > 4.5 ? 0 : 1 - ad * 0.2;
          if (style === 'fluid') { blur = Math.round(Math.min(6, ad * 1.6) * 2) / 2; tr += ` scale(${1 - Math.min(ad, 4) * 0.035})`; }
        } else if (style === 'vertical') {
          const cw = small ? 58 : 84;
          const extra = d > 0 ? 12 : d < 0 ? -12 : 0;
          tr = `translate(-50%, -50%) translateX(${(-d * cw - extra).toFixed(1)}px)`;
          op = ad > 4.2 ? 0 : 1 - ad * 0.22;
        } else if (style === 'vinyl') {
          const R = Math.min(H * 0.46, W * 0.42);
          const cx = -R * 0.38, cy = H / 2;
          const th = d * (small ? 15 : 12.5) * Math.PI / 180;
          const rl = R + (small ? 26 : 40);
          const x = cx + rl * Math.cos(th), y = cy + rl * Math.sin(th);
          tr = `translate(${x}px, ${y}px) rotate(${th}rad) translateY(-50%)`;
          op = ad > 5.5 ? 0 : 1 - ad * 0.16;
          if (disc) { disc.style.width = disc.style.height = (R * 2) + 'px'; disc.style.left = (cx - R) + 'px'; disc.style.top = (cy - R) + 'px'; }
        } else if (style === 'spatial') {
          const t = S.clamp(1 - ad, 0, 1);
          const emph = t * t * (3 - 2 * t);
          const future = d > 0;
          const z = -ad * (future ? 140 : 120) + 30 * emph;
          const persp = 760 / (760 - z);
          const slot = small ? 76 : 102;
          const side = k % 2 === 0 ? 1 : -1;
          const x = side * (future ? 46 : -36) * Math.min(ad, 2.6) * persp * (small ? 0.55 : 1);
          const y = -d * slot;
          const sc = Math.max(0.68, 1 - ad * 0.08) * persp;
          const rx = future ? -ad * 5 : 12 * (1 - emph);
          tr = `translate(-50%, -50%) translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, ${z.toFixed(1)}px) rotateX(${rx.toFixed(1)}deg) scale(${sc.toFixed(3)})`;
          const edge = S.clamp(3.2 - ad, 0, 1);
          op = ((future ? Math.max(0.12, 0.78 - ad * 0.2) : Math.max(0.08, 0.52 - ad * 0.18)) * (1 - emph) + emph) * edge;
        }
        el.style.transform = tr;
        el.style.opacity = op.toFixed(3);
        if (el.__blur !== blur || force) {
          el.__blur = blur;
          el.style.filter = blur > 0.05 ? `blur(${blur}px)` : '';
        }
      });
    }

    tabs.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      S.$$('button', tabs).forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b); });
      style = b.dataset.style;
      build();
    });
    window.addEventListener('resize', () => layout(true));
    build();

    S.tick(dt => {
      if (S.motionOn) t = (t + dt) % LOOP;
      let n = 0;
      LINES.forEach((l, k) => { if (t >= l.t) n = k; });
      if (n !== idx) {
        if (n < idx) p = n - 1; // 循环回到开头时只滑一行，不倒卷整段
        idx = n;
        needLayout = true;
      }
      if (Math.abs(p - idx) >= 0.002) {
        p = S.approach(p, idx, 7, dt);
        if (Math.abs(p - idx) < 0.002) p = idx;
        needLayout = true;
      }
      if (needLayout) {
        needLayout = false;
        layout(false);
      }
    }, stage);

    /* ---------- TTML 逐字 ---------- */
    const box = S.$('#ttml');
    if (box) {
      const words = ['听', '见', '溪', '水', ' ', '在', '练', '习', '换', '气'];
      const dur = [0.32, 0.32, 0.36, 0.5, 0.2, 0.28, 0.32, 0.32, 0.38, 0.9];
      let acc = 0;
      const spans = words.map((w, i) => { const b = acc; acc += dur[i]; return { w, b, e: acc }; });
      const total = acc + 1.4;
      box.innerHTML = spans.map(s => `<span>${s.w === ' ' ? '&nbsp;' : s.w}</span>`).join('');
      S.$('#ttmlTr').textContent = 'And hear the creek practising its breath';
      const sp = S.$$('span', box);
      let tt = 0;
      S.tick(dt => {
        if (!S.motionOn) return;
        tt = (tt + dt) % total;
        spans.forEach((s, i) => {
          const k = S.clamp((tt - s.b) / (s.e - s.b), 0, 1);
          if (sp[i].__k === k) return;
          sp[i].__k = k;
          sp[i].style.setProperty('--p', (k * 100).toFixed(1) + '%');
          sp[i].style.transform = k > 0 && k < 1 ? `translateY(${(-2.5 * Math.sin(Math.PI * k)).toFixed(2)}px)` : '';
        });
      }, box);
    }
  });
})();
;
/* 律动柱：伪频谱 + 帧率无关物理衰减（解析解，按 dt 计算）
 * 可选：麦克风真实频谱（Web Audio AnalyserNode，对数分箱 + 自动增益）
 */
(function () {
  const S = window.Sonance;

  S.onReady(() => {
    const cv = S.$('#vizCanvas');
    if (!cv) return;
    const ctx = cv.getContext('2d');
    let W = 0, H = 0, dpr = 1, N = 40;
    let style = 'bars';
    let h = [], peak = [], peakV = [];
    let analyser = null, freq = null, agc = 0.25, stream = null;

    function resize() {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = cv.clientWidth; H = cv.clientHeight;
      cv.width = W * dpr; cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      N = W < 560 ? 26 : W < 900 ? 36 : 44;
      h = new Array(N).fill(0); peak = new Array(N).fill(0); peakV = new Array(N).fill(0);
    }
    resize();
    window.addEventListener('resize', resize);

    // 伪频谱：低频带节拍，高频带噪声，整体向高频滚降
    function fakeTarget(i, t) {
      const x = i / (N - 1);
      const beat = Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 * 1.9)), 10);   // ~114 BPM
      const off = Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 * 1.9 + 2.2)), 14);
      const roll = 0.95 - x * 0.62;
      const n1 = 0.5 + 0.5 * Math.sin(t * 3.1 + i * 0.9) * Math.sin(t * 1.7 + i * 0.37);
      const n2 = 0.5 + 0.5 * Math.sin(t * 7.3 + i * 2.3);
      let v = roll * (0.42 + 0.38 * n1 + 0.12 * n2);
      v += (1 - x) * (1 - x) * beat * 0.55 + (x > 0.35 && x < 0.75 ? off * 0.25 : 0);
      if (x > 0.82) v *= 0.4 + 0.6 * n2;
      return S.clamp(v, 0.02, 1);
    }
    function micTarget(i) {
      const bins = freq.length;
      const lo = Math.floor(Math.pow(bins, i / N)), hi = Math.max(lo + 1, Math.floor(Math.pow(bins, (i + 1) / N)));
      let m = 0;
      for (let b = lo; b < hi && b < bins; b++) m = Math.max(m, freq[b]);
      return m / 255;
    }

    const ATTACK = 28, RELEASE = 5.5, G = 2.6;
    function update(dt, t) {
      let mx = 0;
      if (analyser) { analyser.getByteFrequencyData(freq); }
      for (let i = 0; i < N; i++) {
        let tg = analyser ? micTarget(i) : fakeTarget(i, t);
        if (analyser) { mx = Math.max(mx, tg); tg = S.clamp(tg / Math.max(agc, 0.08), 0, 1); }
        if (!S.motionOn) tg = h[i];
        // 帧率无关：指数趋近的解析解（上升快、下降慢）
        h[i] = S.approach(h[i], tg, tg > h[i] ? ATTACK : RELEASE, dt);
        // 峰值帽：匀加速下落的解析解 y = y0 - v0·dt - ½g·dt²
        if (h[i] >= peak[i]) { peak[i] = h[i]; peakV[i] = 0; }
        else { peak[i] = Math.max(h[i], peak[i] - peakV[i] * dt - 0.5 * G * dt * dt); peakV[i] += G * dt; }
      }
      if (analyser) agc = mx > agc ? S.approach(agc, mx, 12, dt) : S.approach(agc, mx, 0.6, dt);
    }

    function draw() {
      ctx.clearRect(0, 0, W, H);
      const base = style === 'mirror' ? H * 0.5 : H * 0.78;
      const maxH = style === 'mirror' ? H * 0.42 : H * 0.68;
      const gap = Math.max(3, W / N * 0.26), bw = (W - gap * (N + 1)) / N;
      const grad = ctx.createLinearGradient(0, base - maxH, 0, base);
      grad.addColorStop(0, '#2346A8'); grad.addColorStop(1, '#3D5BD9');

      if (style === 'wave') {
        const pts = h.map((v, i) => [gap + i * (bw + gap) + bw / 2, base - v * maxH]);
        const path = new Path2D();
        path.moveTo(0, base); path.lineTo(pts[0][0], pts[0][1]);
        for (let i = 0; i < pts.length - 1; i++) {
          const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
          path.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
        }
        path.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]); path.lineTo(W, base); path.closePath();
        const fg = ctx.createLinearGradient(0, base - maxH, 0, base);
        fg.addColorStop(0, 'rgba(35,70,168,.85)'); fg.addColorStop(1, 'rgba(61,91,217,.25)');
        ctx.fillStyle = fg; ctx.fill(path);
        ctx.strokeStyle = '#2346A8'; ctx.lineWidth = 2.5; ctx.stroke(path);
        // 倒影
        ctx.save(); ctx.translate(0, base * 2); ctx.scale(1, -1); ctx.globalAlpha = 0.14; ctx.fillStyle = '#3D5BD9'; ctx.fill(path); ctx.restore();
        return;
      }
      for (let i = 0; i < N; i++) {
        const x = gap + i * (bw + gap);
        const bh = Math.max(2, h[i] * maxH);
        ctx.fillStyle = grad;
        if (style === 'mirror') {
          ctx.fillRect(x, base - bh, bw, bh * 2);
        } else {
          ctx.fillRect(x, base - bh, bw, bh);
          // 倒影（复刻截图：地平线下半透明倒影）
          const rg = ctx.createLinearGradient(0, base, 0, base + bh * 0.5);
          rg.addColorStop(0, 'rgba(61,91,217,.28)'); rg.addColorStop(1, 'rgba(61,91,217,0)');
          ctx.fillStyle = rg; ctx.fillRect(x, base + 2, bw, bh * 0.5);
          // 峰值帽
          ctx.fillStyle = 'rgba(35,70,168,.9)';
          ctx.fillRect(x, base - peak[i] * maxH - 6, bw, 3);
        }
      }
      if (style !== 'mirror') {
        ctx.fillStyle = 'rgba(255,255,255,.55)';
        ctx.fillRect(0, base, W, 1.5);
      }
    }

    const hz = S.$('#vizHz');
    let hzAcc = 0;
    S.tick((dt, t) => {
      update(dt, t);
      draw();
      hzAcc += dt;
      if (hzAcc > 0.5) { hzAcc = 0; hz.textContent = Math.round(S.fps) + ' Hz'; }
    }, cv);

    const seg = S.$('#vizSeg');
    seg.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      S.$$('button', seg).forEach(x => x.classList.toggle('on', x === b));
      style = b.dataset.v;
    });

    const mic = S.$('#vizMic');
    mic.addEventListener('click', async () => {
      if (analyser) {
        stream.getTracks().forEach(t => t.stop());
        analyser = null; stream = null;
        if (S.bgm) S.bgm.duck(false);
        mic.classList.remove('on'); S.$('span', mic).textContent = '用麦克风试试';
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const ac = new (window.AudioContext || window.webkitAudioContext)();
        const src = ac.createMediaStreamSource(stream);
        analyser = ac.createAnalyser();
        analyser.fftSize = 2048; analyser.smoothingTimeConstant = 0.5;
        freq = new Uint8Array(analyser.frequencyBinCount);
        src.connect(analyser);
        if (S.bgm) S.bgm.duck(true);
        mic.classList.add('on'); S.$('span', mic).textContent = '关闭麦克风';
        S.toast('正在用麦克风采样，声音不会离开你的浏览器');
      } catch (err) {
        S.toast('没有拿到麦克风权限，继续用演示频谱');
      }
    });
  });
})();
;
/* 封面墙：Bento 拼贴 + 点击抽出唱片（FLIP）+ 向下拖动插回墙上 */
(function () {
  const S = window.Sonance;
  const ORDER = [
    ['conicA', 2], ['rings', 1], ['sunset', 1], ['dotsCoral', 1], ['type', 1],
    ['checker', 2], ['dotsLime', 1], ['halftone', 1], ['arcs', 1], ['conicB', 2],
    ['dusk', 1], ['mint', 1], ['sunset', 1], ['rings', 1], ['dotsCoral', 1], ['conicA', 1],
    ['type', 1], ['halftone', 1]
  ];
  const LYR = [
    ['风从山那边过来', '把昨天的雨 吹成今天的云'],
    ['我把耳机摘下一半', '听见溪水 在练习换气'],
    ['不必丝 也不必竹', '整座山 都在轻轻地唱'],
    ['你听 那是清音', '落在每一片叶子的背面']
  ];

  S.onReady(() => {
    const grid = S.$('#wallGrid');
    const ov = S.$('#wallFocus');
    if (!grid || !ov) return;
    const ic = SIcons.svg;

    grid.innerHTML = ORDER.map(([id, s], i) =>
      `<button type="button" class="wall-card s${s}" data-id="${id}" aria-label="播放：${SCovers.get(id).title}">${SCovers.html(id, { cap: true })}</button>`).join('');

    ov.innerHTML = `
      <div class="wf-bg"></div>
      <button type="button" class="wf-close" aria-label="把唱片插回墙上">${ic('chevronDown')}</button>
      <button type="button" class="wf-tune" aria-hidden="true" tabindex="-1">${ic('sliders')}</button>
      <div class="wf-stage">
        <div class="wf-art">
          <div class="wf-disc"><div class="wf-label"></div></div>
          <div class="wf-sleeve"></div>
        </div>
        <div class="wf-lyrics"><p class="a"></p><p class="b"></p></div>
        <div class="wf-info"><b></b><span></span></div>
        <div class="wf-prog"><i></i></div>
        <div class="wf-times"><span class="w0">0:01</span><span class="w1">3:48</span></div>
        <div class="wf-ctrl">
          <button type="button" class="wf-prev" aria-label="上一张">${ic('prev')}</button>
          <s-drop playing class="wf-drop">${ic('pause')}</s-drop>
          <button type="button" class="wf-next" aria-label="下一张">${ic('next')}</button>
        </div>
        <span class="wf-queue">${ic('queue')}曲目列表 · 1 首</span>
        <p class="wf-hint">↓ 向下拖动，把唱片插回墙上</p>
      </div>`;
    SIcons.hydrate(ov);

    const stage = S.$('.wf-stage', ov), sleeve = S.$('.wf-sleeve', ov), disc = S.$('.wf-disc', ov), label = S.$('.wf-label', ov);
    const bg = S.$('.wf-bg', ov);
    let curCard = null, busy = false, lyrI = 0, pos = 0, dur = 228;

    function setCover(id) {
      const c = SCovers.get(id);
      sleeve.innerHTML = SCovers.html(id, { cap: true });
      label.innerHTML = SCovers.html(id);
      S.$('.wf-info b', ov).textContent = c.title;
      S.$('.wf-info span', ov).textContent = c.artist;
      ov.style.setProperty('--wf-top', SColor.deep(c.glow, 0.36, 0.45));
      ov.style.setProperty('--wf-mid', SColor.deep(c.glow, 0.16, 0.35));
      ov.style.setProperty('--drop', SColor.deep(c.glow, 0.48, 0.45));
      pos = 1; dur = 180 + Math.floor(Math.random() * 120);
    }

    function flipFrom(rect) {
      const to = sleeve.getBoundingClientRect();
      const sx = rect.width / to.width;
      sleeve.style.transition = 'none';
      sleeve.style.transform = `translate(${rect.left - to.left}px, ${rect.top - to.top}px) scale(${sx})`;
      void sleeve.offsetWidth;
      sleeve.style.transition = '';
      sleeve.style.transform = '';
    }

    function open(card) {
      if (busy) return;
      busy = true;
      curCard = card;
      const rect = card.getBoundingClientRect();
      setCover(card.dataset.id);
      ov.classList.add('open');
      ov.setAttribute('aria-hidden', 'false');
      document.documentElement.classList.add('wall-lock');
      card.classList.add('lifted');
      flipFrom(rect);
      setTimeout(() => { ov.classList.add('disc-out'); busy = false; S.$('.wf-close', ov).focus({ preventScroll: true }); }, S.reduced ? 0 : 520);
    }

    function close() {
      if (busy || !ov.classList.contains('open')) return;
      busy = true;
      ov.classList.remove('disc-out');
      const back = () => {
        const card = curCard;
        if (card) {
          const r = card.getBoundingClientRect(), to = sleeve.getBoundingClientRect();
          // 拖动时 stage 有位移，先取当前位置再飞回
          sleeve.style.transform = `translate(${r.left - to.left}px, ${r.top - to.top}px) scale(${r.width / to.width})`;
        }
        ov.classList.add('closing');
        stage.style.transition = ''; bg.style.opacity = '';
        setTimeout(() => {
          ov.classList.remove('open', 'closing');
          ov.setAttribute('aria-hidden', 'true');
          stage.style.transform = '';
          sleeve.style.transition = 'none'; sleeve.style.transform = ''; void sleeve.offsetWidth; sleeve.style.transition = '';
          document.documentElement.classList.remove('wall-lock');
          if (card) { card.classList.remove('lifted'); card.focus({ preventScroll: true }); }
          busy = false;
        }, S.reduced ? 0 : 560);
      };
      setTimeout(back, S.reduced ? 0 : 260);
    }

    grid.addEventListener('click', e => { const c = e.target.closest('.wall-card'); if (c) open(c); });
    S.$('#wallRandom').addEventListener('click', () => {
      const cards = S.$$('.wall-card', grid);
      open(cards[Math.floor(Math.random() * cards.length)]);
    });
    S.$('.wf-close', ov).addEventListener('click', close);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });

    function hop(d) {
      const cards = S.$$('.wall-card', grid);
      let i = cards.indexOf(curCard);
      i = (i + d + cards.length) % cards.length;
      curCard.classList.remove('lifted');
      curCard = cards[i];
      curCard.classList.add('lifted');
      ov.classList.remove('disc-out');
      setTimeout(() => { setCover(curCard.dataset.id); ov.classList.add('disc-out'); }, 280);
    }
    S.$('.wf-prev', ov).addEventListener('click', () => hop(-1));
    S.$('.wf-next', ov).addEventListener('click', () => hop(1));
    const wdrop = S.$('.wf-drop', ov);
    wdrop.addEventListener('click', () => {
      const p = !wdrop.hasAttribute('playing');
      wdrop.toggleAttribute('playing', p);
      S.$('.drop-ic', wdrop).innerHTML = ic(p ? 'pause' : 'play');
      ov.classList.toggle('paused', !p);
    });

    // 向下拖动：跟手位移，松手超过阈值就插回墙上
    let y0 = null, dy = 0;
    stage.addEventListener('pointerdown', e => {
      if (e.target.closest('button, s-drop')) return;
      y0 = e.clientY; dy = 0;
      stage.setPointerCapture(e.pointerId);
      stage.style.transition = 'none';
    });
    stage.addEventListener('pointermove', e => {
      if (y0 == null) return;
      dy = Math.max(0, e.clientY - y0);
      const k = Math.min(1, dy / 400);
      stage.style.transform = `translateY(${dy}px) scale(${1 - k * 0.12})`;
      bg.style.opacity = String(1 - k * 0.6);
    });
    const end = () => {
      if (y0 == null) return;
      y0 = null;
      stage.style.transition = '';
      if (dy > 120) close();
      else { stage.style.transform = ''; bg.style.opacity = ''; }
    };
    stage.addEventListener('pointerup', end);
    stage.addEventListener('pointercancel', end);

    // 歌词与进度
    const pa = S.$('.wf-lyrics .a', ov), pb = S.$('.wf-lyrics .b', ov);
    const fill = S.$('.wf-prog i', ov), w0 = S.$('.w0', ov), w1 = S.$('.w1', ov);
    let la = 0;
    const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
    pa.textContent = LYR[0][0]; pb.textContent = LYR[0][1];
    S.tick(dt => {
      if (!ov.classList.contains('open') || ov.classList.contains('paused') || !S.motionOn) return;
      pos = Math.min(dur, pos + dt);
      fill.style.transform = `scaleX(${pos / dur})`;
      w0.textContent = fmt(pos); w1.textContent = fmt(dur);
      la += dt;
      if (la > 3.6) {
        la = 0; lyrI = (lyrI + 1) % LYR.length;
        pa.classList.add('swap'); pb.classList.add('swap');
        setTimeout(() => { pa.textContent = LYR[lyrI][0]; pb.textContent = LYR[lyrI][1]; pa.classList.remove('swap'); pb.classList.remove('swap'); }, 260);
      }
    });
  });
})();
;
/* 音效工作室交互：音色预设、10 段 64-bit 风格均衡器曲线、A/B 对比、声场效果、伴奏消音与可选 Web Audio 试听 */
(function () {
  const S = window.Sonance;

  function fmtFreq(f) {
    return f >= 1000 ? (f / 1000) + 'k' : String(f);
  }
  function fmtDb(v) {
    const r = Math.abs(v) < 0.05 ? 0 : v;
    return (r > 0 ? '+' : '') + r.toFixed(1);
  }
  // 将 10 个频点 (-12..+12 dB) 映射成 SVG 路径（Catmull-Rom 转三次贝塞尔）
  function buildCurve(vals, w, h, padX, padY) {
    const n = vals.length;
    const pts = vals.map((db, i) => [
      padX + (i / (n - 1)) * (w - padX * 2),
      padY + ((12 - S.clamp(db, -12, 12)) / 24) * (h - padY * 2)
    ]);
    let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
    for (let i = 0; i < n - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[Math.min(n - 1, i + 2)];
      const c1x = p1[0] + (p2[0] - p0[0]) / 6;
      const c1y = S.clamp(p1[1] + (p2[1] - p0[1]) / 6, padY - 12, h - padY + 12);
      const c2x = p2[0] - (p3[0] - p1[0]) / 6;
      const c2y = S.clamp(p2[1] - (p3[1] - p1[1]) / 6, padY - 12, h - padY + 12);
      d += ` C${c1x.toFixed(1)},${c1y.toFixed(1)} ${c2x.toFixed(1)},${c2y.toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
    }
    return { d, pts };
  }

  S.onReady(() => {
    const panel = S.$('#studioPanel');
    const data = window.SONANCE_EQ;
    if (!panel || !data) return;

    const freqs = data.freqs;
    const presets = data.presets;
    const quickIds = ['off', 'extreme_hifi', 'vocal', 'bass', 'live', 'night'];

    const st = {
      cat: '全部',
      presetId: 'extreme_hifi',
      vals: [...presets[1].eq],
      targetVals: [...presets[1].eq],
      bypass: false, // false = A (开启), true = B (旁通)
      field: { width: 110, bass: 18, reverb: 14, bs2b: false, hpf: true },
      karaoke: false,
      karaDepth: 0
    };

    /* ---------- 1. 页签切换 ---------- */
    const tabBtns = S.$$('.studio-tabs button[data-tab]', panel);
    const panes = S.$$('.pane[data-pane]', panel);
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const k = btn.dataset.tab;
        tabBtns.forEach(b => b.classList.toggle('on', b === btn));
        panes.forEach(p => p.classList.toggle('on', p.dataset.pane === k));
      });
    });

    /* ---------- 2. 音色预设页签 ---------- */
    const catsEl = S.$('#presetCats', panel);
    const gridEl = S.$('#presetGrid', panel);
    const allCats = ['全部', ...data.categories];

    catsEl.innerHTML = allCats.map(c =>
      `<button type="button" data-cat="${c}" class="${c === st.cat ? 'on' : ''}">${c}</button>`
    ).join('');

    function renderPresets() {
      const list = st.cat === '全部' ? presets : presets.filter(p => p.cat === st.cat);
      gridEl.innerHTML = list.map(p => {
        const { d } = buildCurve(p.eq, 120, 38, 4, 6);
        const on = p.id === st.presetId;
        return `<button type="button" class="preset-card${on ? ' on' : ''}" data-pid="${p.id}">
          <div class="preset-top"><b>${p.name}</b><span class="preset-badge">${p.cat}</span></div>
          <p class="preset-desc">${p.desc}</p>
          <svg class="preset-mini" viewBox="0 0 120 38" aria-hidden="true">
            <line x1="4" y1="19" x2="116" y2="19" stroke="currentColor" stroke-opacity=".18" stroke-dasharray="2 2"/>
            <path d="${d}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>`;
      }).join('');
    }
    catsEl.addEventListener('click', e => {
      const b = e.target.closest('button[data-cat]');
      if (!b) return;
      st.cat = b.dataset.cat;
      S.$$('button', catsEl).forEach(x => x.classList.toggle('on', x === b));
      renderPresets();
    });

    /* ---------- 3. 均衡器页签 ---------- */
    const curveSvg = S.$('#eqCurve', panel);
    const slidersEl = S.$('#eqSliders', panel);
    const chipsEl = S.$('#eqChips', panel);
    const abBtn = S.$('#abToggle', panel);
    const listenBtn = S.$('#eqListen', panel);

    slidersEl.innerHTML = freqs.map((f, i) => `
      <div class="eq-col" data-i="${i}">
        <span class="eq-db tnum">${fmtDb(st.vals[i])}</span>
        <div class="eq-fader">
          <div class="eq-track"><i class="eq-zero"></i><b class="eq-fill"></b><em class="eq-thumb"></em></div>
          <input type="range" class="eq-range" min="-12" max="12" step="0.2" value="${st.vals[i]}" aria-label="${fmtFreq(f)} Hz 增益">
        </div>
        <span class="eq-freq tnum">${fmtFreq(f)}</span>
      </div>`).join('');

    const cols = S.$$('.eq-col', slidersEl);
    const inputs = cols.map(c => S.$('.eq-range', c));
    const dbLabels = cols.map(c => S.$('.eq-db', c));
    const fills = cols.map(c => S.$('.eq-fill', c));
    const thumbs = cols.map(c => S.$('.eq-thumb', c));

    chipsEl.innerHTML = quickIds.map(id => {
      const p = presets.find(x => x.id === id);
      return p ? `<button type="button" class="eq-chip${p.id === st.presetId ? ' on' : ''}" data-pid="${p.id}">${p.name}</button>` : '';
    }).join('');

    function syncChips() {
      S.$$('.eq-chip', chipsEl).forEach(c => c.classList.toggle('on', c.dataset.pid === st.presetId));
      S.$$('.preset-card', gridEl).forEach(c => c.classList.toggle('on', c.dataset.pid === st.presetId));
    }

    function applyPreset(id) {
      const p = presets.find(x => x.id === id);
      if (!p) return;
      st.presetId = id;
      st.targetVals = [...p.eq];
      if (st.bypass) {
        st.bypass = false;
        syncAB();
      }
      syncChips();
    }

    gridEl.addEventListener('click', e => {
      const card = e.target.closest('.preset-card[data-pid]');
      if (!card) return;
      applyPreset(card.dataset.pid);
      S.toast('已切换到预设：' + presets.find(p => p.id === card.dataset.pid).name);
    });

    chipsEl.addEventListener('click', e => {
      const chip = e.target.closest('.eq-chip[data-pid]');
      if (!chip) return;
      applyPreset(chip.dataset.pid);
    });

    inputs.forEach((inp, i) => {
      inp.addEventListener('input', () => {
        const v = parseFloat(inp.value);
        st.vals[i] = st.targetVals[i] = v;
        st.presetId = '';
        if (st.bypass) {
          st.bypass = false;
          syncAB();
        }
        syncChips();
        drawEq();
        syncAudio();
      });
    });

    function syncAB() {
      const sp = S.$$('span', abBtn);
      sp[0].classList.toggle('on', !st.bypass);
      sp[1].classList.toggle('on', st.bypass);
      abBtn.setAttribute('aria-pressed', String(st.bypass));
      slidersEl.classList.toggle('bypassed', st.bypass);
      drawEq();
      syncAudio();
    }
    abBtn.addEventListener('click', () => {
      st.bypass = !st.bypass;
      syncAB();
      S.toast(st.bypass ? 'B · 旁通原声对比' : 'A · 已开启均衡器');
    });

    function drawEq() {
      const W = 1000, H = 220, padX = 48, padY = 24;
      const midY = H / 2;
      const shown = st.bypass ? new Array(10).fill(0) : st.vals;
      const { d, pts } = buildCurve(shown, W, H, padX, padY);
      const area = `${d} L${pts[pts.length - 1][0].toFixed(1)},${midY} L${pts[0][0].toFixed(1)},${midY} Z`;

      let ghost = '';
      if (st.bypass) {
        const g = buildCurve(st.vals, W, H, padX, padY);
        ghost = `<path d="${g.d}" fill="none" stroke="var(--accent)" stroke-opacity=".28" stroke-width="2" stroke-dasharray="5 5"/>`;
      }

      const gridLines = [-12, -6, 0, 6, 12].map(db => {
        const y = padY + ((12 - db) / 24) * (H - padY * 2);
        const cls = db === 0 ? 'eq-grid-zero' : 'eq-grid-line';
        const lbl = db === 0 ? '0 dB' : (db > 0 ? `+${db}` : String(db));
        return `<line x1="${padX - 10}" y1="${y}" x2="${W - padX + 10}" y2="${y}" class="${cls}"/>
                <text x="6" y="${y + 4}" class="eq-grid-lbl">${lbl}</text>`;
      }).join('');

      const dots = pts.map(([x, y]) =>
        `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5.5" class="eq-pt"/>`
      ).join('');

      curveSvg.innerHTML = `<defs>
        <linearGradient id="eqAreaG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--accent)" stop-opacity=".28"/>
          <stop offset="50%" stop-color="var(--accent)" stop-opacity=".06"/>
          <stop offset="100%" stop-color="var(--accent)" stop-opacity=".24"/>
        </linearGradient>
      </defs>${gridLines}${ghost}<path d="${area}" fill="url(#eqAreaG)"/><path d="${d}" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round"/>${dots}`;

      // 同步 10 根推子轨道、滑块、读数
      for (let i = 0; i < 10; i++) {
        const v = st.vals[i];
        const pct = ((v + 12) / 24) * 100;
        const fillFrom = Math.min(50, pct);
        const fillH = Math.abs(pct - 50);
        inputs[i].value = v.toFixed(1);
        dbLabels[i].textContent = fmtDb(st.bypass ? 0 : v);
        thumbs[i].style.bottom = `calc(${pct.toFixed(2)}% - 8px)`;
        fills[i].style.bottom = `${fillFrom.toFixed(2)}%`;
        fills[i].style.height = `${fillH.toFixed(2)}%`;
      }
    }

    /* ---------- 4. 声场效果页签 ---------- */
    const fieldEl = S.$('#fieldGrid', panel);
    fieldEl.innerHTML = `
      <div class="field-item">
        <div class="field-head"><b>声场宽度</b><span class="tnum" id="fwVal">${st.field.width}%</span></div>
        <input type="range" id="fwRange" min="80" max="160" step="2" value="${st.field.width}" aria-label="声场宽度">
        <p>自然拓宽立体声横向分离度，余量随宽度自适应补偿</p>
      </div>
      <div class="field-item">
        <div class="field-head"><b>虚拟低音</b><span class="tnum" id="fbVal">${st.field.bass}%</span></div>
        <input type="range" id="fbRange" min="0" max="100" step="2" value="${st.field.bass}" aria-label="虚拟低音">
        <p>合成基频谐波，让小尺寸耳机或手机外放也能听出下潜质感</p>
      </div>
      <div class="field-item">
        <div class="field-head"><b>厅堂混响（Freeverb）</b><span class="tnum" id="frVal">${st.field.reverb}%</span></div>
        <input type="range" id="frRange" min="0" max="100" step="2" value="${st.field.reverb}" aria-label="厅堂混响">
        <p>轻柔的早期反射与空气尾韵，消除干涩与压迫感</p>
      </div>
      <div class="field-item toggles">
        <label class="switch"><input type="checkbox" id="bs2bToggle"><span></span><div><b>BS2B 双耳交叉馈送</b><small>模拟音箱自然串音，减轻头戴耳机的头中效应</small></div></label>
        <label class="switch"><input type="checkbox" id="hpfToggle" checked><span></span><div><b>外放高通保护（58 Hz）</b><small>滤除扬声器无法重放的超低频，防止破音</small></div></label>
      </div>`;

    S.$('#fwRange', fieldEl).addEventListener('input', e => {
      st.field.width = +e.target.value;
      S.$('#fwVal', fieldEl).textContent = st.field.width + '%';
    });
    S.$('#fbRange', fieldEl).addEventListener('input', e => {
      st.field.bass = +e.target.value;
      S.$('#fbVal', fieldEl).textContent = st.field.bass + '%';
      syncAudio();
    });
    S.$('#frRange', fieldEl).addEventListener('input', e => {
      st.field.reverb = +e.target.value;
      S.$('#frVal', fieldEl).textContent = st.field.reverb + '%';
    });
    S.$('#bs2bToggle', fieldEl).addEventListener('change', e => { st.field.bs2b = e.target.checked; });
    S.$('#hpfToggle', fieldEl).addEventListener('change', e => { st.field.hpf = e.target.checked; syncAudio(); });

    /* ---------- 5. 伴奏消音页签 ---------- */
    const karaInput = S.$('#karaOn', panel);
    const karaPath = S.$('.kara-full', panel);
    const karaBand = S.$('.kara-band', panel);
    function drawKaraoke(depth) {
      const pts = [];
      for (let i = 0; i <= 48; i++) {
        const x = 20 + (i / 48) * 560;
        // 160 Hz - 4.8 kHz 大致落在 x = 150..420
        const inVocal = S.smooth(110, 175, x) * (1 - S.smooth(395, 455, x));
        const ripple = Math.sin(i * 0.65) * 8 + Math.cos(i * 0.3) * 6;
        const y = 78 + ripple + inVocal * depth * 72;
        pts.push([x, y]);
      }
      let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
      for (let i = 1; i < pts.length; i++) {
        const mx = (pts[i - 1][0] + pts[i][0]) / 2;
        const my = (pts[i - 1][1] + pts[i][1]) / 2;
        d += ` Q${pts[i - 1][0].toFixed(1)},${pts[i - 1][1].toFixed(1)} ${mx.toFixed(1)},${my.toFixed(1)}`;
      }
      const last = pts[pts.length - 1];
      d += ` L${last[0].toFixed(1)},${last[1].toFixed(1)} L580,180 L20,180 Z`;
      karaPath.setAttribute('d', d);
      if (karaBand) karaBand.style.opacity = (0.28 + depth * 0.55).toFixed(2);
    }
    karaInput.addEventListener('change', () => { st.karaoke = karaInput.checked; });

    /* ---------- 6. 可选 Web Audio 合成音试听 ---------- */
    let audioCtx = null, eqFilters = [], bassNode = null, hpfNode = null, masterGain = null, oscList = [], audioPlaying = false;

    function syncAudio() {
      if (!audioPlaying || !audioCtx) return;
      const now = audioCtx.currentTime;
      eqFilters.forEach((f, i) => {
        const g = st.bypass ? 0 : st.vals[i];
        f.gain.setTargetAtTime(g, now, 0.03);
      });
      if (bassNode) bassNode.gain.setTargetAtTime((st.field.bass / 100) * 6, now, 0.04);
      if (hpfNode) hpfNode.frequency.setTargetAtTime(st.field.hpf ? 58 : 20, now, 0.04);
    }

    function stopAudio() {
      audioPlaying = false;
      if (S.bgm) S.bgm.duck(false);
      if (masterGain && audioCtx) {
        const now = audioCtx.currentTime;
        masterGain.gain.setTargetAtTime(0, now, 0.04);
      }
      setTimeout(() => {
        oscList.forEach(o => { try { o.stop(); o.disconnect(); } catch (_) {} });
        oscList = [];
        if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
        eqFilters = []; bassNode = null; hpfNode = null; masterGain = null;
      }, 120);
      listenBtn.classList.remove('on');
      S.$('span', listenBtn).textContent = '试听合成音';
      listenBtn.querySelector('.ic').outerHTML = SIcons.svg('play');
    }

    function startAudio() {
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AC();
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.001;

        hpfNode = audioCtx.createBiquadFilter();
        hpfNode.type = 'highpass';
        hpfNode.frequency.value = st.field.hpf ? 58 : 20;

        bassNode = audioCtx.createBiquadFilter();
        bassNode.type = 'lowshelf';
        bassNode.frequency.value = 100;
        bassNode.gain.value = (st.field.bass / 100) * 6;

        eqFilters = freqs.map((hz, i) => {
          const f = audioCtx.createBiquadFilter();
          f.type = 'peaking';
          f.frequency.value = hz;
          f.Q.value = 1.4;
          f.gain.value = st.bypass ? 0 : st.vals[i];
          return f;
        });

        let head = hpfNode;
        hpfNode.connect(bassNode);
        head = bassNode;
        eqFilters.forEach(f => { head.connect(f); head = f; });
        head.connect(masterGain);
        masterGain.connect(audioCtx.destination);

        // 温暖合成和弦（Cmaj9）+ 轻柔粉红噪声覆盖全频段，便于听出 EQ 变化
        [130.81, 196.0, 246.94, 293.66, 329.63].forEach((freq, idx) => {
          const osc = audioCtx.createOscillator();
          const g = audioCtx.createGain();
          osc.type = idx === 0 ? 'triangle' : 'sine';
          osc.frequency.value = freq;
          g.gain.value = idx === 0 ? 0.16 : 0.07;
          osc.connect(g); g.connect(hpfNode);
          osc.start();
          oscList.push(osc);
        });
        const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * 2, audioCtx.sampleRate);
        const ch = buf.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0;
        for (let i = 0; i < ch.length; i++) {
          const w = Math.random() * 2 - 1;
          b0 = 0.997 * b0 + w * 0.029;
          b1 = 0.985 * b1 + w * 0.032;
          b2 = 0.950 * b2 + w * 0.048;
          ch[i] = (b0 + b1 + b2 + w * 0.018) * 0.28;
        }
        const noise = audioCtx.createBufferSource();
        noise.buffer = buf; noise.loop = true;
        const ng = audioCtx.createGain(); ng.gain.value = 0.22;
        noise.connect(ng); ng.connect(hpfNode);
        noise.start();
        oscList.push(noise);

        audioPlaying = true;
        if (S.bgm) S.bgm.duck(true);
        masterGain.gain.setTargetAtTime(0.45, audioCtx.currentTime, 0.08);
        listenBtn.classList.add('on');
        S.$('span', listenBtn).textContent = '停止试听';
        listenBtn.querySelector('.ic').outerHTML = SIcons.svg('pause');
      } catch (_) {
        S.toast('当前浏览器不支持 Web Audio 试听');
      }
    }

    listenBtn.addEventListener('click', () => {
      if (audioPlaying) stopAudio();
      else startAudio();
    });

    /* ---------- 7. 帧循环：滑块平滑趋近 & 消音波形动画 ---------- */
    renderPresets();
    drawEq();
    drawKaraoke(0);

    S.tick(dt => {
      let dirty = false;
      for (let i = 0; i < 10; i++) {
        if (Math.abs(st.vals[i] - st.targetVals[i]) > 0.01) {
          st.vals[i] = S.approach(st.vals[i], st.targetVals[i], 11, dt);
          dirty = true;
        } else if (st.vals[i] !== st.targetVals[i]) {
          st.vals[i] = st.targetVals[i];
          dirty = true;
        }
      }
      if (dirty) { drawEq(); syncAudio(); }

      const kt = st.karaoke ? 1 : 0;
      if (Math.abs(st.karaDepth - kt) > 0.005) {
        st.karaDepth = S.approach(st.karaDepth, kt, 8, dt);
        drawKaraoke(st.karaDepth);
      }
    }, panel);
  });
})();
;
/* 页面其余交互与数据：顶栏、品牌图标、3D 黑胶加载、多语言曲库、桌面歌词、53 款图标、31 套皮肤、工艺计数、下载 */
(function () {
  const S = window.Sonance;

  // 多语言示例曲库（原创虚拟曲目，展示混排与 A–Z 索引）
  const TRACKS = [
    { id: 1,  title: 'สายลมบนภูเขา',   artist: 'Narin',      album: 'Morning Mist',   cover: 'mint',      key: '#', dur: '3:42', recent: true,  fav: true  },
    { id: 2,  title: '새벽 비 소리',     artist: 'Haru',       album: 'Seoul Rain',     cover: 'dusk',      key: '#', dur: '4:15', recent: true,  fav: false },
    { id: 3,  title: '山あいの風',       artist: 'Kaze',       album: 'Komorebi',       cover: 'sunset',    key: '#', dur: '3:58', recent: false, fav: true  },
    { id: 4,  title: 'Afterglow Study',  artist: 'Claire',     album: 'Glass Room',     cover: 'conicA',    key: 'A', dur: '3:24', recent: true,  fav: false },
    { id: 5,  title: 'Clear Horizon',    artist: 'Mono Lake',  album: 'Echoes Vol.2',   cover: 'rings',     key: 'C', dur: '5:12', recent: false, fav: true  },
    { id: 6,  title: '第一缕光',         artist: '林间',       album: '山水间',         cover: 'conicA',    key: 'D', dur: '4:06', recent: true,  fav: true  },
    { id: 7,  title: '飞鸟与海',         artist: '山水乐队',   album: '落日线',         cover: 'sunset',    key: 'F', dur: '4:56', recent: true,  fav: true  },
    { id: 8,  title: '黄昏车站',         artist: '海盐',       album: '末班车',         cover: 'dusk',      key: 'H', dur: '3:49', recent: false, fav: false },
    { id: 9,  title: '几何午后',         artist: '包豪斯',     album: 'Triangle',       cover: 'arcs',      key: 'J', dur: '3:18', recent: true,  fav: false },
    { id: 10, title: '橘子汽水',         artist: '海盐',       album: '夏日切片',       cover: 'dotsCoral', key: 'J', dur: '3:31', recent: false, fav: true  },
    { id: 11, title: '旷野',             artist: '无名氏',     album: 'Open Field',     cover: 'conicB',    key: 'K', dur: '5:04', recent: false, fav: false },
    { id: 12, title: 'Linen & Vinyl',    artist: 'Owen',       album: 'Turntable',      cover: 'checker',   key: 'L', dur: '4:22', recent: true,  fav: false },
    { id: 13, title: 'Op.14 迷宫',       artist: '白日梦',     album: 'Nocturne',       cover: 'checker',   key: 'O', dur: '3:48', recent: false, fav: true  },
    { id: 14, title: '清音',             artist: '山水',       album: '招隐集',         cover: 'type',      key: 'Q', dur: '4:32', recent: true,  fav: true  },
    { id: 15, title: 'Stillwater',       artist: 'Lin',        album: 'Ambient 04',     cover: 'mint',      key: 'S', dur: '6:10', recent: false, fav: false },
    { id: 16, title: '萤火',             artist: '青柠',       album: '夜行',           cover: 'dotsLime',  key: 'Y', dur: '3:55', recent: false, fav: true  },
    { id: 17, title: '正午',             artist: 'Sonance',    album: 'Half-Tone',      cover: 'halftone',  key: 'Z', dur: '4:44', recent: true,  fav: false },
    { id: 18, title: '薄荷雨',           artist: '林间',       album: '清晨',           cover: 'mint',      key: 'B', dur: '3:28', recent: false, fav: false }
  ];

  S.onReady(() => {
    /* ---------- 1. 顶栏滚动 & 品牌图标 ---------- */
    const nav = S.$('#nav');
    const navLinks = S.$$('.nav-seg a', nav);
    function syncNavScroll() {
      if (nav) nav.classList.toggle('scrolled', window.scrollY > 40);
    }
    window.addEventListener('scroll', syncNavScroll, { passive: true });
    syncNavScroll();

    document.addEventListener('s:track', e => {
      const id = e.detail.section.el.id;
      const map = { player: '#player', lyrics: '#player', visualizer: '#player', wall: '#player', vinyl: '#player', studio: '#player', library: '#player', connect: '#player', philosophy: '#player', skins: '#skins', craft: '#skins', download: '#download', community: '#community' };
      const target = map[id] || '';
      navLinks.forEach(a => a.classList.toggle('on', a.getAttribute('href') === target));
    });

    const icons = window.SONANCE_ICONS || [];
    const defIcon = icons.find(x => x.id === 's2_4') || icons[0];
    if (defIcon) {
      ['#brandIc', '#libIc', '#footIc'].forEach(sel => {
        const el = S.$(sel);
        if (el) {
          el.style.background = defIcon.bg;
          el.innerHTML = defIcon.svg;
        }
      });
    }

    /* ---------- 2. Section 06 · 3D 黑胶唱机按需加载 ---------- */
    const vinylBtn = S.$('#vinylLoad');
    const vinylStage = S.$('#vinylStage');
    if (vinylBtn && vinylStage) {
      const posterHtml = vinylStage.innerHTML;
      let loaded = false;
      vinylBtn.addEventListener('click', () => {
        loaded = !loaded;
        if (loaded) {
          vinylStage.innerHTML = '<iframe class="vinyl-iframe" src="vinyl/index.html?v=45ec257f" title="3D 黑胶唱机演示" loading="lazy"></iframe>';
          S.$('b', vinylBtn).textContent = '收起 3D 唱机';
          S.$('small', vinylBtn).textContent = '回到静态唱机示意图';
          S.$('.drop-ic', vinylBtn).innerHTML = SIcons.svg('close');
        } else {
          vinylStage.innerHTML = posterHtml;
          SIcons.hydrate(vinylStage);
          S.$('b', vinylBtn).textContent = '放上唱片';
          S.$('small', vinylBtn).textContent = '加载 3D 场景（约 0.8 MB）';
          S.$('.drop-ic', vinylBtn).innerHTML = SIcons.svg('play');
        }
      });
    }

    /* ---------- 3. Section 08 · 本地曲库演示 ---------- */
    const libList = S.$('#libList');
    const libIndex = S.$('#libIndex');
    const libSearch = S.$('#libSearch');
    const libTabs = S.$('#libTabs');
    const libCount = S.$('#libCount');
    const libRand = S.$('.lib-random');
    if (libList && libIndex) {
      const ALPHA = ['#', ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')];
      let tab = 'all', q = '', activeId = 7;

      libIndex.innerHTML = ALPHA.map(ch => `<button type="button" data-k="${ch}">${ch}</button>`).join('');

      function filtered() {
        return TRACKS.filter(t => {
          if (tab === 'recent' && !t.recent) return false;
          if (tab === 'fav' && !t.fav) return false;
          if (q) {
            const kw = q.toLowerCase();
            return (t.title + ' ' + t.artist + ' ' + t.album).toLowerCase().includes(kw);
          }
          return true;
        });
      }

      function renderLib() {
        const list = filtered();
        if (libCount) libCount.textContent = list.length;
        if (!list.length) {
          libList.innerHTML = '<li class="lib-empty">没有找到匹配的歌曲</li>';
          return;
        }
        libList.innerHTML = list.map(t => {
          const playing = t.id === activeId;
          return `<li class="lib-row${playing ? ' playing' : ''}" data-id="${t.id}" data-key="${t.key}">
            <div class="lib-cv">${SCovers.html(t.cover)}${playing ? '<span class="lib-eq" aria-hidden="true"><i></i><i></i><i></i></span>' : ''}</div>
            <div class="lib-info"><b>${t.title}</b><small>${t.artist} · ${t.album}</small></div>
            <span class="lib-dur tnum">${t.dur}</span>
            <button type="button" class="lib-fav${t.fav ? ' on' : ''}" aria-label="${t.fav ? '取消收藏' : '收藏'} ${t.title}">${SIcons.svg('heart')}</button>
          </li>`;
        }).join('');
      }

      libList.addEventListener('click', e => {
        const favBtn = e.target.closest('.lib-fav');
        if (favBtn) {
          e.stopPropagation();
          const id = +favBtn.closest('.lib-row').dataset.id;
          const tr = TRACKS.find(x => x.id === id);
          if (tr) { tr.fav = !tr.fav; renderLib(); }
          return;
        }
        const row = e.target.closest('.lib-row');
        if (row) {
          activeId = +row.dataset.id;
          renderLib();
        }
      });

      libTabs.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        tab = b.dataset.v;
        S.$$('button', libTabs).forEach(x => x.classList.toggle('on', x === b));
        renderLib();
      });

      libSearch.addEventListener('input', () => {
        q = libSearch.value.trim();
        renderLib();
      });

      if (libRand) {
        libRand.addEventListener('click', () => {
          const list = filtered();
          if (!list.length) return;
          const pick = list[Math.floor(Math.random() * list.length)];
          activeId = pick.id;
          renderLib();
          const row = S.$(`.lib-row[data-id="${activeId}"]`, libList);
          if (row) row.scrollIntoView({ behavior: S.reduced ? 'auto' : 'smooth', block: 'nearest' });
        });
      }

      libIndex.addEventListener('click', e => {
        const b = e.target.closest('button[data-k]');
        if (!b) return;
        const k = b.dataset.k;
        S.$$('button', libIndex).forEach(x => x.classList.toggle('on', x === b));
        const rows = S.$$('.lib-row', libList);
        let hit = rows.find(r => r.dataset.key === k);
        if (!hit && k !== '#') {
          const idx = ALPHA.indexOf(k);
          hit = rows.find(r => ALPHA.indexOf(r.dataset.key) >= idx);
        }
        if (hit) hit.scrollIntoView({ behavior: S.reduced ? 'auto' : 'smooth', block: 'start' });
      });

      renderLib();
    }

    /* ---------- 4. Section 09 · 小组件封面 / 桌面歌词 / 53 款图标 ---------- */
    S.$$('.wg-cv[data-wcover]').forEach(el => {
      el.innerHTML = SCovers.html(el.dataset.wcover);
    });

    const dlyBar = S.$('#dlyBar');
    if (dlyBar) {
      const modes = [
        { cls: 'mode-none', label: '无背景立体字' },
        { cls: 'mode-light', label: '浅色磨砂背景' },
        { cls: 'mode-dark', label: '深色磨砂背景' }
      ];
      const lines = ['风从山那边过来', '听见溪水 在练习换气', '非必丝与竹，山水有清音'];
      let mi = 0, li = 0;
      dlyBar.addEventListener('click', () => {
        mi = (mi + 1) % modes.length;
        li = (li + 1) % lines.length;
        dlyBar.className = 'dly-bar ' + modes[mi].cls;
        S.$('.dly-line', dlyBar).textContent = lines[li];
        S.toast('桌面歌词样式：' + modes[mi].label);
      });
    }

    const marquee = S.$('#iconMarquee');
    if (marquee && icons.length) {
      const half = Math.ceil(icons.length / 2);
      const rowA = icons.slice(0, half);
      const rowB = icons.slice(half);
      const tile = ic => `<div class="ic-tile" title="${ic.name}"><span class="ic-squircle" style="background:${ic.bg}">${ic.svg}</span><small>${ic.name.split(' · ')[0]}</small></div>`;
      const makeRow = (list, rev) => `<div class="mq-row${rev ? ' rev' : ''}"><div class="mq-track">${list.map(tile).join('')}${list.map(tile).join('')}</div></div>`;
      marquee.innerHTML = makeRow(rowA, false) + makeRow(rowB, true);
    }

    /* ---------- 5. Section 10 · 31 套皮肤 ---------- */
    const skinsSec = S.$('#skins');
    const skinRail = S.$('#skinRail');
    const skinFilter = S.$('#skinFilter');
    const skinsBg = S.$('.skins-bg', skinsSec);
    const skins = window.SONANCE_SKINS || [];
    if (skinsSec && skinRail && skins.length) {
      let filter = 'all', pinnedId = null;

      function applySkinPreview(skin) {
        if (!skin) {
          skinsSec.classList.remove('previewing', 'preview-dark', 'preview-light');
          skinsBg.style.opacity = '0';
          skinsSec.style.removeProperty('--sk-text');
          skinsSec.style.removeProperty('--sk-dim');
          skinsSec.style.removeProperty('--sk-accent');
          skinsSec.style.removeProperty('--sk-on');
          return;
        }
        const g0 = (skin.grad && skin.grad[0]) || skin.surface2 || skin.bg;
        const g1 = (skin.grad && skin.grad[1]) || skin.bg;
        skinsBg.style.background = `radial-gradient(circle at 72% 30%, ${skin.accent}2e 0%, transparent 50%), linear-gradient(135deg, ${g0}, ${g1})`;
        skinsBg.style.opacity = '1';
        skinsSec.classList.add('previewing');
        skinsSec.classList.toggle('preview-dark', !skin.light);
        skinsSec.classList.toggle('preview-light', !!skin.light);
        skinsSec.style.setProperty('--sk-text', skin.text);
        skinsSec.style.setProperty('--sk-dim', skin.textDim);
        skinsSec.style.setProperty('--sk-accent', skin.accent);
        skinsSec.style.setProperty('--sk-on', skin.onAccent || (skin.light ? '#fff' : '#121212'));
      }

      function renderSkins() {
        const list = filter === 'all' ? skins : skins.filter(s => (filter === 'light' ? s.light : !s.light));
        skinRail.innerHTML = list.map(sk => {
          const pin = sk.id === pinnedId;
          return `<button type="button" class="skin-card${pin ? ' on' : ''}" data-sid="${sk.id}" style="--s-bg:${sk.bg};--s-sf:${sk.surface};--s-sf2:${sk.surface2};--s-tx:${sk.text};--s-dim:${sk.textDim};--s-ac:${sk.accent};--s-on:${sk.onAccent}">
            <div class="sk-mock">
              <div class="sk-top"><i></i><span></span></div>
              <div class="sk-rows">
                <div class="sk-r"><i style="background:${sk.accent}"></i><span><b style="width:68%"></b><small style="width:42%"></small></span></div>
                <div class="sk-r"><i></i><span><b style="width:54%"></b><small style="width:36%"></small></span></div>
              </div>
              <div class="sk-mini"><span class="sk-art"></span><span class="sk-bar"></span><span class="sk-dot"></span></div>
            </div>
            <div class="sk-meta"><b>${sk.name}</b><small>${sk.tagline}</small></div>
          </button>`;
        }).join('');
      }

      skinRail.addEventListener('pointerover', e => {
        if (e.pointerType === 'touch') return;
        const c = e.target.closest('.skin-card[data-sid]');
        if (!c) return;
        const sk = skins.find(x => x.id === c.dataset.sid);
        if (sk) applySkinPreview(sk);
      });
      skinRail.addEventListener('pointerleave', () => {
        const sk = pinnedId ? skins.find(x => x.id === pinnedId) : null;
        applySkinPreview(sk);
      });
      skinRail.addEventListener('click', e => {
        const c = e.target.closest('.skin-card[data-sid]');
        if (!c) return;
        pinnedId = pinnedId === c.dataset.sid ? null : c.dataset.sid;
        const sk = pinnedId ? skins.find(x => x.id === pinnedId) : null;
        applySkinPreview(sk);
        S.$$('.skin-card', skinRail).forEach(x => x.classList.toggle('on', x.dataset.sid === pinnedId));
      });

      if (skinFilter) {
        skinFilter.addEventListener('click', e => {
          const b = e.target.closest('button'); if (!b) return;
          filter = b.dataset.v;
          S.$$('button', skinFilter).forEach(x => x.classList.toggle('on', x === b));
          renderSkins();
        });
      }
      renderSkins();
    }

    /* ---------- 6. Section 11 · 工艺数字递增 ---------- */
    const nums = S.$$('.num b[data-count]');
    if (nums.length) {
      const nio = new IntersectionObserver(entries => {
        entries.forEach(en => {
          if (!en.isIntersecting) return;
          const el = en.target;
          nio.unobserve(el);
          const target = +el.dataset.count;
          if (S.reduced || target === 0) { el.textContent = String(target); return; }
          const t0 = performance.now();
          const step = now => {
            const k = S.clamp((now - t0) / 900, 0, 1);
            const e = 1 - Math.pow(1 - k, 3);
            el.textContent = String(Math.round(target * e));
            if (k < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        });
      }, { threshold: 0.2 });
      nums.forEach(n => nio.observe(n));
    }

    /* ---------- 7. Section 12 · 夸克下载 / 一键复制口令与群号 / 二维码放大 ---------- */
    const dlCover = S.$('#dlCover');
    if (dlCover) dlCover.innerHTML = SCovers.html('sunset');

    const COPY_MAP = {
      quark: () => S.copy(S.config.quarkCode, '已复制夸克口令，打开夸克网盘 APP 即可获取'),
      qq: () => S.copy(S.config.qqGroup, '已复制 QQ 交流群号：' + S.config.qqGroup),
      wechat: () => S.copy(S.config.wechat, '已复制微信号：' + S.config.wechat),
      sha256: () => S.copy(S.config.sha256, '已复制 SHA-256 校验值')
    };
    S.$$('[data-copy]').forEach(el => {
      const act = COPY_MAP[el.dataset.copy];
      if (!act) return;
      if (el.tagName !== 'BUTTON' && el.tagName !== 'A') {
        el.setAttribute('role', 'button');
        el.tabIndex = 0;
        el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(); } });
      }
      el.addEventListener('click', act);
    });

    const qrModal = S.$('#qrModal');
    if (qrModal) {
      let lastTrigger = null;
      const closeQr = () => {
        if (!qrModal.classList.contains('open')) return;
        qrModal.classList.remove('open');
        qrModal.setAttribute('aria-hidden', 'true');
        if (lastTrigger) { lastTrigger.focus({ preventScroll: true }); lastTrigger = null; }
      };
      S.$$('.qr-zoom').forEach(btn => {
        btn.addEventListener('click', () => {
          lastTrigger = btn;
          const src = btn.dataset.qr;
          const title = btn.dataset.qrTitle || '二维码预览';
          qrModal.innerHTML = `<div class="qr-card glass">
            <button type="button" class="qr-close" aria-label="关闭二维码预览">${SIcons.svg('close')}</button>
            <img src="${src}" alt="${title}">
            <p>${title}</p>
          </div>`;
          qrModal.classList.add('open');
          qrModal.setAttribute('aria-hidden', 'false');
          const cl = S.$('.qr-close', qrModal);
          if (cl) {
            cl.addEventListener('click', closeQr);
            cl.focus({ preventScroll: true });
          }
        });
      });
      qrModal.addEventListener('click', e => { if (e.target === qrModal) closeQr(); });
      document.addEventListener('keydown', e => { if (e.key === 'Escape') closeQr(); });
    }
  });
})();
